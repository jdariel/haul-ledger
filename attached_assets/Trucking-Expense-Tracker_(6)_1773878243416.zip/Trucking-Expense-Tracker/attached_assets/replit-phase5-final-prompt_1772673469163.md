# HaulLedger — Phase 5 (Final) Prompt

You are a senior full-stack engineer. Work through every numbered item in order. Do not break existing functionality. Run `npm run build` at the end and fix any TypeScript errors before finishing.

---

## 1. BUG FIX — deleteAllUserData must delete quickExpenses

**File: `server/storage.ts`**

Find the `deleteAllUserData` method (around line 275). `quickExpenses` is already imported at line 3. Add one missing delete call as the **first** line inside the method:

```ts
// BEFORE:
async deleteAllUserData(userId: string): Promise<void> {
  await db.delete(fuelEntries).where(eq(fuelEntries.userId, userId));
  await db.delete(trips).where(eq(trips.userId, userId));
  await db.delete(assets).where(eq(assets.userId, userId));
  await db.delete(expenses).where(eq(expenses.userId, userId));
  await db.delete(income).where(eq(income.userId, userId));
  await db.delete(savedRoutes).where(eq(savedRoutes.userId, userId));
}

// AFTER:
async deleteAllUserData(userId: string): Promise<void> {
  await db.delete(quickExpenses).where(eq(quickExpenses.userId, userId));
  await db.delete(fuelEntries).where(eq(fuelEntries.userId, userId));
  await db.delete(trips).where(eq(trips.userId, userId));
  await db.delete(assets).where(eq(assets.userId, userId));
  await db.delete(expenses).where(eq(expenses.userId, userId));
  await db.delete(income).where(eq(income.userId, userId));
  await db.delete(savedRoutes).where(eq(savedRoutes.userId, userId));
}
```

---

## 2. LIGHT MODE — Fix glass-card utility

**File: `client/src/index.css`**

Replace the `.glass-card` class:

```css
/* BEFORE: */
.glass-card {
  @apply bg-card/80 backdrop-blur-md border border-white/5 shadow-xl;
}

/* AFTER: */
.glass-card {
  @apply bg-card/80 backdrop-blur-md border border-border/20 shadow-xl;
}
```

---

## 3. LIGHT MODE — Full replacement pass across all files

Apply the substitution table below to every matching occurrence in every file listed. Do **not** touch color-specific classes (emerald, rose, amber, cyan, primary, destructive). Only replace white-opacity borders and backgrounds.

### Substitution table

| Find | Replace with |
|---|---|
| `border-white/5` | `border-border/20` |
| `border-white/10` | `border-border/25` |
| `border-white/[0.06]` | `border-border/20` |
| `border-white/[0.08]` | `border-border/25` |
| `border-white/[0.04]` | `border-border/15` |
| `border-white/[0.03]` | `border-border/10` |
| `border-white/[0.02]` | `border-border/10` |
| `bg-white/[0.04]` | `bg-muted/40` |
| `bg-white/[0.03]` | `bg-muted/30` |
| `bg-white/[0.02]` | `bg-muted/20` |
| `bg-white/[0.01]` | `bg-muted/10` |
| `bg-white/5` | `bg-muted/30` |
| `hover:bg-white/5` | `hover:bg-muted/30` |
| `from-white/[0.04]` | `from-muted/40` |

### Files to update (apply all matching substitutions in each)

**`client/src/components/BottomNav.tsx`**
- Line 17: `border-white/5`

**`client/src/components/ConfirmDeleteDialog.tsx`**
- Lines 25, 31: `border-white/10`

**`client/src/components/CreateExpenseDialog.tsx`**
- Lines 241, 249: `border-white/10`
- Line 289: `border-white/10` and `hover:bg-white/5`
- Lines 381, 404, 429, 507: `border-white/10` on SelectContent
- Line 443: `border-white/5`

**`client/src/components/CreateIncomeDialog.tsx`**
- Line 125: `border-white/10`
- Line 132: `border-white/10` and `bg-white/[0.03]`
- Line 152: `border-white/10` and `bg-white/[0.02]`

**`client/src/components/IFTAReportDialog.tsx`**
- Lines 156, 157: `border-white/[0.06]`
- Lines 171, 175: `border-white/10`
- Lines 205, 209, 213: `bg-white/[0.03]` and `border-white/[0.06]`
- Lines 224, 257, 293, 298, 332, 337: `border-white/[0.06]`
- Lines 227, 260, 301, 340: `border-white/[0.06]` (header rows)
- Lines 235, 269, 310, 351: `border-white/[0.03]` (data rows)
- Lines 241, 276, 317, 360: `bg-white/[0.02]` (total rows)

**`client/src/components/ScheduleCDialog.tsx`**
- Lines 117, 118: `border-white/[0.06]`
- Lines 132, 136: `border-white/10`
- Lines 153, 180, 228, 267: `border-white/[0.06]` (table wrappers)
- Lines 156, 183, 231, 270: `border-white/[0.06]` (header rows)
- Lines 163, 255, 294: `border-white/[0.06]` (total rows)
- Line 168: `bg-white/[0.02]`
- Lines 191, 242, 281: `bg-white/[0.01]` (alternating rows)
- Line 204: `bg-white/[0.03]` and `border-white/[0.06]`
- Line 214: `border-white/[0.06]` and `from-white/[0.04]`

**`client/src/components/StatCard.tsx`**
- Line 39: `bg-white/5` and `border-white/5`

**`client/src/components/SuggestionInput.tsx`**
- Line 62: `border-white/10`

**`client/src/components/TransactionList.tsx`**
- Lines 41, 55: `border-white/5`
- Line 86: `border-white/10`

**`client/src/pages/Assets.tsx`**
- Lines 83, 95, 125: `border-white/5`
- Line 163: `border-white/10`

**`client/src/pages/Expenses.tsx`**
- Lines 89, 94: `border-white/10`
- Line 131: `border-white/10`
- Lines 145, 190: `border-white/5`
- Line 220: `bg-white/5` (payment method badge background)
- Line 273: `border-white/10`

**`client/src/pages/FuelLog.tsx`**
- Lines 132, 138: `border-white/5`
- Line 179: `border-white/10`

**`client/src/pages/Income.tsx`**
- Lines 61, 71: `border-white/5`

**`client/src/pages/Reports.tsx`**
- Lines 158, 162: `border-white/10`
- Line 176 — ternary expression, replace only the false branch:
  ```tsx
  // BEFORE:
  startOpen ? "border-primary bg-primary/5" : "border-white/10 bg-white/[0.03]"
  // AFTER:
  startOpen ? "border-primary bg-primary/5" : "border-border/25 bg-muted/30"
  ```
- Line 184: `border-white/10` on PopoverContent
- Line 206 — ternary expression, replace only the false branch:
  ```tsx
  // BEFORE:
  endOpen ? "border-primary bg-primary/5" : "border-white/10 bg-white/[0.03]"
  // AFTER:
  endOpen ? "border-primary bg-primary/5" : "border-border/25 bg-muted/30"
  ```
- Line 214: `border-white/10` on PopoverContent
- Line 233: `bg-white/[0.04]` (tab toggle container)
- Lines 259, 292, 318, 359, 417, 466: `border-white/[0.06]` and `from-white/[0.04]` (stat cards)
- Line 335: `border-white/[0.04]`
- Line 341: `bg-white/[0.04]` (fuel bar background)
- Line 472: `border-white/[0.04]` (expense list dividers)

**`client/src/pages/SavedRoutes.tsx`**
- Lines 87, 118: `border-white/5`
- Line 134: `border-white/10`

**`client/src/pages/Trips.tsx`**
- Lines 106, 121, 127: `border-white/5`
- Line 171: `border-white/10`
- Lines 190, 203: `border-white/5`

---

## 4. LIGHT MODE — Fix the Sidebar

**File: `client/src/components/Sidebar.tsx`**

Three replacements:

**Line 22** — outer wrapper border:
```tsx
// BEFORE: border-r border-white/5
// AFTER:  border-r border-border/20
```

**Line 46** — inactive nav item hover (also fixes dark-only `hover:text-white`):
```tsx
// BEFORE: "text-muted-foreground hover:bg-white/5 hover:text-white"
// AFTER:  "text-muted-foreground hover:bg-muted/30 hover:text-foreground"
```

**Line 58** — bottom section border:
```tsx
// BEFORE: border-t border-white/5
// AFTER:  border-t border-border/20
```

---

## 5. LIGHT MODE — Fix the Landing page

**File: `client/src/pages/Landing.tsx`**

**Line 6** — remove hardcoded dark background and `text-white`:
```tsx
// BEFORE:
<div className="min-h-screen bg-[#0b1121] text-white flex flex-col lg:flex-row">
// AFTER:
<div className="min-h-screen bg-background text-foreground flex flex-col lg:flex-row">
```

**Line 59** — right panel divider:
```tsx
// BEFORE: lg:border-white/[0.06]
// AFTER:  lg:border-border/20
```

**Line 62** — auth card:
```tsx
// BEFORE:
<div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] p-6 sm:p-8 space-y-6">
// AFTER:
<div className="rounded-2xl border border-border/25 bg-card/50 p-6 sm:p-8 space-y-6">
```

**Lines 86 and 88** — both divider lines (identical, replace both):
```tsx
// BEFORE: <div className="flex-1 h-px bg-white/[0.06]" />
// AFTER:  <div className="flex-1 h-px bg-border/20" />
```

**Line 138** — FeaturePill component wrapper:
```tsx
// BEFORE:
<div className="flex items-center gap-3 rounded-xl bg-white/[0.04] border border-white/[0.06] px-4 py-3">
// AFTER:
<div className="flex items-center gap-3 rounded-xl bg-muted/40 border border-border/20 px-4 py-3">
```

**Line 149** — HowItWorksStep component wrapper:
```tsx
// BEFORE: bg-white/[0.04] border border-white/[0.06]
// AFTER:  bg-muted/40 border border-border/20
```

**Line 154** — HowItWorksStep title (hardcoded `text-white`):
```tsx
// BEFORE: <p className="text-sm font-semibold text-white">{title}</p>
// AFTER:  <p className="text-sm font-semibold text-foreground">{title}</p>
```

Also in **`client/src/pages/Assets.tsx`**, find both asset name paragraphs that hardcode `text-white` and fix them:
```tsx
// BEFORE (appears twice — once in trucks section, once in trailers):
<p className="font-semibold text-white truncate">{a.name}</p>
// AFTER:
<p className="font-semibold text-foreground truncate">{a.name}</p>
```

---

## 6. STICKY BACK BUTTON — QuickAdd page

**File: `client/src/pages/QuickAdd.tsx`**

The `← Settings` link is inside `<header>` and scrolls out of view. Replace the return statement's opening and the `<header>` block:

```tsx
// BEFORE:
return (
  <div className="space-y-6 pb-20">
    <header>
      <Link href="/settings" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground mb-3 hover:text-foreground transition-colors" data-testid="link-back-settings">
        <ArrowLeft className="w-4 h-4" />
        Settings
      </Link>
      <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-quick-add-title">Quick Add</h1>
      <p className="text-muted-foreground mt-1">Tap a shortcut on the dashboard to instantly log a common expense.</p>
    </header>

// AFTER:
return (
  <div className="space-y-6 pb-20">
    <div
      className="sticky top-0 z-20 -mx-4 px-4 py-2 md:-mx-8 md:px-8 bg-background/90 backdrop-blur-sm border-b border-border/20"
      data-testid="quickadd-sticky-nav"
    >
      <Link
        href="/settings"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        data-testid="link-back-settings"
      >
        <ArrowLeft className="w-4 h-4" />
        Settings
      </Link>
    </div>

    <header>
      <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-quick-add-title">Quick Add</h1>
      <p className="text-muted-foreground mt-1">Tap a shortcut on the dashboard to instantly log a common expense.</p>
    </header>
```

---

## 7. ODOMETER RUNNING TOTAL — Fleet / Assets page

Trips already store `assetId`. Show total miles logged per truck on the Fleet page.

**File: `client/src/pages/Assets.tsx`**

**Step 1** — Add to imports:
```tsx
import { useTrips } from "@/hooks/use-trips";
// Add Navigation to the existing lucide-react import line
import { Plus, Truck, Loader2, Pencil, Trash2, Container, Navigation } from "lucide-react";
```

**Step 2** — Add the hook and helper inside the `Assets` component body, right after the existing hooks:
```tsx
const { data: tripsData } = useTrips();

function getMilesForAsset(assetId: number): number {
  return (tripsData || [])
    .filter((t: any) => t.assetId === assetId)
    .reduce((sum: number, t: any) => {
      if (t.startOdometer && t.endOdometer) {
        return sum + (Number(t.endOdometer) - Number(t.startOdometer));
      }
      return sum + Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0);
    }, 0);
}
```

**Step 3** — Inside each asset card (there are two card sections — trucks and trailers, both with identical structure), find the `<div className="min-w-0">` that holds the asset name, year/make/model, plate, and VIN. Add the miles block as the **last child** of that div, after the VIN paragraph:

```tsx
{(() => {
  const miles = getMilesForAsset(a.id);
  return miles > 0 ? (
    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border/20">
      <Navigation className="w-3 h-3 text-cyan-400 flex-shrink-0" />
      <span className="text-xs text-muted-foreground">
        <span className="font-medium text-foreground">{miles.toLocaleString()}</span> miles logged
      </span>
    </div>
  ) : null;
})()}
```

Add this in **both** the trucks card and the trailers card.

---

## 8. ONBOARDING — First-time welcome banner

**Step 1** — Add to `client/src/lib/userPrefs.ts`:
```ts
export function isFirstVisit(): boolean {
  return !localStorage.getItem("hl-visited");
}
export function markVisited(): void {
  localStorage.setItem("hl-visited", "1");
}
```

**Step 2** — Create `client/src/components/OnboardingBanner.tsx`:
```tsx
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { X, Truck, Receipt, TrendingUp, BarChart3 } from "lucide-react";
import { isFirstVisit, markVisited } from "@/lib/userPrefs";

export function OnboardingBanner() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isFirstVisit()) {
      setShow(true);
      markVisited();
    }
  }, []);

  if (!show) return null;

  const steps = [
    { icon: Truck,      label: "Add your truck",      href: "/fleet",    color: "text-cyan-400",    bg: "bg-cyan-500/10"    },
    { icon: TrendingUp, label: "Log your first load", href: "/income",   color: "text-emerald-400", bg: "bg-emerald-500/10" },
    { icon: Receipt,    label: "Track expenses",       href: "/expenses", color: "text-rose-400",    bg: "bg-rose-500/10"    },
    { icon: BarChart3,  label: "View reports",         href: "/reports",  color: "text-primary",     bg: "bg-primary/10"     },
  ];

  return (
    <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5 relative" data-testid="card-onboarding">
      <button
        onClick={() => setShow(false)}
        className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Dismiss"
        data-testid="button-dismiss-onboarding"
      >
        <X className="w-4 h-4" />
      </button>

      <h2 className="font-display font-bold text-lg text-foreground mb-0.5">Welcome to HaulLedger 👋</h2>
      <p className="text-sm text-muted-foreground mb-4">Here's how to get started:</p>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {steps.map((step, i) => {
          const Icon = step.icon;
          return (
            <Link
              key={step.href}
              href={step.href}
              className="flex flex-col items-center gap-2 p-3 rounded-xl bg-card/50 border border-border/20 hover:border-primary/30 hover:bg-card/80 transition-all text-center"
              data-testid={`onboarding-step-${i + 1}`}
            >
              <div className={`w-9 h-9 rounded-xl ${step.bg} flex items-center justify-center`}>
                <Icon className={`w-5 h-5 ${step.color}`} />
              </div>
              <span className="text-xs font-medium text-foreground leading-tight">{step.label}</span>
            </Link>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground mt-4 pt-3 border-t border-border/20">
        💡 Tip: Set up{" "}
        <Link href="/settings/quick-add" className="text-primary underline underline-offset-2">
          Quick Add shortcuts
        </Link>{" "}
        to log common expenses in one tap from the dashboard.
      </p>
    </div>
  );
}
```

**Step 3** — In `client/src/pages/Dashboard.tsx`, add the import and place the component as the **first child** inside the outer div, before `<header>`:
```tsx
import { OnboardingBanner } from "@/components/OnboardingBanner";

// In JSX:
<div className="space-y-5 pb-32 relative">
  <OnboardingBanner />
  <header>
    ...
```

---

## 9. PDF PRINT UPGRADE — Schedule C accountant summary

**File: `client/src/components/ScheduleCDialog.tsx`**

Find `handlePrint` (line 50). Replace the entire `w.document.write(...)` template string. Keep the null checks, `w.document.close()`, and `w.print()` untouched:

```tsx
const handlePrint = () => {
  const printContent = document.getElementById("schedulec-print-content");
  if (!printContent) return;
  const w = window.open("", "_blank");
  if (!w) return;

  const netEl = printContent.querySelector("[data-print-net]");
  const netText = netEl?.textContent || "—";

  w.document.write(`
    <html><head><title>HaulLedger — Schedule C Summary</title>
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
             padding: 32px; color: #111; font-size: 12px; max-width: 820px; margin: 0 auto; }
      .cover { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 2px solid #111; }
      .brand { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; margin-bottom: 4px; }
      .period { font-size: 13px; color: #555; margin-bottom: 14px; }
      .accountant-note { font-size: 11px; color: #555; background: #f4f4f4;
                         border-left: 3px solid #333; padding: 8px 12px; border-radius: 2px; }
      .net-box { margin-bottom: 24px; padding: 16px 20px; border: 2px solid #111;
                 border-radius: 6px; display: flex; justify-content: space-between; align-items: center; }
      .net-label { font-size: 11px; font-weight: 600; text-transform: uppercase;
                   letter-spacing: 0.5px; color: #666; }
      .net-sub { font-size: 10px; color: #999; margin-top: 3px; }
      .net-value { font-size: 30px; font-weight: 800; letter-spacing: -1px; }
      h1 { font-size: 18px; margin-bottom: 2px; }
      h2 { font-size: 13px; margin-top: 20px; margin-bottom: 8px; color: #444;
           border-bottom: 1px solid #ddd; padding-bottom: 4px;
           text-transform: uppercase; letter-spacing: 0.5px; }
      .subtitle { color: #666; font-size: 12px; margin-bottom: 20px; }
      .form-title { font-size: 10px; color: #999; text-transform: uppercase;
                    letter-spacing: 0.5px; margin-bottom: 4px; }
      table { width: 100%; border-collapse: collapse; margin-top: 4px; }
      th { text-align: left; border-bottom: 2px solid #333; padding: 6px 8px;
           font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #555; }
      td { border-bottom: 1px solid #eee; padding: 6px 8px; }
      .num { text-align: right; font-variant-numeric: tabular-nums; }
      .line-num { color: #999; font-size: 11px; width: 40px; }
      .total-row td { border-top: 2px solid #333; border-bottom: 2px solid #333;
                      font-weight: 700; background: #f9f9f9; }
      .section-total td { border-top: 1px solid #999; font-weight: 600; background: #fafafa; }
      .profit-row td { border-top: 2px solid #333; font-weight: 700; font-size: 14px; }
      .footer { margin-top: 40px; padding-top: 12px; border-top: 1px solid #ddd;
                font-size: 10px; color: #bbb; text-align: center; }
      @media print { body { padding: 16px; } }
    </style></head><body>
    <div class="cover">
      <div class="brand">HaulLedger</div>
      <div class="period">Schedule C Business Expense Summary</div>
      <div class="accountant-note">
        <strong>For your accountant:</strong> This report was generated by HaulLedger.
        Please retain original receipts for all expense line items. This summary is for
        reference only and does not constitute a filed tax document.
      </div>
    </div>
    <div class="net-box">
      <div>
        <div class="net-label">Line 31 — Net Profit / (Loss)</div>
        <div class="net-sub">Total gross income minus total deductible expenses</div>
      </div>
      <div class="net-value">${netText}</div>
    </div>
    ${printContent.innerHTML}
    <div class="footer">Generated by HaulLedger &mdash; Retain with your tax records</div>
    </body></html>
  `);
  w.document.close();
  w.print();
};
```

Then find the hidden print content region (the div with `id="schedulec-print-content"`). Locate the `<td>` that renders the net profit value in the summary and add `data-print-net` to it:

```tsx
// Find the net profit td and add the attribute — it will look something like:
<td className="num font-bold" data-print-net>{fmt(netProfit)}</td>
```

---

## AFTER ALL CHANGES

Run `npm run build` and fix any TypeScript errors.

Then verify this checklist:

**Bug fix:**
- Settings → Delete All Data → confirm → sign back in → `/settings/quick-add` → list is empty ✓

**Light mode** (toggle in Settings → Appearance):
- Dashboard: no white-on-white borders ✓
- Expenses: filter button, search bar, rows all readable ✓
- Reports: date pickers, stat cards, tab toggle readable ✓
- IFTA dialog and Schedule C dialog: table borders visible, not invisible ✓
- Landing page: background responds to theme, auth card readable ✓
- Sidebar: border and hover states work in both themes ✓
- Assets, Trips, FuelLog, Income, SavedRoutes: no invisible borders ✓

**QuickAdd sticky nav:**
- Scroll down on `/settings/quick-add` → `← Settings` bar stays pinned at the top ✓

**Odometer:**
- Assign a trip to an asset → Fleet page → asset card shows "X miles logged" ✓

**Onboarding:**
- Run `localStorage.clear()` in the browser console → refresh → welcome banner appears on Dashboard ✓
- Dismiss with X → refresh → banner stays gone ✓
- Each step card navigates to the correct page ✓

**PDF print:**
- Reports → Schedule C → Print → preview shows HaulLedger brand header, net profit callout box, accountant note, and footer ✓
