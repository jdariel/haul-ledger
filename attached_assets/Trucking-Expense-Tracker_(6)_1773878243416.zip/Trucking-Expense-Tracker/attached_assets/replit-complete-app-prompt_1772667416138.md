# TruckBooks — Phase 3: Complete the App

You are a senior full-stack engineer working on TruckBooks, a trucking expense tracker. Below are the remaining fixes and features needed to make this a fully complete, production-ready app. Work through them in order. Do not break existing functionality. After all changes, run `npm run build` and confirm no TypeScript errors.

---

## 1. DELETE CONFIRMATION — PREVENT ACCIDENTAL DATA LOSS

Currently, swiping to delete on Expenses, Income, FuelLog, Trips, and Assets immediately deletes the record with no confirmation. This is dangerous.

**Fix every delete in the app:**

Create a reusable `ConfirmDeleteDialog` component at `client/src/components/ConfirmDeleteDialog.tsx`:

```tsx
interface ConfirmDeleteDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  onConfirm: () => void;
  isDeleting?: boolean;
}
```

It should render an `AlertDialog` with a red "Delete" confirm button and a cancel button.

Then update these files to use it instead of direct deletes:
- `client/src/pages/Expenses.tsx` — set a `pendingDelete` state, open the dialog, only call `deleteExpense.mutateAsync()` on confirm
- `client/src/pages/Income.tsx` — same pattern
- `client/src/pages/FuelLog.tsx` — same pattern
- `client/src/pages/Trips.tsx` — same pattern
- `client/src/pages/Assets.tsx` — same pattern

The `SwipeableRow` `onDelete` prop should set `pendingDelete` to the item, not immediately delete it.

---

## 2. RECEIPT VIEWER — TAP TO VIEW ATTACHED RECEIPT

The `receiptUrl` is stored on expenses but there is no way to view the image. When an expense has a receipt attached, tapping the receipt icon should open a fullscreen image dialog.

**In `client/src/pages/Expenses.tsx`:**

Add state: `const [viewingReceiptUrl, setViewingReceiptUrl] = useState<string | null>(null)`

Add a receipt icon button on each expense row (next to the amount). When clicked (not swiped), call `setViewingReceiptUrl(expense.receiptUrl)`.

Add a `Dialog` at the bottom of the page:
```tsx
<Dialog open={!!viewingReceiptUrl} onOpenChange={() => setViewingReceiptUrl(null)}>
  <DialogContent className="max-w-lg p-2 bg-black border-white/10">
    <img src={viewingReceiptUrl!} className="w-full rounded-lg object-contain max-h-[80vh]" />
  </DialogContent>
</Dialog>
```

Also add the same receipt viewer to the edit dialog — in `CreateExpenseDialog.tsx`, when editing an expense that has a `receiptUrl`, show a small thumbnail with a "View Receipt" button below the upload area.

---

## 3. SEARCH + DATE RANGE FILTER ON EXPENSES PAGE

The Expenses page currently only filters by week + category. Add a search bar and a date range mode.

**In `client/src/pages/Expenses.tsx`:**

Add a search input at the top of the list area (below the category filter). It should filter expenses by merchant name (case-insensitive `includes`).

Add a toggle between "Week" view and "All" view:
- Week view: current behavior (WeekNavigator + week total)
- All view: shows all expenses, sorted by date descending, with the existing category filter and new search filter still applied

The toggle should be a simple segmented control: `[ Week | All ]`

When in "All" mode, show a total at the top: "X expenses • $Y total"

---

## 4. ADD REPORTS TAB TO BOTTOM NAV

Reports is one of the most important screens but is buried under Settings. Update `client/src/components/BottomNav.tsx`:

Replace the current 4-item nav with 5 items:
```
Home | Expenses | Income | Reports | More
```

Use these icons:
- Home: `LayoutDashboard`
- Expenses: `Wallet`  
- Income: `TrendingUp`
- Reports: `BarChart3`
- More: `Settings`

For 5 items on small screens, reduce the label font size to `text-[9px]` and icon size to `w-5 h-5` so they fit comfortably.

---

## 5. MILES THIS WEEK STAT ON DASHBOARD

The dashboard shows net profit, total income, total expenses, total miles (all-time), and fuel cost/mile. But truckers think in weekly miles. Add a "Miles This Week" stat card.

**In `server/storage.ts`**, update `getFinancialSummary(userId, period)` to also return `weeklyMiles: number` — the sum of `loadedMiles + emptyMiles` (or odometer diff) from trips in the current week.

**In `client/src/pages/Dashboard.tsx`**, add a stat card between the existing miles card and fuel card:
- Label: "Miles This Week"
- Value: `weeklyMiles.toLocaleString()`
- Icon: `Navigation` (cyan color)
- Links to `/trips`

If `weeklyMiles === 0`, show `"—"` instead of `0`.

---

## 6. PER-TRUCK PROFIT FILTER ON DASHBOARD

The Assets (fleet) table exists but expenses have a `truckId` field that is never used for filtering. Wire it up minimally.

**In `client/src/pages/Dashboard.tsx`:**

Fetch assets with `useAssets()`. If the user has more than 1 asset, show a small truck selector dropdown at the top of the dashboard (next to the Week/Month toggle). Options: "All Trucks" + each asset name.

When a truck is selected, filter the `expenses` and `income` data passed to summary cards by `truckId`. For now, just show a filtered total — no need to change the server summary endpoint, just do it client-side from the already-loaded data.

If the user has 0 or 1 asset, don't show the selector at all.

---

## 7. IFTA QUARTER DEADLINE BANNER

IFTA filings are due quarterly: April 30, July 31, October 31, January 31.

**In `client/src/pages/Dashboard.tsx`**, add a deadline banner that appears in the 30 days before each deadline:

```tsx
// Calculate days until next IFTA deadline
function getDaysUntilIFTA(): number | null { ... }
```

If `daysUntil <= 30`, show a banner below the period toggle:
```
⚠️  IFTA Q[X] filing due in [N] days — Go to Reports
```

Style it as an amber/yellow warning card. Clicking it navigates to `/reports` and auto-opens the IFTA dialog.

If more than 30 days away, don't show anything.

---

## 8. EXPORT REMINDER IN SETTINGS

In `client/src/pages/Settings.tsx`, below the "Export All Data" button, add a small info callout:

```
💡 We recommend exporting your data monthly. Your records are stored securely, 
but a local backup is always a good idea.
```

Style it as a subtle muted info box (not alarming, just friendly).

Also: the current "Export All Data" exports JSON. Add a second button: **"Export as CSV"** that calls a new endpoint `GET /api/account/export-csv`.

**In `server/routes.ts`**, add the endpoint:
```
app.get("/api/account/export-csv", isAuthenticated, async (req, res) => {
  // Generate a multi-sheet equivalent: 
  // Send a zip or just a combined CSV with section headers
  // For simplicity: combine expenses + income into one CSV with a "type" column
  // columns: type, date, merchant/source, category, amount, paymentMethod, notes
})
```

Use the existing `downloadCSV` utility pattern on the client side.

---

## 9. INLINE NOTES ON INCOME ENTRIES

The Income page shows: source, route, amount, date. But there's a `notes` field that is never displayed.

**In `client/src/pages/Income.tsx`**, in the income list rows, if `item.notes` is present, show it as a second line in smaller muted text below the route/source info. Truncate at 60 characters with `…`.

Also: add a trailer number badge if `item.trailerNumber` is present — show it as a small pill next to the route name (e.g. `#T-101`).

---

## 10. IMPROVE THE LANDING PAGE FOR APP STORE READINESS

The current landing page is functional but doesn't sell the app. Update `client/src/pages/Landing.tsx` to be more compelling:

**Headline:** Change to:
```
Your books.
Done at the pump.
```

**Subheadline:** 
```
TruckBooks is the fastest way for owner-operators to track expenses, scan receipts, and stay IFTA & Schedule C ready — without the paperwork headache.
```

**Add a "How it works" section** (3 steps, horizontal on desktop, vertical on mobile):
1. 📸 Snap a receipt → AI reads it automatically
2. ✅ Confirm & save → Categorized for taxes
3. 📊 Export reports → Hand to your accountant

**Add 3 social proof stat pills** below the sign-in button:
- `✓ IFTA-ready reports`
- `✓ Schedule C mapped`
- `✓ Receipt scanning built in`

Keep the existing sign-in button and Replit auth flow exactly as-is. Only change the copy and visual layout around it.

---

## 11. TRUCK SELECTOR ON EXPENSE FORM (COMPLETE THE HALF-BUILT FEATURE)

The `CreateExpenseDialog` has a `truckId` field in the schema but it is not rendered in the form. Either complete it or remove it cleanly.

**Complete it:**

In `CreateExpenseDialog.tsx`, fetch assets with `useAssets()`. If assets exist, add an optional "Truck / Asset" select field to the form (below Payment Method):
- Options: a blank/none option + each asset's name
- When selected, sets `form.truckId` to the asset's id as a string

If the user has no assets, don't render the field at all (no empty selects).

This makes the per-truck filtering from fix #6 actually work end-to-end.

---

## AFTER ALL CHANGES

1. Run `npm run db:push` to apply any schema changes.
2. Run `npm run build` — fix any TypeScript errors before finishing.
3. Test the full critical path: sign in → add expense with receipt → view receipt → add income from saved route → go to Reports → export CSV → check Dashboard shows correct miles and IFTA banner if applicable.
