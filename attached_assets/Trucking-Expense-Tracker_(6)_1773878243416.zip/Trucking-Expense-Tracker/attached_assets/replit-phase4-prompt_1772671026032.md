# HaulLedger — Phase 4 Prompt

You are a senior full-stack engineer. Work through every item below in order. Do not break existing functionality. Run `npm run build` at the end and fix any TypeScript errors before finishing.

---

## 1. REBRAND: TruckBooks → HaulLedger

Replace every occurrence of "TruckBooks" and "truckbooks" across the codebase with "HaulLedger" and "haulledger". Here are all the exact locations:

**`client/src/pages/Landing.tsx`**
- `TruckBooks` (app name span, data-testid="text-app-name") → `HaulLedger`
- `TruckBooks is the fastest way...` in the subheadline → `HaulLedger is the fastest way...`
- Both copyright lines `© {year} TruckBooks. All rights reserved.` → `© {year} HaulLedger. All rights reserved.`

**`client/src/components/Sidebar.tsx`**
- The `<h1>TruckBooks</h1>` heading → `HaulLedger`

**`client/src/pages/Settings.tsx`**
- `a.download = "truckbooks-export.json"` → `"haulledger-export.json"`
- `downloadCSV("truckbooks-export.csv", ...)` → `downloadCSV("haulledger-export.csv", ...)`

**`server/routes.ts`**
- `filename=truckbooks-export.json` → `filename=haulledger-export.json`

**`replit.md`**
- `# TruckBooks - Trucking Expenses & Earnings Tracker` → `# HaulLedger - Trucking Expenses & Earnings Tracker`
- `TruckBooks is a web application...` → `HaulLedger is a web application...`

---

## 2. FIX: IFTA BANNER AUTO-OPENS THE IFTA DIALOG

The IFTA deadline banner on the Dashboard links to `/reports` but the IFTA dialog never auto-opens. Fix it end-to-end.

**In `client/src/pages/Dashboard.tsx`:**

Import `useLocation` from wouter (it is already imported — just destructure the setter). Replace the `<Link href="/reports">` wrapper inside the IFTA banner card with a button that navigates with a query param:

```tsx
const [, setLocation] = useLocation();

// Replace <Link href="/reports" className="flex items-center gap-3"> with:
<button
  onClick={() => setLocation("/reports?ifta=1")}
  className="flex items-center gap-3 w-full text-left"
  data-testid="button-ifta-banner"
>
```

**In `client/src/pages/Reports.tsx`:**

Add at the top of the component:
```tsx
import { useSearch } from "wouter";

const search = useSearch();

useEffect(() => {
  if (search.includes("ifta=1")) {
    setIftaOpen(true);
  }
}, [search]);
```

---

## 3. FIX: PER-TRUCK FILTER UPDATES STAT CARDS

When a truck is selected in the Dashboard dropdown, only "Recent Activity" currently filters. The Net Profit, Income, and Expenses stat cards must also update.

**In `client/src/pages/Dashboard.tsx`**, add computed filtered values after the data is loaded:

```tsx
const filteredExpensesList = selectedTruckId
  ? (expensesData || []).filter(e => e.truckId === String(selectedTruckId))
  : null;

// income has no truckId field, so income is never truck-filtered
const displayExpenses = filteredExpensesList
  ? filteredExpensesList.reduce((s, e) => s + Number(e.amount), 0)
  : totalExpenses;

const displayIncome = totalIncome;
const displayNetProfit = selectedTruckId
  ? displayIncome - displayExpenses
  : netProfit;
```

Use `displayExpenses`, `displayIncome`, `displayNetProfit` in the three stat cards instead of `totalExpenses`, `totalIncome`, `netProfit`.

Add a subtle label below the Net Profit heading when a truck filter is active:
```tsx
{selectedTruckId && (
  <p className="text-[10px] text-amber-400/70 mt-0.5" data-testid="text-truck-filter-label">
    Expenses filtered by truck
  </p>
)}
```

---

## 4. FIX: CSV EXPORT INCLUDES TRIPS AND FUEL ENTRIES

The "Export as CSV" in Settings only exports expenses and income. Extend it to include trips and fuel entries.

**In `client/src/pages/Settings.tsx`**, update `handleExportCSV`. After building the income rows, add:

```tsx
// Section separator + trips
rows.push({ type: "---", date: "TRIPS", merchantOrSource: "", category: "", amount: "", paymentMethod: "", notes: "" });
if (data.trips && Array.isArray(data.trips)) {
  for (const t of data.trips) {
    rows.push({
      type: "trip",
      date: t.date ? new Date(t.date).toLocaleDateString() : "",
      merchantOrSource: `${t.startLocation || ""} → ${t.endLocation || ""}`,
      category: t.jurisdiction || "",
      amount: `${(Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0)).toFixed(0)} mi`,
      paymentMethod: "",
      notes: t.notes || "",
    });
  }
}

// Section separator + fuel
rows.push({ type: "---", date: "FUEL ENTRIES", merchantOrSource: "", category: "", amount: "", paymentMethod: "", notes: "" });
if (data.fuelEntries && Array.isArray(data.fuelEntries)) {
  for (const f of data.fuelEntries) {
    rows.push({
      type: "fuel",
      date: f.date ? new Date(f.date).toLocaleDateString() : "",
      merchantOrSource: f.vendor || "",
      category: f.jurisdiction || "",
      amount: f.totalCost != null ? `-${Number(f.totalCost).toFixed(2)}` : "",
      paymentMethod: `${Number(f.gallons || 0).toFixed(1)}gal @ $${Number(f.pricePerGallon || 0).toFixed(3)}`,
      notes: f.notes || "",
    });
  }
}
```

---

## 5. DARK / LIGHT MODE TOGGLE IN SETTINGS

**Step 1 — Add light mode CSS variables in `client/src/index.css`.**

Add a `.light` class block immediately after the `:root` block:

```css
.light {
  --background: 210 20% 98%;
  --foreground: 222 47% 11%;
  --card: 0 0% 100%;
  --card-foreground: 222 47% 11%;
  --popover: 0 0% 100%;
  --popover-foreground: 222 47% 11%;
  --primary: 217 91% 50%;
  --primary-foreground: 0 0% 100%;
  --secondary: 210 20% 92%;
  --secondary-foreground: 222 47% 11%;
  --muted: 210 20% 92%;
  --muted-foreground: 215 20% 40%;
  --accent: 142 71% 38%;
  --accent-foreground: 0 0% 100%;
  --destructive: 0 72% 51%;
  --destructive-foreground: 0 0% 100%;
  --border: 214 20% 88%;
  --input: 214 20% 88%;
  --ring: 217 91% 50%;
}
```

In `client/src/App.tsx`, change the hardcoded `bg-[#0b1121]` on the layout wrapper div to `bg-background` so it responds to the theme.

**Step 2 — Create `client/src/lib/theme.tsx`:**

```tsx
import { createContext, useContext, useEffect, useState } from "react";

type Theme = "dark" | "light";

const ThemeContext = createContext<{
  theme: Theme;
  toggleTheme: () => void;
}>({ theme: "dark", toggleTheme: () => {} });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    return (localStorage.getItem("hl-theme") as Theme) || "dark";
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("dark", "light");
    root.classList.add(theme);
    localStorage.setItem("hl-theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme(t => t === "dark" ? "light" : "dark");

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
```

**Step 3 — Wrap the app in `client/src/App.tsx`:**

```tsx
import { ThemeProvider } from "@/lib/theme";

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}
```

**Step 4 — Add the toggle in `client/src/pages/Settings.tsx`:**

```tsx
import { useTheme } from "@/lib/theme";
import { Switch } from "@/components/ui/switch";
import { Sun, Moon } from "lucide-react";

const { theme, toggleTheme } = useTheme();
```

Inside the Profile card's settings list, add a new row at the bottom:

```tsx
<div className="flex items-center justify-between py-3 border-t border-white/5">
  <div className="flex items-center gap-3 text-sm">
    {theme === "dark"
      ? <Moon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
      : <Sun className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
    <span className="text-muted-foreground">Appearance</span>
    <span className="ml-auto text-white">{theme === "dark" ? "Dark" : "Light"}</span>
  </div>
  <Switch
    checked={theme === "light"}
    onCheckedChange={toggleTheme}
    className="ml-4"
    data-testid="switch-theme"
  />
</div>
```

---

## 6. MILEAGE GOALS — WEEKLY TARGET + DASHBOARD PROGRESS BAR

**Step 1 — Create `client/src/lib/userPrefs.ts`:**

```ts
export function getMilesGoal(): number {
  return parseInt(localStorage.getItem("hl-weekly-miles-goal") || "0", 10);
}
export function setMilesGoal(goal: number): void {
  localStorage.setItem("hl-weekly-miles-goal", String(goal));
}
```

**Step 2 — Add "Goals" card in `client/src/pages/Settings.tsx`**, between the Profile card and the Tools card:

```tsx
import { getMilesGoal, setMilesGoal } from "@/lib/userPrefs";
import { Target } from "lucide-react";

const [milesGoalInput, setMilesGoalInput] = useState(() => {
  const g = getMilesGoal();
  return g > 0 ? String(g) : "";
});
```

```tsx
<Card className="bg-card/30 border-white/5 rounded-2xl overflow-hidden">
  <div className="p-6 border-b border-white/5">
    <h2 className="font-display font-semibold text-white text-lg">Goals</h2>
  </div>
  <div className="p-6">
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 flex-shrink-0">
        <Target className="w-5 h-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-white font-medium text-sm">Weekly Miles Target</p>
        <p className="text-muted-foreground text-xs mt-0.5">Track progress on your dashboard</p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <Input
          type="number"
          min="0"
          placeholder="e.g. 2500"
          value={milesGoalInput}
          onChange={(e) => setMilesGoalInput(e.target.value)}
          className="w-24 border-white/10 bg-card/30 text-center"
          data-testid="input-miles-goal"
        />
        <Button
          size="sm"
          variant="outline"
          className="border-white/10"
          onClick={() => {
            const val = parseInt(milesGoalInput, 10);
            if (val > 0) {
              setMilesGoal(val);
              toast({ title: "Goal Saved", description: `Weekly target set to ${val.toLocaleString()} miles.` });
            } else {
              setMilesGoal(0);
              toast({ title: "Goal Cleared", description: "Weekly miles target removed." });
            }
          }}
          data-testid="button-save-miles-goal"
        >
          Save
        </Button>
      </div>
    </div>
  </div>
</Card>
```

**Step 3 — Update the "Miles This Week" card on the Dashboard (`client/src/pages/Dashboard.tsx`):**

```tsx
import { getMilesGoal } from "@/lib/userPrefs";
const [milesGoal] = useState(() => getMilesGoal());
```

Replace the existing "Miles This Week" card. Make it `col-span-2` so the progress bar has room. Also restructure the grid so the layout is:

- Row 1: Income | Expenses (2 cols)
- Row 2: Miles (all-time) | Fuel Cost/Mile (2 cols)
- Row 3: Miles This Week (full width, col-span-2)

```tsx
<Link
  href="/trips"
  className="glass-card rounded-2xl p-4 border border-cyan-500/20 relative overflow-hidden hover-elevate col-span-2"
  data-testid="card-weekly-miles"
>
  <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-500 w-fit mb-3">
    <Navigation className="w-5 h-5" />
  </div>
  <div className="flex items-end justify-between mb-1">
    <div>
      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
        Miles This Week
      </p>
      <h3 className="text-xl font-display font-bold text-white mt-0.5" data-testid="text-weekly-miles">
        {weeklyMiles > 0 ? weeklyMiles.toLocaleString() : "—"}
      </h3>
    </div>
    {milesGoal > 0 && (
      <span className="text-xs text-muted-foreground tabular-nums mb-1" data-testid="text-miles-goal">
        / {milesGoal.toLocaleString()} goal
      </span>
    )}
  </div>
  {milesGoal > 0 && (
    <>
      <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden mt-2">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-cyan-300 transition-all duration-500"
          style={{ width: `${Math.min(100, weeklyMiles > 0 ? (weeklyMiles / milesGoal) * 100 : 0)}%` }}
          data-testid="progress-miles-goal"
        />
      </div>
      <p className="text-[10px] text-muted-foreground/50 mt-1 text-right">
        {weeklyMiles > 0 ? `${Math.round((weeklyMiles / milesGoal) * 100)}% of weekly goal` : "No miles logged yet"}
      </p>
    </>
  )}
</Link>
```

---

## 7. QUICK ADD — ONE-TAP EXPENSE SHORTCUTS

**Step 1 — Add `quickExpenses` table to `shared/schema.ts`:**

```ts
export const quickExpenses = pgTable("quick_expenses", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  label: text("label").notNull(),
  merchant: text("merchant").notNull(),
  category: text("category").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuickExpenseSchema = createInsertSchema(quickExpenses).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export type QuickExpense = typeof quickExpenses.$inferSelect;
export type InsertQuickExpense = z.infer<typeof insertQuickExpenseSchema>;
```

**Step 2 — Add storage methods in `server/storage.ts`:**

Add to `IStorage` interface:
```ts
getQuickExpenses(userId: string): Promise<QuickExpense[]>;
createQuickExpense(data: InsertQuickExpense & { userId: string }): Promise<QuickExpense>;
deleteQuickExpense(id: number, userId: string): Promise<void>;
```

Implement all three in `DatabaseStorage` using standard drizzle queries on the `quickExpenses` table (import it from the schema).

**Step 3 — Register API routes in `server/routes.ts`:**

```ts
// GET /api/quick-expenses
app.get('/api/quick-expenses', isAuthenticated, async (req, res) => {
  try {
    res.json(await storage.getQuickExpenses(getUserId(req)));
  } catch { res.status(500).json({ message: "Failed to fetch" }); }
});

// POST /api/quick-expenses
app.post('/api/quick-expenses', isAuthenticated, async (req, res) => {
  try {
    const input = insertQuickExpenseSchema.parse(req.body);
    res.status(201).json(await storage.createQuickExpense({ ...input, userId: getUserId(req) }));
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
    res.status(500).json({ message: "Failed to create" });
  }
});

// DELETE /api/quick-expenses/:id
app.delete('/api/quick-expenses/:id', isAuthenticated, async (req, res) => {
  try {
    await storage.deleteQuickExpense(Number(req.params.id), getUserId(req));
    res.status(204).send();
  } catch { res.status(500).json({ message: "Failed to delete" }); }
});

// POST /api/quick-expenses/:id/log
app.post('/api/quick-expenses/:id/log', isAuthenticated, async (req, res) => {
  try {
    const userId = getUserId(req);
    const templates = await storage.getQuickExpenses(userId);
    const template = templates.find(t => t.id === Number(req.params.id));
    if (!template) return res.status(404).json({ message: "Template not found" });
    const expense = await storage.createExpense({
      userId,
      date: new Date(),
      merchant: template.merchant,
      category: template.category,
      amount: template.amount,
      paymentMethod: template.paymentMethod ?? undefined,
      notes: template.notes ?? undefined,
    });
    res.status(201).json(expense);
  } catch { res.status(500).json({ message: "Failed to log expense" }); }
});
```

**Step 4 — Create `client/src/hooks/use-quick-expenses.ts`:**

```ts
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const KEY = "/api/quick-expenses";

export function useQuickExpenses() {
  return useQuery({
    queryKey: [KEY],
    queryFn: async () => {
      const res = await fetch(KEY, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch quick expenses");
      return res.json();
    },
  });
}

export function useCreateQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const res = await fetch(KEY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create");
      return res.json();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [KEY] }),
  });
}

export function useDeleteQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${KEY}/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [KEY] }),
  });
}

export function useLogQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${KEY}/${id}/log`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed to log expense");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/expenses"] });
      qc.invalidateQueries({ queryKey: ["/api/summary"] });
    },
  });
}
```

**Step 5 — Add Quick Add section to the Dashboard (`client/src/pages/Dashboard.tsx`):**

```tsx
import { useQuickExpenses, useLogQuickExpense } from "@/hooks/use-quick-expenses";
import { Zap } from "lucide-react";

const { data: quickExpensesList } = useQuickExpenses();
const logQuickExpense = useLogQuickExpense();
```

Add this block between the stat cards grid and the Recent Activity card:

```tsx
{quickExpensesList && quickExpensesList.length > 0 && (
  <div>
    <div className="flex items-center justify-between mb-3">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
        <Zap className="w-3.5 h-3.5 text-amber-400" /> Quick Add
      </p>
      <Link href="/settings/quick-add" className="text-xs text-primary" data-testid="link-manage-quick-add">
        Manage
      </Link>
    </div>
    <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 snap-x" style={{ scrollbarWidth: "none" }}>
      {quickExpensesList.map((qe: any) => (
        <button
          key={qe.id}
          disabled={logQuickExpense.isPending}
          onClick={async () => {
            try {
              await logQuickExpense.mutateAsync(qe.id);
              toast({ title: "Logged!", description: `${qe.label} — $${Number(qe.amount).toFixed(2)} added.` });
            } catch {
              toast({ title: "Error", description: "Failed to log expense.", variant: "destructive" });
            }
          }}
          data-testid={`button-quick-add-${qe.id}`}
          className="flex-shrink-0 snap-start flex flex-col items-start gap-0.5 px-4 py-3 rounded-2xl bg-card/40 border border-white/10 hover:bg-card/70 hover:border-primary/30 active:scale-95 transition-all text-left min-w-[130px] disabled:opacity-50"
        >
          <span className="text-[10px] text-muted-foreground uppercase tracking-wide">{qe.category}</span>
          <span className="text-sm font-semibold truncate w-full">{qe.label}</span>
          <span className="text-base font-bold text-rose-400 tabular-nums">${Number(qe.amount).toFixed(2)}</span>
        </button>
      ))}
    </div>
  </div>
)}
```

**Step 6 — Create `client/src/pages/QuickAdd.tsx`:**

Build a full management page with:
- Page header: "Quick Add" title + subtitle "Tap a shortcut on the dashboard to instantly log a common expense."
- An inline "Add Template" form at the top of the page with fields: Label (e.g. "Morning Fuel Stop"), Merchant, Category (same EXPENSE_CATEGORIES dropdown as the expense form), Amount, Payment Method (optional). Save button uses `useCreateQuickExpense`.
- Below the form: a list of saved templates. Each row shows the label, merchant, category, and amount on the left, and a red trash button on the right that opens `ConfirmDeleteDialog` using `useDeleteQuickExpense`.
- Empty state below the form when no templates exist: show a Zap icon + "No quick add templates yet. Fill in the form above to create your first one."
- Use `useToast` for success/error feedback.

**Step 7 — Register route in `client/src/App.tsx`:**

```tsx
import QuickAdd from "@/pages/QuickAdd";
// Inside private Switch:
<Route path="/settings/quick-add" component={QuickAdd} />
```

**Step 8 — Add Quick Add link in the Settings Tools card (`client/src/pages/Settings.tsx`):**

```tsx
import { Zap } from "lucide-react";

<Link href="/settings/quick-add" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-quick-add">
  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
    <Zap className="w-5 h-5" />
  </div>
  <div className="flex-1">
    <p className="text-white font-medium text-sm">Quick Add</p>
    <p className="text-muted-foreground text-xs">Save common expenses to log in one tap</p>
  </div>
  <ChevronRight className="w-4 h-4 text-muted-foreground" />
</Link>
```

---

## 8. APP TITLE, META TAGS, AND FONT CLEANUP

Replace the entire `<head>` content in `client/index.html` with the following. This also removes the 20+ unnecessary Google Font imports that are currently bloating the page load:

```html
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
  <title>HaulLedger — Trucking Expense Tracker</title>
  <meta name="description" content="Track expenses, scan receipts, and stay IFTA & Schedule C ready. Built for owner-operators." />
  <meta name="theme-color" content="#0b1121" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-title" content="HaulLedger" />
  <link rel="icon" type="image/png" href="/favicon.png" />
  <link rel="manifest" href="/manifest.json" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
</head>
```

---

## 9. PWA MANIFEST — INSTALL TO HOME SCREEN

Create `client/public/manifest.json`:

```json
{
  "name": "HaulLedger",
  "short_name": "HaulLedger",
  "description": "Trucking expense tracker for owner-operators",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0b1121",
  "theme_color": "#0b1121",
  "orientation": "portrait-primary",
  "icons": [
    {
      "src": "/favicon.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/favicon.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}
```

---

## AFTER ALL CHANGES

1. Run `npm run db:push` to create the `quick_expenses` table.
2. Run `npm run build` — fix any TypeScript errors before finishing.
3. Verify this full critical path:
   - Browser tab shows "HaulLedger — Trucking Expense Tracker"
   - Sidebar and Landing page both say "HaulLedger"
   - Toggle light mode in Settings → entire app switches to light theme → refresh → still light
   - Set weekly miles goal in Settings → progress bar appears on Dashboard Miles This Week card
   - Go to `/settings/quick-add` → create a template → it appears as a card on the Dashboard → tap it → expense appears in Expenses with today's date
   - Tap the IFTA deadline banner on Dashboard → navigates to `/reports` AND IFTA dialog opens automatically
   - Select a truck in the Dashboard dropdown → Expenses stat card shows filtered total with "Expenses filtered by truck" label
   - Export as CSV from Settings → file has 4 sections: expenses, income, trips, fuel entries
