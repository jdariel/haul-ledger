# Trucking Expense Tracker — Full Fix Prompt

You are a senior full-stack engineer. Below is a prioritized list of fixes and improvements for this Trucking Expense Tracker app. Work through them in order. Do not break existing functionality.

---

## 1. ADD CSV EXPORT TO SCHEDULE C AND IFTA REPORTS

Currently `ScheduleCDialog.tsx` and `IFTAReportDialog.tsx` only have a Print button. Add a **Download CSV** button to both dialogs.

**ScheduleCDialog CSV** should include two sections:
- Expense rows: `Date, Merchant, Category, Schedule C Line, Amount`
- Income rows: `Date, Source, Route, Amount`
- A summary row at the bottom with `Net Profit`

**IFTAReportDialog CSV** should include:
- Fuel entries: `Date, Vendor, Jurisdiction/State, Gallons, Price Per Gallon, Total Cost`
- Trip rows: `Date, Start Location, End Location, Jurisdiction, Loaded Miles, Empty Miles, Total Miles`

Implementation: Create a `downloadCSV(filename, rows)` utility in `client/src/lib/utils.ts` that takes an array of objects and generates a CSV blob download. Use it in both dialogs.

---

## 2. FIX DUPLICATE FUEL DATA (EXPENSES vs FUEL ENTRIES)

The `expenses` table has `pricePerGallon`, `gallons`, and `jurisdiction` fields, AND there is a separate `fuelEntries` table with the same data. This causes confusion and split data.

**Fix:** When a user logs a Fuel expense in `CreateExpenseDialog.tsx` (category = "Fuel") and fills in gallons + price per gallon + jurisdiction, automatically create a corresponding `fuelEntry` record on the server so that the IFTA report stays accurate.

In `server/routes.ts`, in the POST `/api/expenses` handler: after saving the expense, check if `category === "Fuel"` and if `gallons` and `pricePerGallon` are present. If so, also call `storage.createFuelEntry(...)` with the same date, jurisdiction, gallons, pricePerGallon, totalCost (= amount), vendor (= merchant), and userId.

This way the user only has to fill out the expense form once and both tables stay in sync.

---

## 3. ADD PAYMENT METHOD FIELD TO EXPENSES

In `shared/schema.ts`, add a `paymentMethod` column to the `expenses` table:
```ts
paymentMethod: text("payment_method"), // "Cash" | "Card" | "Fuel Card" | "Check" | "Other"
```

Update `insertExpenseSchema` to include it as optional.

In `CreateExpenseDialog.tsx`, add a Select field for Payment Method with options: `Cash`, `Card`, `Fuel Card`, `Check`, `Other`. Place it below the Amount field.

In `TransactionList.tsx` and the expense detail view, display the payment method as a small badge if present.

Run the database migration after schema changes.

---

## 4. WIRE UP SAVED ROUTES → INCOME LOGGING

Currently `savedRoutes` exist but are disconnected from income. Fix this:

In `CreateIncomeDialog.tsx`, add a "Load from Saved Route" button at the top of the form. When clicked, show a small dropdown/popover listing all saved routes (fetched via the existing `useSavedRoutes()` hook). When the user picks one, auto-fill the `amount` field with the route's `price` and the `routeName` field with the route's `name`.

This removes friction for drivers who run the same lanes repeatedly.

---

## 5. DISABLE BUTTONS DURING ASYNC OPERATIONS

Several flows allow double-submits. Fix all of these:

- In `CreateExpenseDialog.tsx`: disable the Save button while `createExpense.isPending`, `updateExpense.isPending`, `isUploadingFile`, or `isProcessingReceipt` is true. Show a `Loader2` spinner inside the button when pending.
- In `CreateIncomeDialog.tsx`: disable Save while `createIncome.isPending` or `updateIncome.isPending`.
- In `ScheduleCDialog.tsx`: disable the Print and CSV buttons while the dialog data is loading.
- In `IFTAReportDialog.tsx`: same — disable Print/CSV while loading.

---

## 6. IMPROVE ERROR HANDLING ON RECEIPT UPLOAD / OCR

In `CreateExpenseDialog.tsx`, the receipt upload and OCR pipeline currently silently fails in some cases. Improve it:

- If the file upload fails, show a toast: `"Receipt upload failed. Please try again."`
- If OCR returns no data (empty result), show a toast: `"Couldn't read receipt automatically. Please fill in the fields manually."`
- If OCR partially succeeds (e.g. got merchant but not amount), still pre-fill what was found and show a toast: `"Receipt partially read — please verify the fields."`
- Never leave the form in a broken/half-filled state after an error.

---

## 7. ADD EMPTY STATES TO ALL LIST PAGES

Pages that show empty lists currently render nothing or a blank area. Add proper empty states to:

- `Expenses.tsx` — if no expenses: show a receipt icon + "No expenses yet. Tap + to log your first expense."
- `Income.tsx` — if no income: show a dollar icon + "No income logged yet. Tap + to add a load."
- `FuelLog.tsx` — if no fuel entries: show a fuel pump icon + "No fuel entries yet. Add your first fuel stop."
- `Trips.tsx` — if no trips: show a map icon + "No trips logged. Start tracking your miles."
- `Assets.tsx` — if no assets: show a truck icon + "No trucks or trailers added yet."
- `SavedRoutes.tsx` — if no routes: show a route icon + "No saved routes. Save your common lanes to log income faster."

Use consistent styling: centered, icon on top, muted description text, and a call-to-action button where appropriate.

---

## 8. FIX COST PER MILE CALCULATION ON DASHBOARD

In `server/storage.ts` (or wherever `getFinancialSummary` is computed), the `costPerMile` and `fuelCostPerMile` are likely returning 0 or NaN when there are no trips logged.

Fix:
- If `totalMiles === 0`, return `costPerMile: 0` and `fuelCostPerMile: 0` instead of dividing by zero.
- On `Dashboard.tsx`, if `totalMiles === 0`, display `costPerMile` as `"—"` instead of `$0.00` so it's clear there's no mileage data yet.

---

## 9. MAKE FUEL LOG USE THE SEPARATE FUEL ENTRIES TABLE CORRECTLY

`FuelLog.tsx` should be the canonical place to view and add dedicated fuel entries (via the `fuelEntries` table), separate from expense-category fuel records.

Ensure:
- The "Add Fuel Stop" form in `FuelLog.tsx` writes to `fuelEntries`, not `expenses`.
- The IFTA report pulls from `fuelEntries` only (not expenses with category=Fuel).
- After fix #2 above is applied, fuel expenses auto-create a `fuelEntry`, so everything flows correctly.

If `FuelLog.tsx` is currently writing to `expenses` instead of `fuelEntries`, fix the hook it calls to use `useCreateFuelEntry` from `use-fuel-entries.ts`.

---

## 10. MINOR UX POLISH

- In `BottomNav.tsx`: make sure the active tab indicator is clearly visible (bold icon + colored label, not just a subtle color shift).
- In `Dashboard.tsx`: the "+ Add" FAB dropdown should close automatically after an action is selected.
- In all dialogs: pressing the Escape key or tapping the backdrop should close the dialog (verify `onOpenChange` is wired correctly on all `Dialog` components).
- In `TransactionList.tsx`: the swipe-to-delete interaction should show a red "Delete" label as the row is swiped, not just reveal an empty area.

---

## AFTER ALL FIXES

1. Run `npm run db:push` (or the equivalent Drizzle migration command) to apply any schema changes.
2. Verify the app builds without TypeScript errors (`npm run build`).
3. Test the full expense flow: add expense with receipt → OCR fills fields → save → appears in Reports → exports correctly via CSV and Print.
