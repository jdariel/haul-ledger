import { z } from 'zod';
import { insertExpenseSchema, insertIncomeSchema, insertSavedRouteSchema, insertAssetSchema, insertTripSchema, insertFuelEntrySchema, expenses, income, savedRoutes, assets, trips, fuelEntries } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // === ASSETS ===
  assets: {
    list: {
      method: 'GET' as const,
      path: '/api/assets' as const,
      responses: {
        200: z.array(z.custom<typeof assets.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/assets/:id' as const,
      responses: {
        200: z.custom<typeof assets.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/assets' as const,
      input: insertAssetSchema,
      responses: {
        201: z.custom<typeof assets.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/assets/:id' as const,
      input: insertAssetSchema.partial(),
      responses: {
        200: z.custom<typeof assets.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/assets/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === TRIPS ===
  trips: {
    list: {
      method: 'GET' as const,
      path: '/api/trips' as const,
      responses: {
        200: z.array(z.custom<typeof trips.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/trips/:id' as const,
      responses: {
        200: z.custom<typeof trips.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/trips' as const,
      input: insertTripSchema,
      responses: {
        201: z.custom<typeof trips.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/trips/:id' as const,
      input: insertTripSchema.partial(),
      responses: {
        200: z.custom<typeof trips.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/trips/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === FUEL ENTRIES ===
  fuelEntries: {
    list: {
      method: 'GET' as const,
      path: '/api/fuel-entries' as const,
      responses: {
        200: z.array(z.custom<typeof fuelEntries.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/fuel-entries/:id' as const,
      responses: {
        200: z.custom<typeof fuelEntries.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/fuel-entries' as const,
      input: insertFuelEntrySchema,
      responses: {
        201: z.custom<typeof fuelEntries.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/fuel-entries/:id' as const,
      input: insertFuelEntrySchema.partial(),
      responses: {
        200: z.custom<typeof fuelEntries.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/fuel-entries/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === EXPENSES ===
  expenses: {
    list: {
      method: 'GET' as const,
      path: '/api/expenses' as const,
      responses: {
        200: z.array(z.custom<typeof expenses.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/expenses/:id' as const,
      responses: {
        200: z.custom<typeof expenses.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/expenses' as const,
      input: insertExpenseSchema,
      responses: {
        201: z.custom<typeof expenses.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/expenses/:id' as const,
      input: insertExpenseSchema.partial(),
      responses: {
        200: z.custom<typeof expenses.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/expenses/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === INCOME ===
  income: {
    list: {
      method: 'GET' as const,
      path: '/api/income' as const,
      responses: {
        200: z.array(z.custom<typeof income.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/income/:id' as const,
      responses: {
        200: z.custom<typeof income.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/income' as const,
      input: insertIncomeSchema,
      responses: {
        201: z.custom<typeof income.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/income/:id' as const,
      input: insertIncomeSchema.partial(),
      responses: {
        200: z.custom<typeof income.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/income/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === SAVED ROUTES ===
  savedRoutes: {
    list: {
      method: 'GET' as const,
      path: '/api/saved-routes' as const,
      responses: {
        200: z.array(z.custom<typeof savedRoutes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/saved-routes' as const,
      input: insertSavedRouteSchema,
      responses: {
        201: z.custom<typeof savedRoutes.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/saved-routes/:id' as const,
      input: insertSavedRouteSchema.partial(),
      responses: {
        200: z.custom<typeof savedRoutes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/saved-routes/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === RECEIPTS ===
  receipts: {
    process: {
      method: 'POST' as const,
      path: '/api/receipts/process' as const,
      input: z.object({
        imageUrl: z.string(),
      }),
      responses: {
        200: z.object({
          merchant: z.string().optional(),
          date: z.string().optional(),
          amount: z.number().optional(),
          category: z.string().optional(),
          notes: z.string().optional(),
          pricePerGallon: z.number().optional(),
          gallons: z.number().optional(),
          jurisdiction: z.string().optional(),
        }),
        500: errorSchemas.internal,
      },
    },
  },

  // === SUMMARY ===
  summary: {
    get: {
      method: 'GET' as const,
      path: '/api/summary' as const,
      input: z.object({
        period: z.enum(["all", "weekly", "monthly"]).optional(),
      }),
      responses: {
        200: z.object({
          totalIncome: z.number(),
          totalExpenses: z.number(),
          netProfit: z.number(),
          totalMiles: z.number(),
          costPerMile: z.number(),
          fuelCostPerMile: z.number(),
        }),
      },
    },
  },

  // === ACCOUNT ===
  account: {
    delete: {
      method: 'DELETE' as const,
      path: '/api/account' as const,
      responses: {
        204: z.void(),
        500: errorSchemas.internal,
      },
    },
    exportData: {
      method: 'GET' as const,
      path: '/api/account/export' as const,
      responses: {
        200: z.any(),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type ExpenseInput = z.infer<typeof api.expenses.create.input>;
export type IncomeInput = z.infer<typeof api.income.create.input>;
export type AssetInput = z.infer<typeof api.assets.create.input>;
export type TripInput = z.infer<typeof api.trips.create.input>;
export type FuelEntryInput = z.infer<typeof api.fuelEntries.create.input>;
