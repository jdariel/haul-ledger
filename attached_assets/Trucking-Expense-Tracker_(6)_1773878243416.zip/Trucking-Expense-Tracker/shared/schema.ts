import { pgTable, text, serial, integer, boolean, timestamp, numeric, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export * from "./models/auth";
export * from "./models/chat";
import { users } from "./models/auth";

// === ASSETS (Trucks / Trailers) ===
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // "truck" | "trailer"
  name: text("name").notNull(),
  vin: text("vin"),
  plate: text("plate"),
  year: text("year"),
  make: text("make"),
  model: text("model"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === TRIPS / MILEAGE ===
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  startLocation: text("start_location").notNull(),
  endLocation: text("end_location").notNull(),
  startOdometer: numeric("start_odometer", { precision: 10, scale: 1 }),
  endOdometer: numeric("end_odometer", { precision: 10, scale: 1 }),
  loadedMiles: numeric("loaded_miles", { precision: 8, scale: 1 }),
  emptyMiles: numeric("empty_miles", { precision: 8, scale: 1 }),
  jurisdiction: text("jurisdiction"),
  assetId: integer("asset_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === FUEL ENTRIES ===
export const fuelEntries = pgTable("fuel_entries", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  jurisdiction: text("jurisdiction").notNull(),
  gallons: numeric("gallons", { precision: 8, scale: 3 }).notNull(),
  pricePerGallon: numeric("price_per_gallon", { precision: 6, scale: 3 }).notNull(),
  totalCost: numeric("total_cost", { precision: 10, scale: 2 }).notNull(),
  vendor: text("vendor"),
  assetId: integer("asset_id"),
  receiptUrl: text("receipt_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === EXPENSES ===
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  merchant: text("merchant").notNull(),
  category: text("category").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  receiptUrl: text("receipt_url"),
  truckId: text("truck_id"),
  pricePerGallon: numeric("price_per_gallon", { precision: 6, scale: 3 }),
  gallons: numeric("gallons", { precision: 8, scale: 3 }),
  jurisdiction: text("jurisdiction"),
  paymentMethod: text("payment_method"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === INCOME ===
export const income = pgTable("income", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  source: text("source").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  trailerNumber: text("trailer_number"),
  routeName: text("route_name"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SAVED ROUTES ===
export const savedRoutes = pgTable("saved_routes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === QUICK EXPENSES (Templates) ===
export const quickExpenses = pgTable("quick_expenses", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  label: text("label").notNull(),
  merchant: text("merchant").notNull(),
  category: text("category").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuickExpenseSchema = createInsertSchema(quickExpenses).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export type QuickExpense = typeof quickExpenses.$inferSelect;
export type InsertQuickExpense = z.infer<typeof insertQuickExpenseSchema>;

// === RELATIONS ===
export const assetsRelations = relations(assets, ({ one }) => ({
  user: one(users, { fields: [assets.userId], references: [users.id] }),
}));

export const tripsRelations = relations(trips, ({ one }) => ({
  user: one(users, { fields: [trips.userId], references: [users.id] }),
}));

export const fuelEntriesRelations = relations(fuelEntries, ({ one }) => ({
  user: one(users, { fields: [fuelEntries.userId], references: [users.id] }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  user: one(users, { fields: [expenses.userId], references: [users.id] }),
}));

export const incomeRelations = relations(income, ({ one }) => ({
  user: one(users, { fields: [income.userId], references: [users.id] }),
}));

export const savedRoutesRelations = relations(savedRoutes, ({ one }) => ({
  user: one(users, { fields: [savedRoutes.userId], references: [users.id] }),
}));

// === ZOD SCHEMAS ===
export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export const insertTripSchema = createInsertSchema(trips, {
  date: z.coerce.date(),
  startOdometer: z.union([z.coerce.number().nonnegative(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  endOdometer: z.union([z.coerce.number().nonnegative(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  loadedMiles: z.union([z.coerce.number().nonnegative(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  emptyMiles: z.union([z.coerce.number().nonnegative(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  assetId: z.union([z.coerce.number(), z.null(), z.undefined()]).optional().transform(v => v === null ? undefined : v),
}).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export const insertFuelEntrySchema = createInsertSchema(fuelEntries, {
  date: z.coerce.date(),
  gallons: z.coerce.number().positive("Gallons must be greater than 0"),
  pricePerGallon: z.coerce.number().nonnegative("Price per gallon must be 0 or more"),
  totalCost: z.coerce.number().nonnegative("Total cost must be 0 or more"),
  assetId: z.union([z.coerce.number(), z.null(), z.undefined()]).optional().transform(v => v === null ? undefined : v),
}).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export const insertExpenseSchema = createInsertSchema(expenses, {
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  date: z.coerce.date(),
  pricePerGallon: z.union([z.coerce.number().positive(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  gallons: z.union([z.coerce.number().positive(), z.literal(""), z.null(), z.undefined()]).optional().transform(v => (v === "" || v === null) ? undefined : v),
  jurisdiction: z.union([z.string(), z.null(), z.undefined()]).optional().transform(v => v === null ? undefined : v),
  paymentMethod: z.union([z.string(), z.null(), z.undefined()]).optional().transform(v => v === null ? undefined : v),
}).omit({ 
  id: true, 
  createdAt: true,
  userId: true 
});

export const insertIncomeSchema = createInsertSchema(income, {
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  date: z.coerce.date(),
}).omit({ 
  id: true, 
  createdAt: true,
  userId: true 
});

export const insertSavedRouteSchema = createInsertSchema(savedRoutes, {
  price: z.coerce.number().positive("Price must be greater than 0"),
}).omit({
  id: true,
  createdAt: true,
  userId: true,
});

// === TYPES ===
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;

export type Trip = typeof trips.$inferSelect;
export type InsertTrip = z.infer<typeof insertTripSchema>;

export type FuelEntry = typeof fuelEntries.$inferSelect;
export type InsertFuelEntry = z.infer<typeof insertFuelEntrySchema>;

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;

export type Income = typeof income.$inferSelect;
export type InsertIncome = z.infer<typeof insertIncomeSchema>;

export type SavedRoute = typeof savedRoutes.$inferSelect;
export type InsertSavedRoute = z.infer<typeof insertSavedRouteSchema>;

export type CreateExpenseRequest = InsertExpense;
export type UpdateExpenseRequest = Partial<InsertExpense>;

export type CreateIncomeRequest = InsertIncome;
export type UpdateIncomeRequest = Partial<InsertIncome>;

// OCR Response Type
export interface ReceiptData {
  merchant?: string;
  date?: string;
  amount?: number;
  category?: string;
  pricePerGallon?: number;
  gallons?: number;
  jurisdiction?: string;
}

// Reports/Summary Type
export interface FinancialSummary {
  totalIncome: number;
  totalExpenses: number;
  netProfit: number;
  totalMiles: number;
  weeklyMiles: number;
  costPerMile: number;
  fuelCostPerMile: number;
}

// US State codes for jurisdiction validation
export const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
  "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
  "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY","DC",
  "AB","BC","MB","NB","NL","NS","NT","NU","ON","PE","QC","SK","YT"
] as const;
