import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { insertQuickExpenseSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replit_integrations/auth";
import { registerAuthRoutes } from "./replit_integrations/auth";
import OpenAI from "openai";

import { registerObjectStorageRoutes, ObjectStorageService } from "./replit_integrations/object_storage";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

function getUserId(req: any): string {
  return req.user?.claims?.sub;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  await setupAuth(app);
  registerAuthRoutes(app);
  registerObjectStorageRoutes(app);
  const objectStorageService = new ObjectStorageService();

  // === ASSETS ROUTES ===
  app.get(api.assets.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getAssets(getUserId(req)));
  });
  app.get(api.assets.get.path, isAuthenticated, async (req, res) => {
    const asset = await storage.getAsset(Number(req.params.id), getUserId(req));
    if (!asset) return res.status(404).json({ message: "Asset not found" });
    res.json(asset);
  });
  app.post(api.assets.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.assets.create.input.parse(req.body);
      res.status(201).json(await storage.createAsset({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.assets.update.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.assets.update.input.parse(req.body);
      const asset = await storage.updateAsset(Number(req.params.id), getUserId(req), input);
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      res.json(asset);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.assets.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteAsset(Number(req.params.id), getUserId(req));
    res.status(204).send();
  });

  // === TRIPS ROUTES ===
  app.get(api.trips.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getTrips(getUserId(req)));
  });
  app.get(api.trips.get.path, isAuthenticated, async (req, res) => {
    const trip = await storage.getTrip(Number(req.params.id), getUserId(req));
    if (!trip) return res.status(404).json({ message: "Trip not found" });
    res.json(trip);
  });
  app.post(api.trips.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.trips.create.input.parse(req.body);
      res.status(201).json(await storage.createTrip({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.trips.update.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.trips.update.input.parse(req.body);
      const trip = await storage.updateTrip(Number(req.params.id), getUserId(req), input);
      if (!trip) return res.status(404).json({ message: "Trip not found" });
      res.json(trip);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.trips.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteTrip(Number(req.params.id), getUserId(req));
    res.status(204).send();
  });

  // === FUEL ENTRIES ROUTES ===
  app.get(api.fuelEntries.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getFuelEntries(getUserId(req)));
  });
  app.get(api.fuelEntries.get.path, isAuthenticated, async (req, res) => {
    const entry = await storage.getFuelEntry(Number(req.params.id), getUserId(req));
    if (!entry) return res.status(404).json({ message: "Fuel entry not found" });
    res.json(entry);
  });
  app.post(api.fuelEntries.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.fuelEntries.create.input.parse(req.body);
      res.status(201).json(await storage.createFuelEntry({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.fuelEntries.update.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.fuelEntries.update.input.parse(req.body);
      const entry = await storage.updateFuelEntry(Number(req.params.id), getUserId(req), input);
      if (!entry) return res.status(404).json({ message: "Fuel entry not found" });
      res.json(entry);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.fuelEntries.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteFuelEntry(Number(req.params.id), getUserId(req));
    res.status(204).send();
  });

  // === EXPENSES ROUTES ===
  app.get(api.expenses.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getExpenses(getUserId(req)));
  });
  app.get(api.expenses.get.path, isAuthenticated, async (req, res) => {
    const expense = await storage.getExpense(Number(req.params.id));
    if (!expense) return res.status(404).json({ message: "Expense not found" });
    res.json(expense);
  });
  app.post(api.expenses.create.path, isAuthenticated, async (req, res) => {
    try {
      const bodySchema = api.expenses.create.input.extend({ amount: z.coerce.number() });
      const input = bodySchema.parse(req.body);
      const userId = getUserId(req);
      const expense = await storage.createExpense({ ...input, userId });

      if (input.category === "Fuel" && input.gallons && input.pricePerGallon) {
        try {
          const fuelData: any = {
            date: input.date,
            gallons: Number(input.gallons),
            pricePerGallon: Number(input.pricePerGallon),
            totalCost: Number(input.amount),
            vendor: input.merchant || "",
            jurisdiction: input.jurisdiction || "",
            notes: input.notes || "",
            userId,
          };
          if (input.truckId) fuelData.assetId = input.truckId;
          await storage.createFuelEntry(fuelData);
        } catch (fuelErr) {
          console.error("Failed to auto-create fuel entry:", fuelErr);
        }
      }

      res.status(201).json(expense);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.expenses.update.path, isAuthenticated, async (req, res) => {
    try {
      const bodySchema = api.expenses.update.input.extend({ amount: z.coerce.number().optional() });
      const input = bodySchema.parse(req.body);
      const expense = await storage.updateExpense(Number(req.params.id), input);
      if (!expense) return res.status(404).json({ message: "Expense not found" });
      res.json(expense);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.expenses.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteExpense(Number(req.params.id));
    res.status(204).send();
  });

  // === INCOME ROUTES ===
  app.get(api.income.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getIncome(getUserId(req)));
  });
  app.get(api.income.get.path, isAuthenticated, async (req, res) => {
    const item = await storage.getIncomeItem(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Income not found" });
    res.json(item);
  });
  app.post(api.income.create.path, isAuthenticated, async (req, res) => {
    try {
      const bodySchema = api.income.create.input.extend({ amount: z.coerce.number() });
      const input = bodySchema.parse(req.body);
      res.status(201).json(await storage.createIncome({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.income.update.path, isAuthenticated, async (req, res) => {
    try {
      const bodySchema = api.income.update.input.extend({ amount: z.coerce.number().optional() });
      const input = bodySchema.parse(req.body);
      const item = await storage.updateIncome(Number(req.params.id), input);
      if (!item) return res.status(404).json({ message: "Income not found" });
      res.json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.income.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteIncome(Number(req.params.id));
    res.status(204).send();
  });

  // === SAVED ROUTES ===
  app.get(api.savedRoutes.list.path, isAuthenticated, async (req, res) => {
    res.json(await storage.getSavedRoutes(getUserId(req)));
  });
  app.post(api.savedRoutes.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.savedRoutes.create.input.parse(req.body);
      res.status(201).json(await storage.createSavedRoute({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.put(api.savedRoutes.update.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.savedRoutes.update.input.parse(req.body);
      const route = await storage.updateSavedRoute(Number(req.params.id), getUserId(req), input);
      if (!route) return res.status(404).json({ message: "Saved route not found" });
      res.json(route);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      throw err;
    }
  });
  app.delete(api.savedRoutes.delete.path, isAuthenticated, async (req, res) => {
    await storage.deleteSavedRoute(Number(req.params.id), getUserId(req));
    res.status(204).send();
  });

  // === QUICK EXPENSES ===
  app.get('/api/quick-expenses', isAuthenticated, async (req, res) => {
    try {
      res.json(await storage.getQuickExpenses(getUserId(req)));
    } catch { res.status(500).json({ message: "Failed to fetch" }); }
  });

  app.post('/api/quick-expenses', isAuthenticated, async (req, res) => {
    try {
      const input = insertQuickExpenseSchema.parse(req.body);
      res.status(201).json(await storage.createQuickExpense({ ...input, userId: getUserId(req) }));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Failed to create" });
    }
  });

  app.delete('/api/quick-expenses/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteQuickExpense(Number(req.params.id), getUserId(req));
      res.status(204).send();
    } catch { res.status(500).json({ message: "Failed to delete" }); }
  });

  app.post('/api/quick-expenses/:id/log', isAuthenticated, async (req, res) => {
    try {
      const userId = getUserId(req);
      const templates = await storage.getQuickExpenses(userId);
      const template = templates.find(t => t.id === Number(req.params.id));
      if (!template) return res.status(404).json({ message: "Template not found" });
      const expense = await storage.createExpense({
        userId,
        date: new Date(),
        merchant: template.merchant,
        category: template.category,
        amount: template.amount,
        paymentMethod: template.paymentMethod ?? undefined,
        notes: template.notes ?? undefined,
      });
      res.status(201).json(expense);
    } catch { res.status(500).json({ message: "Failed to log expense" }); }
  });

  // === SUMMARY ===
  app.get(api.summary.get.path, isAuthenticated, async (req, res) => {
    const period = req.query.period as string | undefined;
    res.json(await storage.getSummary(getUserId(req), period));
  });

  // === ACCOUNT ===
  app.delete(api.account.delete.path, isAuthenticated, async (req, res) => {
    try {
      await storage.deleteAllUserData(getUserId(req));
      req.logout(() => {
        res.status(204).send();
      });
    } catch (err) {
      res.status(500).json({ message: "Failed to delete account data" });
    }
  });

  app.get(api.account.exportData.path, isAuthenticated, async (req, res) => {
    try {
      const data = await storage.exportAllUserData(getUserId(req));
      res.setHeader("Content-Disposition", "attachment; filename=haulledger-export.json");
      res.json(data);
    } catch (err) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  // === RECEIPT OCR ===
  app.post(api.receipts.process.path, isAuthenticated, async (req, res) => {
    try {
      const { imageUrl } = req.body;

      if (!imageUrl) {
        return res.status(400).json({ message: "No image provided" });
      }

      let imageContent: string = imageUrl;
      if (imageUrl.startsWith("data:")) {
        const match = imageUrl.match(/^data:(image\/\w+);base64,/);
        if (!match) {
          return res.status(400).json({ message: "Invalid image format" });
        }
        imageContent = imageUrl;
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: `Analyze this receipt image and extract the following information:
1. merchant: the merchant/business name
2. date: the date in YYYY-MM-DD format
3. amount: total amount as a number
4. category: suggest the most appropriate category from: Fuel, Repairs, Maintenance, Insurance, Taxes & Licenses, Supplies, Travel, Utilities, Rent/Lease, Other
5. notes: a concise, organized summary of the receipt. Include:
   - Items purchased (list each with price if visible)
   - Payment method (cash, card ending in XXXX, etc.) if visible
   - Location/address if visible
   - Any relevant details like invoice number, pump number, odometer reading
   Format as clean short lines separated by " | " (pipe with spaces). Example: "Diesel fuel, Pump #7 | 1234 Main St, Dallas TX | Visa ending 4821 | Odometer: 245,890"

If this is a FUEL/GAS receipt, also extract:
6. pricePerGallon: the price per gallon as a number (e.g. 3.459)
7. gallons: the number of gallons purchased as a number
8. jurisdiction: the state or jurisdiction where the fuel was purchased (use 2-letter state code if in the US, e.g. "TX", "CA")

Return only a JSON object with these keys: merchant, date, amount, category, notes, pricePerGallon, gallons, jurisdiction. For non-fuel receipts, omit the fuel fields or set them to null.` },
              { type: "image_url", image_url: { url: imageContent, detail: "low" } },
            ],
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });

      const content = response.choices[0].message.content;
      if (!content) throw new Error("No analysis returned");
      
      const data = JSON.parse(content);
      
      let amount = data.amount || data.total || data.totalAmount;
      if (typeof amount === 'string') {
        amount = parseFloat(amount.replace(/[^0-9.]/g, ''));
      }

      let pricePerGallon = data.pricePerGallon || data.price_per_gallon;
      if (typeof pricePerGallon === 'string') {
        pricePerGallon = parseFloat(pricePerGallon.replace(/[^0-9.]/g, ''));
      }

      let gallons = data.gallons || data.numberOfGallons;
      if (typeof gallons === 'string') {
        gallons = parseFloat(gallons.replace(/[^0-9.]/g, ''));
      }

      res.json({
        merchant: data.merchant || data.merchantName,
        date: data.date,
        amount: amount,
        category: data.category,
        notes: data.notes || undefined,
        pricePerGallon: pricePerGallon || undefined,
        gallons: gallons || undefined,
        jurisdiction: data.jurisdiction || data.state || undefined,
      });

    } catch (error: any) {
      console.error("OCR Error:", error?.message || error);
      if (error?.status) console.error("OCR Status:", error.status);
      if (error?.error) console.error("OCR Detail:", JSON.stringify(error.error));
      res.status(500).json({ message: "Failed to process receipt" });
    }
  });

  return httpServer;
}
