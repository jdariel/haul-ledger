import { db } from "./db";
import {
  expenses, income, savedRoutes, assets, trips, fuelEntries, quickExpenses,
  type InsertExpense, type InsertIncome, type InsertSavedRoute,
  type InsertAsset, type InsertTrip, type InsertFuelEntry, type InsertQuickExpense,
  type Expense, type Income, type SavedRoute,
  type Asset, type Trip, type FuelEntry, type QuickExpense,
  type FinancialSummary
} from "@shared/schema";
import { eq, desc, and, sum, sql, gte } from "drizzle-orm";

export interface IStorage {
  // Assets
  getAssets(userId: string): Promise<Asset[]>;
  getAsset(id: number, userId: string): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset & { userId: string }): Promise<Asset>;
  updateAsset(id: number, userId: string, updates: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: number, userId: string): Promise<void>;

  // Trips
  getTrips(userId: string): Promise<Trip[]>;
  getTrip(id: number, userId: string): Promise<Trip | undefined>;
  createTrip(trip: InsertTrip & { userId: string }): Promise<Trip>;
  updateTrip(id: number, userId: string, updates: Partial<InsertTrip>): Promise<Trip | undefined>;
  deleteTrip(id: number, userId: string): Promise<void>;

  // Fuel Entries
  getFuelEntries(userId: string): Promise<FuelEntry[]>;
  getFuelEntry(id: number, userId: string): Promise<FuelEntry | undefined>;
  createFuelEntry(entry: InsertFuelEntry & { userId: string }): Promise<FuelEntry>;
  updateFuelEntry(id: number, userId: string, updates: Partial<InsertFuelEntry>): Promise<FuelEntry | undefined>;
  deleteFuelEntry(id: number, userId: string): Promise<void>;

  // Expenses
  getExpenses(userId: string): Promise<Expense[]>;
  getExpense(id: number): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense & { userId: string }): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<void>;

  // Income
  getIncome(userId: string): Promise<Income[]>;
  getIncomeItem(id: number): Promise<Income | undefined>;
  createIncome(item: InsertIncome & { userId: string }): Promise<Income>;
  updateIncome(id: number, item: Partial<InsertIncome>): Promise<Income | undefined>;
  deleteIncome(id: number): Promise<void>;

  // Saved Routes
  getSavedRoutes(userId: string): Promise<SavedRoute[]>;
  createSavedRoute(route: InsertSavedRoute & { userId: string }): Promise<SavedRoute>;
  updateSavedRoute(id: number, userId: string, updates: Partial<InsertSavedRoute>): Promise<SavedRoute | undefined>;
  deleteSavedRoute(id: number, userId: string): Promise<void>;

  // Quick Expenses
  getQuickExpenses(userId: string): Promise<QuickExpense[]>;
  createQuickExpense(data: InsertQuickExpense & { userId: string }): Promise<QuickExpense>;
  deleteQuickExpense(id: number, userId: string): Promise<void>;

  // Summary
  getSummary(userId: string, period?: string): Promise<FinancialSummary>;

  // Account
  deleteAllUserData(userId: string): Promise<void>;
  exportAllUserData(userId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // === Assets ===
  async getAssets(userId: string): Promise<Asset[]> {
    return await db.select().from(assets).where(eq(assets.userId, userId)).orderBy(desc(assets.createdAt));
  }
  async getAsset(id: number, userId: string): Promise<Asset | undefined> {
    const [asset] = await db.select().from(assets).where(and(eq(assets.id, id), eq(assets.userId, userId)));
    return asset;
  }
  async createAsset(asset: InsertAsset & { userId: string }): Promise<Asset> {
    const [newAsset] = await db.insert(assets).values(asset).returning();
    return newAsset;
  }
  async updateAsset(id: number, userId: string, updates: Partial<InsertAsset>): Promise<Asset | undefined> {
    const [updated] = await db.update(assets).set(updates).where(and(eq(assets.id, id), eq(assets.userId, userId))).returning();
    return updated;
  }
  async deleteAsset(id: number, userId: string): Promise<void> {
    await db.delete(assets).where(and(eq(assets.id, id), eq(assets.userId, userId)));
  }

  // === Trips ===
  async getTrips(userId: string): Promise<Trip[]> {
    return await db.select().from(trips).where(eq(trips.userId, userId)).orderBy(desc(trips.date));
  }
  async getTrip(id: number, userId: string): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(and(eq(trips.id, id), eq(trips.userId, userId)));
    return trip;
  }
  async createTrip(trip: InsertTrip & { userId: string }): Promise<Trip> {
    const [newTrip] = await db.insert(trips).values(trip).returning();
    return newTrip;
  }
  async updateTrip(id: number, userId: string, updates: Partial<InsertTrip>): Promise<Trip | undefined> {
    const [updated] = await db.update(trips).set(updates).where(and(eq(trips.id, id), eq(trips.userId, userId))).returning();
    return updated;
  }
  async deleteTrip(id: number, userId: string): Promise<void> {
    await db.delete(trips).where(and(eq(trips.id, id), eq(trips.userId, userId)));
  }

  // === Fuel Entries ===
  async getFuelEntries(userId: string): Promise<FuelEntry[]> {
    return await db.select().from(fuelEntries).where(eq(fuelEntries.userId, userId)).orderBy(desc(fuelEntries.date));
  }
  async getFuelEntry(id: number, userId: string): Promise<FuelEntry | undefined> {
    const [entry] = await db.select().from(fuelEntries).where(and(eq(fuelEntries.id, id), eq(fuelEntries.userId, userId)));
    return entry;
  }
  async createFuelEntry(entry: InsertFuelEntry & { userId: string }): Promise<FuelEntry> {
    const [newEntry] = await db.insert(fuelEntries).values(entry).returning();
    return newEntry;
  }
  async updateFuelEntry(id: number, userId: string, updates: Partial<InsertFuelEntry>): Promise<FuelEntry | undefined> {
    const [updated] = await db.update(fuelEntries).set(updates).where(and(eq(fuelEntries.id, id), eq(fuelEntries.userId, userId))).returning();
    return updated;
  }
  async deleteFuelEntry(id: number, userId: string): Promise<void> {
    await db.delete(fuelEntries).where(and(eq(fuelEntries.id, id), eq(fuelEntries.userId, userId)));
  }

  // === Expenses ===
  async getExpenses(userId: string): Promise<Expense[]> {
    return await db.select().from(expenses).where(eq(expenses.userId, userId)).orderBy(desc(expenses.date));
  }
  async getExpense(id: number): Promise<Expense | undefined> {
    const [expense] = await db.select().from(expenses).where(eq(expenses.id, id));
    return expense;
  }
  async createExpense(expense: InsertExpense & { userId: string }): Promise<Expense> {
    const [newExpense] = await db.insert(expenses).values(expense).returning();
    return newExpense;
  }
  async updateExpense(id: number, updates: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updated] = await db.update(expenses).set(updates).where(eq(expenses.id, id)).returning();
    return updated;
  }
  async deleteExpense(id: number): Promise<void> {
    await db.delete(expenses).where(eq(expenses.id, id));
  }

  // === Income ===
  async getIncome(userId: string): Promise<Income[]> {
    return await db.select().from(income).where(eq(income.userId, userId)).orderBy(desc(income.date));
  }
  async getIncomeItem(id: number): Promise<Income | undefined> {
    const [item] = await db.select().from(income).where(eq(income.id, id));
    return item;
  }
  async createIncome(item: InsertIncome & { userId: string }): Promise<Income> {
    const [newItem] = await db.insert(income).values(item).returning();
    return newItem;
  }
  async updateIncome(id: number, updates: Partial<InsertIncome>): Promise<Income | undefined> {
    const [updated] = await db.update(income).set(updates).where(eq(income.id, id)).returning();
    return updated;
  }
  async deleteIncome(id: number): Promise<void> {
    await db.delete(income).where(eq(income.id, id));
  }

  // === Saved Routes ===
  async getSavedRoutes(userId: string): Promise<SavedRoute[]> {
    return await db.select().from(savedRoutes).where(eq(savedRoutes.userId, userId)).orderBy(desc(savedRoutes.createdAt));
  }
  async createSavedRoute(route: InsertSavedRoute & { userId: string }): Promise<SavedRoute> {
    const [newRoute] = await db.insert(savedRoutes).values(route).returning();
    return newRoute;
  }
  async updateSavedRoute(id: number, userId: string, updates: Partial<InsertSavedRoute>): Promise<SavedRoute | undefined> {
    const [updated] = await db.update(savedRoutes).set(updates).where(and(eq(savedRoutes.id, id), eq(savedRoutes.userId, userId))).returning();
    return updated;
  }
  async deleteSavedRoute(id: number, userId: string): Promise<void> {
    await db.delete(savedRoutes).where(and(eq(savedRoutes.id, id), eq(savedRoutes.userId, userId)));
  }

  // === Quick Expenses ===
  async getQuickExpenses(userId: string): Promise<QuickExpense[]> {
    return await db.select().from(quickExpenses).where(eq(quickExpenses.userId, userId)).orderBy(desc(quickExpenses.createdAt));
  }
  async createQuickExpense(data: InsertQuickExpense & { userId: string }): Promise<QuickExpense> {
    const [created] = await db.insert(quickExpenses).values(data).returning();
    return created;
  }
  async deleteQuickExpense(id: number, userId: string): Promise<void> {
    await db.delete(quickExpenses).where(and(eq(quickExpenses.id, id), eq(quickExpenses.userId, userId)));
  }

  // === Summary ===
  async getSummary(userId: string, period?: string): Promise<FinancialSummary> {
    let startDate: Date | undefined;
    if (period && period !== "all") {
      const now = new Date();
      if (period === "weekly") {
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      } else {
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      }
    }

    const incomeWhere = startDate
      ? and(eq(income.userId, userId), gte(income.date, startDate))
      : eq(income.userId, userId);
    const expenseWhere = startDate
      ? and(eq(expenses.userId, userId), gte(expenses.date, startDate))
      : eq(expenses.userId, userId);
    const tripsWhere = startDate
      ? and(eq(trips.userId, userId), gte(trips.date, startDate))
      : eq(trips.userId, userId);
    const fuelWhere = startDate
      ? and(eq(fuelEntries.userId, userId), gte(fuelEntries.date, startDate))
      : eq(fuelEntries.userId, userId);

    const [incomeResult] = await db.select({ total: sum(income.amount) }).from(income).where(incomeWhere);
    const [expenseResult] = await db.select({ total: sum(expenses.amount) }).from(expenses).where(expenseWhere);

    const tripRows = await db.select({
      startOdo: trips.startOdometer,
      endOdo: trips.endOdometer,
      loadedMiles: trips.loadedMiles,
      emptyMiles: trips.emptyMiles,
    }).from(trips).where(tripsWhere);

    let totalMiles = 0;
    tripRows.forEach(t => {
      if (t.startOdo && t.endOdo) {
        totalMiles += Number(t.endOdo) - Number(t.startOdo);
      } else {
        totalMiles += Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0);
      }
    });

    const [fuelResult] = await db.select({ total: sum(fuelEntries.totalCost) }).from(fuelEntries).where(fuelWhere);

    const now = new Date();
    const dayOfWeek = now.getDay();
    const startOfWeekDate = new Date(now);
    startOfWeekDate.setDate(now.getDate() - dayOfWeek);
    startOfWeekDate.setHours(0, 0, 0, 0);

    const weeklyTripRows = await db.select({
      startOdo: trips.startOdometer,
      endOdo: trips.endOdometer,
      loadedMiles: trips.loadedMiles,
      emptyMiles: trips.emptyMiles,
    }).from(trips).where(and(eq(trips.userId, userId), gte(trips.date, startOfWeekDate)));

    let weeklyMiles = 0;
    weeklyTripRows.forEach(t => {
      if (t.startOdo && t.endOdo) {
        weeklyMiles += Number(t.endOdo) - Number(t.startOdo);
      } else {
        weeklyMiles += Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0);
      }
    });

    const totalIncome = Number(incomeResult?.total || 0);
    const totalExpenses = Number(expenseResult?.total || 0);
    const totalFuelCost = Number(fuelResult?.total || 0);
    const netProfit = totalIncome - totalExpenses;
    const costPerMile = totalMiles > 0 ? totalExpenses / totalMiles : 0;
    const fuelCostPerMile = totalMiles > 0 ? totalFuelCost / totalMiles : 0;

    return { totalIncome, totalExpenses, netProfit, totalMiles, weeklyMiles, costPerMile, fuelCostPerMile };
  }

  // === Account ===
  async deleteAllUserData(userId: string): Promise<void> {
    await db.delete(quickExpenses).where(eq(quickExpenses.userId, userId));
    await db.delete(fuelEntries).where(eq(fuelEntries.userId, userId));
    await db.delete(trips).where(eq(trips.userId, userId));
    await db.delete(assets).where(eq(assets.userId, userId));
    await db.delete(expenses).where(eq(expenses.userId, userId));
    await db.delete(income).where(eq(income.userId, userId));
    await db.delete(savedRoutes).where(eq(savedRoutes.userId, userId));
  }

  async exportAllUserData(userId: string): Promise<any> {
    const [userExpenses, userIncome, userTrips, userFuelEntries, userAssets, userRoutes] = await Promise.all([
      db.select().from(expenses).where(eq(expenses.userId, userId)),
      db.select().from(income).where(eq(income.userId, userId)),
      db.select().from(trips).where(eq(trips.userId, userId)),
      db.select().from(fuelEntries).where(eq(fuelEntries.userId, userId)),
      db.select().from(assets).where(eq(assets.userId, userId)),
      db.select().from(savedRoutes).where(eq(savedRoutes.userId, userId)),
    ]);
    return {
      exportedAt: new Date().toISOString(),
      expenses: userExpenses,
      income: userIncome,
      trips: userTrips,
      fuelEntries: userFuelEntries,
      assets: userAssets,
      savedRoutes: userRoutes,
    };
  }
}

export const storage = new DatabaseStorage();
