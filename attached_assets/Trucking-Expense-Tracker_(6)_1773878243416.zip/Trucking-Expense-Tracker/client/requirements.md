## Packages
recharts | For financial charts (bar/pie) on the dashboard and reports
framer-motion | For page transitions and smooth UI animations
date-fns | For date formatting and manipulation
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes
lucide-react | Icon set (already in base stack, but noting usage)

## Notes
The app uses Replit Auth.
API routes are defined in @shared/routes.
Receipt processing uses a mock/AI integration endpoint.
Mobile-first design approach.
