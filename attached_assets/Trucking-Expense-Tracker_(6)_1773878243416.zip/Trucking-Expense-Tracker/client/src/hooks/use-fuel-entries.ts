import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type FuelEntryInput } from "@shared/routes";

export function useFuelEntries() {
  return useQuery({
    queryKey: [api.fuelEntries.list.path],
    queryFn: async () => {
      const res = await fetch(api.fuelEntries.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch fuel entries");
      return res.json();
    },
  });
}

export function useCreateFuelEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: FuelEntryInput) => {
      const res = await fetch(api.fuelEntries.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Failed"); }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.fuelEntries.list.path] });
      qc.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}

export function useUpdateFuelEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<FuelEntryInput>) => {
      const url = buildUrl(api.fuelEntries.update.path, { id });
      const res = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update fuel entry");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.fuelEntries.list.path] });
      qc.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}

export function useDeleteFuelEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.fuelEntries.delete.path, { id });
      const res = await fetch(url, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete fuel entry");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.fuelEntries.list.path] });
      qc.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}
