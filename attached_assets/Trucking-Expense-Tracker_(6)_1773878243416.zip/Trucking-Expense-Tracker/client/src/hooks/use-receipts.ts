import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useProcessReceipt() {
  return useMutation({
    mutationFn: async (imageUrl: string) => {
      const res = await fetch(api.receipts.process.path, {
        method: api.receipts.process.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageUrl }),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error("Failed to process receipt");
      }
      return api.receipts.process.responses[200].parse(await res.json());
    },
  });
}
