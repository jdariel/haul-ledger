import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { savedRoutes } from "@shared/schema";

type SavedRoute = typeof savedRoutes.$inferSelect;

export function useSavedRoutes() {
  return useQuery<SavedRoute[]>({
    queryKey: [api.savedRoutes.list.path],
    queryFn: async () => {
      const res = await fetch(api.savedRoutes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch saved routes");
      return res.json();
    },
  });
}

export function useCreateSavedRoute() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { name: string; source: string; trailerNumber?: string; routeName?: string; notes?: string }) => {
      const res = await fetch(api.savedRoutes.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create saved route");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.savedRoutes.list.path] });
    },
  });
}

export function useUpdateSavedRoute() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number; name?: string; source?: string; trailerNumber?: string; routeName?: string; notes?: string }) => {
      const url = buildUrl(api.savedRoutes.update.path, { id });
      const res = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update saved route");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.savedRoutes.list.path] });
    },
  });
}

export function useDeleteSavedRoute() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.savedRoutes.delete.path, { id });
      const res = await fetch(url, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete saved route");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.savedRoutes.list.path] });
    },
  });
}
