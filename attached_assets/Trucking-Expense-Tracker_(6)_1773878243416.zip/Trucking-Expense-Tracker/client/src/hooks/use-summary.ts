import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useFinancialSummary(period: string = "all") {
  return useQuery({
    queryKey: [api.summary.get.path, period],
    queryFn: async () => {
      const url = new URL(api.summary.get.path, window.location.origin);
      if (period !== "all") {
        url.searchParams.set("period", period);
      }
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch summary");
      return res.json();
    },
  });
}
