import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type IncomeInput } from "@shared/routes";
import { income } from "@shared/schema";

type Income = typeof income.$inferSelect;

export function useIncomeList() {
  return useQuery({
    queryKey: [api.income.list.path],
    queryFn: async () => {
      const res = await fetch(api.income.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch income records");
      return api.income.list.responses[200].parse(await res.json());
    },
  });
}

export function useIncome(id: number) {
  return useQuery({
    queryKey: [api.income.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.income.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch income record");
      return api.income.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateIncome() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: IncomeInput) => {
      const parsedData = { ...data, amount: Number(data.amount) };
      const validated = api.income.create.input.parse(parsedData);
      
      const res = await fetch(api.income.create.path, {
        method: api.income.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to create income record");
      return api.income.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.income.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}

export function useUpdateIncome() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<IncomeInput>) => {
      const parsedUpdates = updates.amount !== undefined 
        ? { ...updates, amount: Number(updates.amount) }
        : updates;
        
      const validated = api.income.update.input.parse(parsedUpdates);
      const url = buildUrl(api.income.update.path, { id });
      
      const res = await fetch(url, {
        method: api.income.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to update income record");
      return api.income.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.income.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}

export function useDeleteIncome() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.income.delete.path, { id });
      const res = await fetch(url, { 
        method: api.income.delete.method, 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to delete income record");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.income.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.summary.get.path] });
    },
  });
}
