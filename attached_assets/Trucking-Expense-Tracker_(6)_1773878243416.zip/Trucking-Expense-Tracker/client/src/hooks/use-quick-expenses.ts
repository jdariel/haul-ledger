import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const KEY = "/api/quick-expenses";

export function useQuickExpenses() {
  return useQuery({
    queryKey: [KEY],
    queryFn: async () => {
      const res = await fetch(KEY, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch quick expenses");
      return res.json();
    },
  });
}

export function useCreateQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const res = await fetch(KEY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create");
      return res.json();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [KEY] }),
  });
}

export function useDeleteQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${KEY}/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [KEY] }),
  });
}

export function useLogQuickExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${KEY}/${id}/log`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed to log expense");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/expenses"] });
      qc.invalidateQueries({ queryKey: ["/api/summary"] });
    },
  });
}
