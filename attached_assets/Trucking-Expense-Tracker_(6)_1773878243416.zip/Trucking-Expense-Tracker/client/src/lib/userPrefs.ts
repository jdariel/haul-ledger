export function getMilesGoal(): number {
  return parseInt(localStorage.getItem("hl-weekly-miles-goal") || "0", 10);
}
export function setMilesGoal(goal: number): void {
  localStorage.setItem("hl-weekly-miles-goal", String(goal));
}

export function isFirstVisit(): boolean {
  return !localStorage.getItem("hl-visited");
}
export function markVisited(): void {
  localStorage.setItem("hl-visited", "1");
}
