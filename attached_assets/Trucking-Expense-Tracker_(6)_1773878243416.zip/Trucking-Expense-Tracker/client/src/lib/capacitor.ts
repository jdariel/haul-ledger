import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Keyboard, KeyboardResize } from '@capacitor/keyboard';
import { SplashScreen } from '@capacitor/splash-screen';

export const isNativePlatform = Capacitor.isNativePlatform();
export const platform = Capacitor.getPlatform();

export async function initCapacitor() {
  if (!isNativePlatform) {
    return;
  }

  document.body.classList.add('capacitor-native');

  try {
    await StatusBar.setStyle({ style: Style.Light });
    await StatusBar.setBackgroundColor({ color: '#0b1121' });
  } catch {}

  try {
    await Keyboard.setResizeMode({ mode: KeyboardResize.Body });
  } catch {}

  try {
    await SplashScreen.hide();
  } catch {}
}

export async function updateStatusBarForTheme(isDark: boolean) {
  if (!isNativePlatform) return;
  try {
    await StatusBar.setStyle({ style: isDark ? Style.Light : Style.Dark });
    await StatusBar.setBackgroundColor({ color: isDark ? '#0b1121' : '#f5f7fa' });
  } catch {}
}
