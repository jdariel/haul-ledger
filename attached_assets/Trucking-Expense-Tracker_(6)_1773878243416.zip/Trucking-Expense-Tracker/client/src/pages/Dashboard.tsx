import { useState, useEffect } from "react";
import { useFinancialSummary } from "@/hooks/use-summary";
import { useExpenses } from "@/hooks/use-expenses";
import { useIncomeList } from "@/hooks/use-income";
import { useAssets } from "@/hooks/use-assets";
import { useQuickExpenses, useLogQuickExpense } from "@/hooks/use-quick-expenses";
import { getMilesGoal } from "@/lib/userPrefs";
import { CreateExpenseDialog } from "@/components/CreateExpenseDialog";
import { CreateIncomeDialog } from "@/components/CreateIncomeDialog";
import { OnboardingBanner } from "@/components/OnboardingBanner";
import { TrendingUp, TrendingDown, Plus, Receipt, DollarSign, Navigation, ArrowRight, Fuel, AlertTriangle, Zap } from "lucide-react";
import { Link, useLocation } from "wouter";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import clsx from "clsx";
import type { Asset } from "@shared/schema";

function getDaysUntilIFTA(): { days: number; quarter: number } | null {
  const now = new Date();
  const year = now.getFullYear();
  const deadlines = [
    { date: new Date(year, 0, 31), quarter: 4 },
    { date: new Date(year, 3, 30), quarter: 1 },
    { date: new Date(year, 6, 31), quarter: 2 },
    { date: new Date(year, 9, 31), quarter: 3 },
    { date: new Date(year + 1, 0, 31), quarter: 4 },
  ];

  for (const dl of deadlines) {
    const diff = Math.ceil((dl.date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diff >= 0 && diff <= 30) {
      return { days: diff, quarter: dl.quarter };
    }
  }
  return null;
}

export default function Dashboard() {
  const [period, setPeriod] = useState<"weekly" | "monthly">("weekly");
  const { data: summary } = useFinancialSummary(period);

  const { data: expensesData } = useExpenses();
  const { data: incomeData } = useIncomeList();
  const { data: assetsData } = useAssets();
  const { data: quickExpensesList } = useQuickExpenses();
  const logQuickExpense = useLogQuickExpense();

  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [isIncomeDialogOpen, setIsIncomeDialogOpen] = useState(false);
  const [selectedTruckId, setSelectedTruckId] = useState<number | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [milesGoal] = useState(() => getMilesGoal());

  const assetsList: Asset[] = assetsData || [];
  const hasMultipleAssets = assetsList.length > 1;

  const recentActivity = [
    ...(expensesData || []).map(e => ({ id: e.id, type: "expense" as const, label: e.merchant, category: e.category, amount: Number(e.amount), date: e.date, truckId: e.truckId })),
    ...(incomeData || []).map(i => ({ id: i.id, type: "income" as const, label: i.source || i.routeName || "Income", category: "Income", amount: Number(i.amount), date: i.date, truckId: null as string | null })),
  ]
    .filter(tx => {
      if (!selectedTruckId) return true;
      return tx.truckId === String(selectedTruckId);
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const totalIncome = summary?.totalIncome || 0;
  const totalExpenses = summary?.totalExpenses || 0;
  const netProfit = summary?.netProfit || 0;
  const totalMiles = summary?.totalMiles || 0;
  const weeklyMiles = summary?.weeklyMiles || 0;
  const fuelCostPerMile = summary?.fuelCostPerMile || 0;

  const filteredExpensesList = selectedTruckId
    ? (expensesData || []).filter(e => e.truckId === String(selectedTruckId))
    : null;

  const displayExpenses = filteredExpensesList
    ? filteredExpensesList.reduce((s, e) => s + Number(e.amount), 0)
    : totalExpenses;

  const displayIncome = totalIncome;
  const displayNetProfit = selectedTruckId
    ? displayIncome - displayExpenses
    : netProfit;

  const iftaInfo = getDaysUntilIFTA();

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);

  return (
    <div className="space-y-5 pb-32 relative">
      <OnboardingBanner />
      <header>
        <h1 className="text-2xl font-display font-bold text-foreground" data-testid="text-dashboard-title">
          {period === "weekly" ? "This Week" : "This Month"}
        </h1>
      </header>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex bg-card/30 p-1 rounded-full border border-border/20 w-fit">
          {(["weekly", "monthly"] as const).map((p) => (
            <button
              key={p}
              className={clsx(
                "px-5 py-1.5 rounded-full text-sm font-medium transition-all",
                period === p
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground"
              )}
              onClick={() => setPeriod(p)}
              data-testid={`button-period-${p}`}
            >
              {p === "weekly" ? "Week" : "Month"}
            </button>
          ))}
        </div>

        {hasMultipleAssets && (
          <Select
            value={selectedTruckId ? String(selectedTruckId) : "all"}
            onValueChange={(val) => setSelectedTruckId(val === "all" ? null : Number(val))}
          >
            <SelectTrigger className="w-[160px] bg-card/30 border-border/20" data-testid="select-truck-filter">
              <SelectValue placeholder="All Trucks" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" data-testid="select-truck-all">All Trucks</SelectItem>
              {assetsList.map((asset) => (
                <SelectItem key={asset.id} value={String(asset.id)} data-testid={`select-truck-${asset.id}`}>
                  {asset.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {iftaInfo && (
        <Card className="p-4 border-amber-500/30 bg-amber-500/10" data-testid="card-ifta-banner">
          <button
            onClick={() => setLocation("/reports?ifta=1")}
            className="flex items-center gap-3 w-full text-left"
            data-testid="button-ifta-banner"
          >
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-500 flex-shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-amber-400" data-testid="text-ifta-warning">
                IFTA Q{iftaInfo.quarter} filing due in {iftaInfo.days} day{iftaInfo.days !== 1 ? "s" : ""}
              </p>
              <p className="text-xs text-muted-foreground">Tap to view reports</p>
            </div>
            <ArrowRight className="w-4 h-4 text-amber-500 ml-auto flex-shrink-0" />
          </button>
        </Card>
      )}

      <div className="glass-card rounded-2xl p-5 border border-border/20 relative overflow-hidden" data-testid="card-net-profit">
        <div className="flex items-start justify-between mb-1">
          <div>
            <p className="text-sm text-muted-foreground font-medium tracking-wide uppercase">Net Profit</p>
            {selectedTruckId && (
              <p className="text-[10px] text-amber-400/70 mt-0.5" data-testid="text-truck-filter-label">
                Expenses filtered by truck
              </p>
            )}
          </div>
          <div className={clsx("p-2 rounded-xl", displayNetProfit >= 0 ? "bg-emerald-500/20 text-emerald-500" : "bg-rose-500/20 text-rose-500")}>
            {displayNetProfit >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
          </div>
        </div>
        <h2
          className={clsx(
            "text-4xl font-display font-bold tracking-tight",
            displayNetProfit >= 0 ? "text-emerald-400" : "text-rose-400"
          )}
          data-testid="text-net-profit"
        >
          {formatCurrency(displayNetProfit)}
        </h2>
        <div className="flex items-center gap-4 mt-3 text-sm">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span className="text-muted-foreground" data-testid="text-profit-income">{formatCurrency(displayIncome)}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
            <span className="text-muted-foreground" data-testid="text-profit-expenses">{formatCurrency(displayExpenses)}</span>
          </span>
        </div>
        <div className="w-full h-1 mt-4 rounded-full bg-foreground/5 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-amber-500"
            style={{
              width: displayIncome + displayExpenses > 0
                ? `${(displayIncome / (displayIncome + displayExpenses)) * 100}%`
                : "0%",
            }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Link href="/income" className="glass-card rounded-2xl p-4 border border-emerald-500/20 relative overflow-hidden hover-elevate" data-testid="card-income">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-500 w-fit mb-3">
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Income</p>
          <h3 className="text-xl font-display font-bold text-emerald-400 mt-0.5" data-testid="text-total-income">
            {formatCurrency(displayIncome)}
          </h3>
        </Link>

        <Link href="/expenses" className="glass-card rounded-2xl p-4 border border-rose-500/20 relative overflow-hidden hover-elevate" data-testid="card-expenses">
          <div className="p-2 rounded-xl bg-rose-500/20 text-rose-500 w-fit mb-3">
            <TrendingDown className="w-5 h-5" />
          </div>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Expenses</p>
          <h3 className="text-xl font-display font-bold text-rose-400 mt-0.5" data-testid="text-total-expenses">
            {formatCurrency(displayExpenses)}
          </h3>
        </Link>

        <Link href="/trips" className="glass-card rounded-2xl p-4 border border-cyan-500/20 relative overflow-hidden hover-elevate" data-testid="card-miles">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-500 w-fit mb-3">
            <Navigation className="w-5 h-5" />
          </div>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Miles</p>
          <h3 className="text-xl font-display font-bold text-foreground mt-0.5" data-testid="text-miles">
            {totalMiles.toLocaleString()}
          </h3>
        </Link>

        <Link href="/fuel" className="glass-card rounded-2xl p-4 border border-amber-500/20 relative overflow-hidden hover-elevate" data-testid="card-fuel-cost-per-mile">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-500 w-fit mb-3">
            <Fuel className="w-5 h-5" />
          </div>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Fuel Cost/Mile</p>
          <h3 className="text-xl font-display font-bold text-amber-400 mt-0.5" data-testid="text-fuel-cost-per-mile">
            {totalMiles > 0 ? `$${fuelCostPerMile.toFixed(2)}` : "\u2014"}
          </h3>
        </Link>

        <Link
          href="/trips"
          className="glass-card rounded-2xl p-4 border border-cyan-500/20 relative overflow-hidden hover-elevate col-span-2"
          data-testid="card-weekly-miles"
        >
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-500 w-fit mb-3">
            <Navigation className="w-5 h-5" />
          </div>
          <div className="flex items-end justify-between mb-1">
            <div>
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Miles This Week
              </p>
              <h3 className="text-xl font-display font-bold text-foreground mt-0.5" data-testid="text-weekly-miles">
                {weeklyMiles > 0 ? weeklyMiles.toLocaleString() : "\u2014"}
              </h3>
            </div>
            {milesGoal > 0 && (
              <span className="text-xs text-muted-foreground tabular-nums mb-1" data-testid="text-miles-goal">
                / {milesGoal.toLocaleString()} goal
              </span>
            )}
          </div>
          {milesGoal > 0 && (
            <>
              <div className="w-full h-1.5 rounded-full bg-foreground/10 overflow-hidden mt-2">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-cyan-300 transition-all duration-500"
                  style={{ width: `${Math.min(100, weeklyMiles > 0 ? (weeklyMiles / milesGoal) * 100 : 0)}%` }}
                  data-testid="progress-miles-goal"
                />
              </div>
              <p className="text-[10px] text-muted-foreground/50 mt-1 text-right">
                {weeklyMiles > 0 ? `${Math.round((weeklyMiles / milesGoal) * 100)}% of weekly goal` : "No miles logged yet"}
              </p>
            </>
          )}
        </Link>
      </div>

      {quickExpensesList && quickExpensesList.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> Quick Add
            </p>
            <Link href="/settings/quick-add" className="text-xs text-primary" data-testid="link-manage-quick-add">
              Manage
            </Link>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 snap-x" style={{ scrollbarWidth: "none" }}>
            {quickExpensesList.map((qe: any) => (
              <button
                key={qe.id}
                disabled={logQuickExpense.isPending}
                onClick={async () => {
                  try {
                    await logQuickExpense.mutateAsync(qe.id);
                    toast({ title: "Logged!", description: `${qe.label} — $${Number(qe.amount).toFixed(2)} added.` });
                  } catch {
                    toast({ title: "Error", description: "Failed to log expense.", variant: "destructive" });
                  }
                }}
                data-testid={`button-quick-add-${qe.id}`}
                className="flex-shrink-0 snap-start flex flex-col items-start gap-0.5 px-4 py-3 rounded-2xl bg-card/40 border border-border/20 hover:bg-card/70 hover:border-primary/30 active:scale-95 transition-all text-left min-w-[130px] disabled:opacity-50"
              >
                <span className="text-[10px] text-muted-foreground uppercase tracking-wide">{qe.category}</span>
                <span className="text-sm font-semibold truncate w-full">{qe.label}</span>
                <span className="text-base font-bold text-rose-400 tabular-nums">${Number(qe.amount).toFixed(2)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="bg-card/30 border border-border/20 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-border/10 flex items-center justify-between">
          <h2 className="text-base font-semibold font-display">Recent Activity</h2>
          <Link href="/expenses" className="text-xs font-medium text-primary flex items-center gap-1" data-testid="link-view-all">
            View All <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        {recentActivity.length === 0 ? (
          <div className="p-6 text-center text-muted-foreground text-sm">
            No activity yet. Start by adding income or expenses.
          </div>
        ) : (
          <div className="divide-y divide-border/10">
            {recentActivity.map((tx) => (
              <div
                key={`${tx.type}-${tx.id}`}
                className="flex items-center justify-between px-4 py-3"
                data-testid={`row-activity-${tx.type}-${tx.id}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={clsx(
                    "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                    tx.type === "income"
                      ? "bg-emerald-500/10 text-emerald-500"
                      : "bg-rose-500/10 text-rose-500"
                  )}>
                    {tx.type === "income" ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{tx.label}</p>
                    <p className="text-xs text-muted-foreground">{format(new Date(tx.date), "MMM d")} {tx.category}</p>
                  </div>
                </div>
                <span className={clsx(
                  "font-semibold tabular-nums text-sm flex-shrink-0",
                  tx.type === "income" ? "text-emerald-400" : "text-rose-400"
                )}>
                  {tx.type === "income" ? "+" : "-"}${tx.amount.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="fixed bottom-24 right-6 z-50">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" className="h-14 w-14 rounded-full shadow-2xl hover:scale-110 transition-transform bg-primary" data-testid="button-fab">
              <Plus className="w-8 h-8 text-primary-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="mb-4 bg-card/95 backdrop-blur-xl border-border/20 p-2 min-w-[160px]">
            <DropdownMenuItem
              className="flex items-center gap-3 p-3 cursor-pointer rounded-lg"
              onClick={() => setIsIncomeDialogOpen(true)}
              data-testid="button-fab-income"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                <DollarSign className="w-4 h-4" />
              </div>
              <span className="font-medium">Add Income</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center gap-3 p-3 cursor-pointer rounded-lg"
              onClick={() => setIsExpenseDialogOpen(true)}
              data-testid="button-fab-expense"
            >
              <div className="w-8 h-8 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-500">
                <Receipt className="w-4 h-4" />
              </div>
              <span className="font-medium">Add Expense</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <CreateExpenseDialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen} />
      <CreateIncomeDialog open={isIncomeDialogOpen} onOpenChange={setIsIncomeDialogOpen} />
    </div>
  );
}
