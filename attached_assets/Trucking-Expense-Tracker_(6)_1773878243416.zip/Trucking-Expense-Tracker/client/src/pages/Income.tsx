import { useIncomeList, useDeleteIncome } from "@/hooks/use-income";
import { CreateIncomeDialog } from "@/components/CreateIncomeDialog";
import { SwipeableRow } from "@/components/SwipeableRow";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";
import { WeekNavigator, getWeekStart, isInWeek } from "@/components/WeekNavigator";
import { Plus, TrendingUp, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { type Income as IncomeType } from "@shared/schema";

export default function Income() {
  const { data: income, isLoading } = useIncomeList();
  const deleteIncome = useDeleteIncome();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingIncome, setEditingIncome] = useState<IncomeType | null>(null);
  const [weekStart, setWeekStart] = useState(() => getWeekStart());
  const [pendingDelete, setPendingDelete] = useState<IncomeType | null>(null);

  const filteredIncome = income?.filter(i => isInWeek(i.date, weekStart)) || [];

  const weekTotal = filteredIncome.reduce((sum, i) => sum + Number(i.amount), 0);

  const handleEdit = (item: IncomeType) => {
    setEditingIncome(item);
    setIsDialogOpen(true);
  };

  const handleDialogChange = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) setEditingIncome(null);
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteIncome.mutateAsync(pendingDelete.id);
      toast({ title: "Income Deleted", description: `Removed ${pendingDelete.source} income record.` });
      setPendingDelete(null);
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-income-title">Income</h1>
          <p className="text-muted-foreground mt-1">Log your loads and settlements.</p>
        </div>
        <Button variant="outline" className="rounded-xl border-emerald-500/50 text-emerald-500" onClick={() => { setEditingIncome(null); setIsDialogOpen(true); }} data-testid="button-add-income">
          <Plus className="w-4 h-4 mr-2" />
          Add Income
        </Button>
      </header>

      <div className="bg-card/30 border border-border/20 rounded-xl p-3">
        <WeekNavigator weekStart={weekStart} onWeekChange={setWeekStart} />
        <div className="text-center mt-2">
          <span className="text-sm text-muted-foreground">Week Total: </span>
          <span className="font-semibold tabular-nums text-emerald-400" data-testid="text-week-total">
            +${weekTotal.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="bg-card/30 border border-border/20 rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <Loader2 className="w-8 h-8 animate-spin text-primary/50" />
          </div>
        ) : filteredIncome.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <TrendingUp className="w-10 h-10 mb-2 opacity-20" />
            <p className="font-medium">No income logged this week.</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Tap + to add a load.</p>
          </div>
        ) : (
          <div className="space-y-3 p-3">
            {filteredIncome.map((item) => (
              <SwipeableRow
                key={item.id}
                onTap={() => handleEdit(item)}
                onDelete={() => setPendingDelete(item)}
                testId={`row-income-${item.id}`}
              >
                <div className="flex items-center justify-between p-4" data-testid={`button-edit-income-${item.id}`}>
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center border bg-emerald-500/10 text-emerald-500 border-emerald-500/20 flex-shrink-0">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm truncate">{item.source || item.routeName || "Income"}</p>
                        {item.trailerNumber && (
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0" data-testid={`badge-trailer-${item.id}`}>
                            #{item.trailerNumber}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(item.date), "MMM d, yyyy")}
                        {item.routeName ? ` ${item.routeName}` : ""}
                      </p>
                      {item.notes && (
                        <p className="text-xs text-muted-foreground/60 truncate mt-0.5" data-testid={`text-notes-${item.id}`}>
                          {item.notes.length > 60 ? `${item.notes.slice(0, 60)}\u2026` : item.notes}
                        </p>
                      )}
                    </div>
                  </div>
                  <span className="font-semibold tabular-nums text-emerald-400 flex-shrink-0">
                    +${Number(item.amount).toFixed(2)}
                  </span>
                </div>
              </SwipeableRow>
            ))}
          </div>
        )}
      </div>

      <CreateIncomeDialog
        open={isDialogOpen}
        onOpenChange={handleDialogChange}
        editIncome={editingIncome}
        onSaved={(date) => setWeekStart(getWeekStart(date))}
      />

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        title="Delete Income"
        description={`Are you sure you want to delete this ${pendingDelete?.source || "income"} record? This action cannot be undone.`}
        onConfirm={handleConfirmDelete}
        isDeleting={deleteIncome.isPending}
      />
    </div>
  );
}
