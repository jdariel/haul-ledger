import { useState } from "react";
import { useQuickExpenses, useCreateQuickExpense, useDeleteQuickExpense } from "@/hooks/use-quick-expenses";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Zap, Trash2, Loader2 } from "lucide-react";
import { Link } from "wouter";
import type { QuickExpense } from "@shared/schema";

const EXPENSE_CATEGORIES = [
  "Fuel", "Repairs", "Insurance", "Tolls", "Parking",
  "DEF", "Lodging", "Meals", "Phone/Internet",
  "Truck Lease", "Scale Tickets", "Other"
];

export default function QuickAdd() {
  const { data: templates, isLoading } = useQuickExpenses();
  const createTemplate = useCreateQuickExpense();
  const deleteTemplate = useDeleteQuickExpense();
  const { toast } = useToast();

  const [label, setLabel] = useState("");
  const [merchant, setMerchant] = useState("");
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [pendingDelete, setPendingDelete] = useState<QuickExpense | null>(null);

  const handleSubmit = async () => {
    if (!label.trim() || !merchant.trim() || !category || !amount) {
      toast({ title: "Missing Fields", description: "Please fill in label, merchant, category, and amount.", variant: "destructive" });
      return;
    }
    try {
      await createTemplate.mutateAsync({
        label: label.trim(),
        merchant: merchant.trim(),
        category,
        amount: amount,
        paymentMethod: paymentMethod.trim() || undefined,
      });
      toast({ title: "Template Created", description: `"${label.trim()}" saved as a quick add shortcut.` });
      setLabel("");
      setMerchant("");
      setCategory("");
      setAmount("");
      setPaymentMethod("");
    } catch {
      toast({ title: "Error", description: "Failed to create template.", variant: "destructive" });
    }
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteTemplate.mutateAsync(pendingDelete.id);
      toast({ title: "Deleted", description: `"${pendingDelete.label}" removed.` });
    } catch {
      toast({ title: "Error", description: "Failed to delete template.", variant: "destructive" });
    } finally {
      setPendingDelete(null);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <header>
        <div className="sticky top-0 z-10 bg-background pt-2 pb-1 -mx-4 px-4">
          <Link href="/settings" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground mb-3 hover:text-foreground transition-colors" data-testid="link-back-settings">
            <ArrowLeft className="w-4 h-4" />
            Settings
          </Link>
        </div>
        <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-quick-add-title">Quick Add</h1>
        <p className="text-muted-foreground mt-1">Tap a shortcut on the dashboard to instantly log a common expense.</p>
      </header>

      <Card className="bg-card/30 border-border/20 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border/10">
          <h2 className="font-display font-semibold text-foreground text-lg">Add Template</h2>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              placeholder="Label (e.g. Morning Fuel Stop)"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              data-testid="input-quick-label"
            />
            <Input
              placeholder="Merchant"
              value={merchant}
              onChange={(e) => setMerchant(e.target.value)}
              data-testid="input-quick-merchant"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger data-testid="select-quick-category">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {EXPENSE_CATEGORIES.map(c => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              data-testid="input-quick-amount"
            />
            <Input
              placeholder="Payment Method (optional)"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              data-testid="input-quick-payment"
            />
          </div>
          <Button
            onClick={handleSubmit}
            disabled={createTemplate.isPending}
            className="w-full sm:w-auto"
            data-testid="button-save-template"
          >
            {createTemplate.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Save Template
          </Button>
        </div>
      </Card>

      <div className="space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : templates && templates.length > 0 ? (
          templates.map((t: QuickExpense) => (
            <Card key={t.id} className="bg-card/30 border-border/20 rounded-2xl p-4 flex items-center justify-between" data-testid={`card-template-${t.id}`}>
              <div className="min-w-0">
                <p className="font-semibold text-sm text-foreground truncate">{t.label}</p>
                <p className="text-xs text-muted-foreground">{t.merchant} · {t.category}</p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <span className="text-sm font-bold text-rose-400 tabular-nums">${Number(t.amount).toFixed(2)}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive hover:bg-destructive/10"
                  onClick={() => setPendingDelete(t)}
                  data-testid={`button-delete-template-${t.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))
        ) : (
          <div className="text-center py-10 space-y-3">
            <div className="mx-auto w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Zap className="w-6 h-6" />
            </div>
            <p className="text-muted-foreground text-sm" data-testid="text-empty-templates">
              No quick add templates yet. Fill in the form above to create your first one.
            </p>
          </div>
        )}
      </div>

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        description={pendingDelete ? `Delete "${pendingDelete.label}" quick add template? This cannot be undone.` : ""}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}
