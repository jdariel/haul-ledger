import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/lib/theme";
import { getMilesGoal, setMilesGoal } from "@/lib/userPrefs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { LogOut, User, Mail, Shield, Route, FilePieChart, ChevronRight, Download, Trash2, Truck, MapPin, Fuel, Loader2, Info, FileSpreadsheet, Sun, Moon, Target, Zap } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { downloadCSV } from "@/lib/utils";

export default function Settings() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isExportingCSV, setIsExportingCSV] = useState(false);
  const [milesGoalInput, setMilesGoalInput] = useState(() => {
    const g = getMilesGoal();
    return g > 0 ? String(g) : "";
  });

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const res = await fetch("/api/account/export", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to export");
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "haulledger-export.json";
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: "Data Exported", description: "Your data has been downloaded." });
    } catch (err: any) {
      toast({ title: "Export Failed", description: err.message, variant: "destructive" });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = async () => {
    setIsExportingCSV(true);
    try {
      const res = await fetch("/api/account/export", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to export");
      const data = await res.json();
      const rows: Record<string, any>[] = [];
      if (data.expenses && Array.isArray(data.expenses)) {
        for (const e of data.expenses) {
          rows.push({
            type: "expense",
            date: e.date ? new Date(e.date).toLocaleDateString() : "",
            merchantOrSource: e.merchant || "",
            category: e.category || "",
            amount: e.amount != null ? `-${Number(e.amount).toFixed(2)}` : "",
            paymentMethod: e.paymentMethod || "",
            notes: e.notes || "",
          });
        }
      }
      if (data.income && Array.isArray(data.income)) {
        for (const i of data.income) {
          rows.push({
            type: "income",
            date: i.date ? new Date(i.date).toLocaleDateString() : "",
            merchantOrSource: i.source || "",
            category: i.category || "",
            amount: i.amount != null ? Number(i.amount).toFixed(2) : "",
            paymentMethod: i.paymentMethod || "",
            notes: i.notes || "",
          });
        }
      }
      rows.push({ type: "---", date: "TRIPS", merchantOrSource: "", category: "", amount: "", paymentMethod: "", notes: "" });
      if (data.trips && Array.isArray(data.trips)) {
        for (const t of data.trips) {
          rows.push({
            type: "trip",
            date: t.date ? new Date(t.date).toLocaleDateString() : "",
            merchantOrSource: `${t.startLocation || ""} → ${t.endLocation || ""}`,
            category: t.jurisdiction || "",
            amount: `${(Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0)).toFixed(0)} mi`,
            paymentMethod: "",
            notes: t.notes || "",
          });
        }
      }
      rows.push({ type: "---", date: "FUEL ENTRIES", merchantOrSource: "", category: "", amount: "", paymentMethod: "", notes: "" });
      if (data.fuelEntries && Array.isArray(data.fuelEntries)) {
        for (const f of data.fuelEntries) {
          rows.push({
            type: "fuel",
            date: f.date ? new Date(f.date).toLocaleDateString() : "",
            merchantOrSource: f.vendor || "",
            category: f.jurisdiction || "",
            amount: f.totalCost != null ? `-${Number(f.totalCost).toFixed(2)}` : "",
            paymentMethod: `${Number(f.gallons || 0).toFixed(1)}gal @ $${Number(f.pricePerGallon || 0).toFixed(3)}`,
            notes: f.notes || "",
          });
        }
      }
      if (rows.length === 0) {
        toast({ title: "No Data", description: "No data to export.", variant: "destructive" });
        return;
      }
      downloadCSV("haulledger-export.csv", rows);
      toast({ title: "CSV Exported", description: "Your data has been downloaded as CSV." });
    } catch (err: any) {
      toast({ title: "Export Failed", description: err.message, variant: "destructive" });
    } finally {
      setIsExportingCSV(false);
    }
  };

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const res = await fetch("/api/account", { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete account data");
      toast({ title: "Account Data Deleted", description: "All your data has been removed." });
      setDeleteDialogOpen(false);
      window.location.href = "/";
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <header>
        <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-settings-title">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage your account and preferences.</p>
      </header>

      <Card className="bg-card/30 border-border/20 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border/10">
          <h2 className="font-display font-semibold text-foreground text-lg">Profile</h2>
        </div>
        <div className="p-6 space-y-5">
          <div className="flex items-center gap-4">
            <img
              src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${user?.firstName || "User"}&background=random`}
              alt="Profile"
              className="w-16 h-16 rounded-2xl ring-2 ring-border/20"
              data-testid="img-profile-avatar"
            />
            <div>
              <p className="font-display font-semibold text-foreground text-xl" data-testid="text-profile-name">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-muted-foreground text-sm" data-testid="text-profile-email">{user?.email}</p>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3 text-sm">
              <User className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="text-muted-foreground">Name</span>
              <span className="ml-auto text-foreground" data-testid="text-setting-name">{user?.firstName} {user?.lastName}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Mail className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="text-muted-foreground">Email</span>
              <span className="ml-auto text-foreground truncate max-w-[200px]" data-testid="text-setting-email">{user?.email}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Shield className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="text-muted-foreground">Auth</span>
              <span className="ml-auto text-foreground">Replit</span>
            </div>
            <div className="flex items-center justify-between py-3 border-t border-border/10">
              <div className="flex items-center gap-3 text-sm">
                {theme === "dark"
                  ? <Moon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  : <Sun className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
                <span className="text-muted-foreground">Appearance</span>
                <span className="ml-auto text-foreground">{theme === "dark" ? "Dark" : "Light"}</span>
              </div>
              <Switch
                checked={theme === "light"}
                onCheckedChange={toggleTheme}
                className="ml-4"
                data-testid="switch-theme"
              />
            </div>
          </div>
        </div>
      </Card>

      <Card className="bg-card/30 border-border/20 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border/10">
          <h2 className="font-display font-semibold text-foreground text-lg">Goals</h2>
        </div>
        <div className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 flex-shrink-0">
              <Target className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-foreground font-medium text-sm">Weekly Miles Target</p>
              <p className="text-muted-foreground text-xs mt-0.5">Track progress on your dashboard</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Input
                type="number"
                min="0"
                placeholder="e.g. 2500"
                value={milesGoalInput}
                onChange={(e) => setMilesGoalInput(e.target.value)}
                className="w-24 border-border/20 bg-card/30 text-center"
                data-testid="input-miles-goal"
              />
              <Button
                size="sm"
                variant="outline"
                className="border-border/20"
                onClick={() => {
                  const val = parseInt(milesGoalInput, 10);
                  if (val > 0) {
                    setMilesGoal(val);
                    toast({ title: "Goal Saved", description: `Weekly target set to ${val.toLocaleString()} miles.` });
                  } else {
                    setMilesGoal(0);
                    toast({ title: "Goal Cleared", description: "Weekly miles target removed." });
                  }
                }}
                data-testid="button-save-miles-goal"
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card className="bg-card/30 border-border/20 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border/10">
          <h2 className="font-display font-semibold text-foreground text-lg">Tools</h2>
        </div>
        <div className="divide-y divide-border/10">
          <Link href="/fleet" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-fleet">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <Truck className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Fleet</p>
              <p className="text-muted-foreground text-xs">Manage your trucks and trailers</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
          <Link href="/trips" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-trips">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Trips</p>
              <p className="text-muted-foreground text-xs">Log trips and track mileage</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
          <Link href="/fuel" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-fuel-log">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Fuel className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Fuel Log</p>
              <p className="text-muted-foreground text-xs">Track fuel purchases for IFTA</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
          <Link href="/routes" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-saved-routes">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <Route className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Saved Routes</p>
              <p className="text-muted-foreground text-xs">Manage your route templates for quick income logging</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
          <Link href="/reports" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-reports">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <FilePieChart className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Reports</p>
              <p className="text-muted-foreground text-xs">View financial reports and export data</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
          <Link href="/settings/quick-add" className="flex items-center gap-4 p-5 hover-elevate" data-testid="link-quick-add">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Zap className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-foreground font-medium text-sm">Quick Add</p>
              <p className="text-muted-foreground text-xs">Save common expenses to log in one tap</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
        </div>
      </Card>

      <Card className="bg-card/30 border-border/20 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border/10">
          <h2 className="font-display font-semibold text-foreground text-lg">Account</h2>
        </div>
        <div className="p-6 space-y-3">
          <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
            <Button
              variant="outline"
              className="w-full sm:w-auto border-border/20"
              onClick={handleExport}
              disabled={isExporting}
              data-testid="button-export-data"
            >
              {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
              Export All Data
            </Button>
            <Button
              variant="outline"
              className="w-full sm:w-auto border-border/20"
              onClick={handleExportCSV}
              disabled={isExportingCSV}
              data-testid="button-export-csv"
            >
              {isExportingCSV ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileSpreadsheet className="w-4 h-4 mr-2" />}
              Export as CSV
            </Button>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-md bg-muted/30 border border-border/10">
            <Info className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground" data-testid="text-export-reminder">
              We recommend exporting your data monthly. Your records are stored securely, but a local backup is always a good idea.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="destructive"
              className="w-full sm:w-auto"
              onClick={() => logout()}
              data-testid="button-sign-out"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
            <Button
              variant="outline"
              className="w-full sm:w-auto border-destructive/30 text-destructive hover:bg-destructive/10"
              onClick={() => setDeleteDialogOpen(true)}
              data-testid="button-delete-account"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete All Data
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-card border-border/20 max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-destructive">Delete All Data</DialogTitle>
            <DialogDescription>
              This will permanently delete all your expenses, income, trips, fuel entries, assets, and saved routes. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={isDeleting} data-testid="button-confirm-delete">
              {isDeleting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Delete Everything
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
