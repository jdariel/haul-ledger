import { useState } from "react";
import { useTrips, useCreateTrip, useDeleteTrip } from "@/hooks/use-trips";
import { useAssets } from "@/hooks/use-assets";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, MapPin, Loader2, Navigation, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { type Trip, type Asset, US_STATES } from "@shared/schema";
import { SwipeableRow } from "@/components/SwipeableRow";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";

export default function Trips() {
  const { data: trips, isLoading } = useTrips();
  const { data: assets } = useAssets();
  const createTrip = useCreateTrip();
  const deleteTrip = useDeleteTrip();
  const { toast } = useToast();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<Trip | null>(null);
  const [form, setForm] = useState({
    date: format(new Date(), "yyyy-MM-dd"),
    startLocation: "",
    endLocation: "",
    startOdometer: "",
    endOdometer: "",
    loadedMiles: "",
    emptyMiles: "",
    jurisdiction: "",
    assetId: "",
    notes: "",
  });

  const resetForm = () => setForm({
    date: format(new Date(), "yyyy-MM-dd"),
    startLocation: "", endLocation: "",
    startOdometer: "", endOdometer: "",
    loadedMiles: "", emptyMiles: "",
    jurisdiction: "", assetId: "", notes: "",
  });

  const handleSave = async () => {
    if (!form.startLocation.trim() || !form.endLocation.trim()) {
      toast({ title: "Start and end locations are required", variant: "destructive" });
      return;
    }
    try {
      await createTrip.mutateAsync({
        date: new Date(form.date),
        startLocation: form.startLocation,
        endLocation: form.endLocation,
        startOdometer: form.startOdometer || undefined,
        endOdometer: form.endOdometer || undefined,
        loadedMiles: form.loadedMiles || undefined,
        emptyMiles: form.emptyMiles || undefined,
        jurisdiction: form.jurisdiction || undefined,
        assetId: form.assetId ? Number(form.assetId) : undefined,
        notes: form.notes || undefined,
      } as any);
      toast({ title: "Trip Logged" });
      setIsDialogOpen(false);
      resetForm();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteTrip.mutateAsync(pendingDelete.id);
      toast({ title: "Trip Deleted" });
      setPendingDelete(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const getMiles = (t: Trip): number => {
    if (t.startOdometer && t.endOdometer) return Number(t.endOdometer) - Number(t.startOdometer);
    return Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0);
  };

  const totalMiles = trips?.reduce((sum: number, t: Trip) => sum + getMiles(t), 0) || 0;

  const trucks = assets?.filter((a: Asset) => a.type === "truck") || [];

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-trips-title">Trips</h1>
          <p className="text-muted-foreground mt-1">Log your trips and track mileage.</p>
        </div>
        <Button className="rounded-xl shadow-lg shadow-primary/20" onClick={() => { resetForm(); setIsDialogOpen(true); }} data-testid="button-add-trip">
          <Plus className="w-4 h-4 mr-2" />
          Log Trip
        </Button>
      </header>

      <Card className="bg-card/30 border-border/20 rounded-xl p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
            <Navigation className="w-5 h-5 text-cyan-500" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Total Miles</p>
            <p className="text-2xl font-display font-bold text-foreground tabular-nums" data-testid="text-total-miles">{totalMiles.toLocaleString()}</p>
          </div>
        </div>
      </Card>

      {isLoading ? (
        <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary/50" /></div>
      ) : (!trips || trips.length === 0) ? (
        <div className="bg-card/30 border border-border/20 rounded-2xl p-12 text-center">
          <MapPin className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
          <p className="text-muted-foreground">No trips logged yet.</p>
          <p className="text-muted-foreground/60 text-sm mt-1">Start logging trips to track your mileage.</p>
        </div>
      ) : (
        <div className="bg-card/30 border border-border/20 rounded-2xl overflow-hidden">
          <div className="space-y-3 p-3">
            {trips.map((trip: Trip) => {
              const miles = getMiles(trip);
              return (
                <SwipeableRow
                  key={trip.id}
                  onTap={() => {}}
                  onDelete={() => setPendingDelete(trip)}
                  testId={`row-trip-${trip.id}`}
                >
                  <div className="flex items-center justify-between p-4 gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-cyan-500/10 text-cyan-500 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate">{trip.startLocation} to {trip.endLocation}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1.5 flex-wrap">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(trip.date), "MMM d, yyyy")}
                          {trip.jurisdiction && <span className="text-cyan-400/70">| {trip.jurisdiction}</span>}
                        </p>
                      </div>
                    </div>
                    <span className="font-semibold tabular-nums text-cyan-400 flex-shrink-0">{miles.toLocaleString()} mi</span>
                  </div>
                </SwipeableRow>
              );
            })}
          </div>
        </div>
      )}

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        title="Delete Trip"
        description={`Are you sure you want to delete the trip from ${pendingDelete?.startLocation || ""} to ${pendingDelete?.endLocation || ""}? This action cannot be undone.`}
        onConfirm={handleConfirmDelete}
        isDeleting={deleteTrip.isPending}
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-border/25 max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">Log Trip</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Date</Label>
              <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} data-testid="input-trip-date" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Start Location</Label>
                <Input placeholder="Dallas, TX" value={form.startLocation} onChange={(e) => setForm({ ...form, startLocation: e.target.value })} data-testid="input-trip-start" />
              </div>
              <div>
                <Label>End Location</Label>
                <Input placeholder="Houston, TX" value={form.endLocation} onChange={(e) => setForm({ ...form, endLocation: e.target.value })} data-testid="input-trip-end" />
              </div>
            </div>
            <div className="rounded-lg border border-border/20 p-3 space-y-3">
              <p className="text-xs text-muted-foreground font-semibold uppercase">Odometer (optional)</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Start Odometer</Label>
                  <Input type="number" placeholder="245,000" value={form.startOdometer} onChange={(e) => setForm({ ...form, startOdometer: e.target.value })} data-testid="input-trip-start-odo" />
                </div>
                <div>
                  <Label className="text-xs">End Odometer</Label>
                  <Input type="number" placeholder="245,350" value={form.endOdometer} onChange={(e) => setForm({ ...form, endOdometer: e.target.value })} data-testid="input-trip-end-odo" />
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-border/20 p-3 space-y-3">
              <p className="text-xs text-muted-foreground font-semibold uppercase">Or Manual Miles</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Loaded Miles</Label>
                  <Input type="number" placeholder="280" value={form.loadedMiles} onChange={(e) => setForm({ ...form, loadedMiles: e.target.value })} data-testid="input-trip-loaded" />
                </div>
                <div>
                  <Label className="text-xs">Empty Miles</Label>
                  <Input type="number" placeholder="70" value={form.emptyMiles} onChange={(e) => setForm({ ...form, emptyMiles: e.target.value })} data-testid="input-trip-empty" />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>State/Province</Label>
                <Select value={form.jurisdiction} onValueChange={(v) => setForm({ ...form, jurisdiction: v })}>
                  <SelectTrigger data-testid="select-trip-jurisdiction"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {US_STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {trucks.length > 0 && (
                <div>
                  <Label>Truck</Label>
                  <Select value={form.assetId} onValueChange={(v) => setForm({ ...form, assetId: v })}>
                    <SelectTrigger data-testid="select-trip-truck"><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {trucks.map((a: Asset) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <div>
              <Label>Notes</Label>
              <Input placeholder="Optional notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} data-testid="input-trip-notes" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={createTrip.isPending} data-testid="button-save-trip">
              {createTrip.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Log Trip
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
