import { useExpenses, useDeleteExpense } from "@/hooks/use-expenses";
import { CreateExpenseDialog } from "@/components/CreateExpenseDialog";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";
import { SwipeableRow } from "@/components/SwipeableRow";
import { WeekNavigator, getWeekStart, isInWeek } from "@/components/WeekNavigator";
import { Plus, TrendingDown, Loader2, Receipt, Fuel, Filter, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { type Expense } from "@shared/schema";

const EXPENSE_CATEGORIES = [
  "All", "Fuel", "Repairs", "Insurance", "Tolls", "Parking",
  "DEF", "Lodging", "Meals", "Phone/Internet",
  "Truck Lease", "Scale Tickets", "Other"
];

export default function Expenses() {
  const { data: expenses, isLoading } = useExpenses();
  const deleteExpense = useDeleteExpense();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [weekStart, setWeekStart] = useState(() => getWeekStart());
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [pendingDelete, setPendingDelete] = useState<Expense | null>(null);
  const [viewingReceiptUrl, setViewingReceiptUrl] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"week" | "all">("week");

  const baseExpenses = viewMode === "week"
    ? (expenses?.filter(e => isInWeek(e.date, weekStart)) || [])
    : ([...(expenses || [])].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));

  const filteredExpenses = baseExpenses
    .filter(e => categoryFilter === "All" || e.category === categoryFilter)
    .filter(e => !searchQuery || e.merchant.toLowerCase().includes(searchQuery.toLowerCase()));

  const displayTotal = filteredExpenses.reduce((sum, e) => sum + Number(e.amount), 0);

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense);
    setIsDialogOpen(true);
  };

  const handleDialogChange = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) setEditingExpense(null);
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteExpense.mutateAsync(pendingDelete.id);
      toast({ title: "Expense Deleted", description: `Removed ${pendingDelete.merchant} expense.` });
      setPendingDelete(null);
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  const getReceiptImageUrl = (receiptUrl: string) => {
    return `/objects/${receiptUrl.replace(/^\/objects\//, '')}`;
  };

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-expenses-title">Expenses</h1>
          <p className="text-muted-foreground mt-1">Track every penny spent on the road.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="rounded-xl border-border/25 gap-1.5" data-testid="button-filter-category">
                <Filter className="w-4 h-4" />
                {categoryFilter === "All" ? "Filter" : categoryFilter}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-card/95 backdrop-blur-xl border-border/25 max-h-64 overflow-y-auto">
              {EXPENSE_CATEGORIES.map((cat) => (
                <DropdownMenuItem
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={categoryFilter === cat ? "bg-primary/10 text-primary" : ""}
                  data-testid={`filter-category-${cat.toLowerCase().replace(/[/\s]/g, '-')}`}
                >
                  {cat}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button className="rounded-xl shadow-lg shadow-primary/20" onClick={() => { setEditingExpense(null); setIsDialogOpen(true); }} data-testid="button-add-expense">
            <Plus className="w-4 h-4 mr-2" />
            Add Expense
          </Button>
        </div>
      </header>

      {categoryFilter !== "All" && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {categoryFilter}
            <button onClick={() => setCategoryFilter("All")} className="ml-1.5 opacity-60 hover:opacity-100" data-testid="button-clear-filter">
              x
            </button>
          </Badge>
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by merchant..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 pr-9 rounded-xl border-border/25 bg-card/30"
          data-testid="input-search-expenses"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            data-testid="button-clear-search"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="bg-card/30 border border-border/20 rounded-xl p-3 space-y-2">
        <div className="flex items-center justify-center gap-1 mb-2">
          <Button
            variant={viewMode === "week" ? "default" : "ghost"}
            size="sm"
            onClick={() => setViewMode("week")}
            className="rounded-l-lg rounded-r-none"
            data-testid="button-view-week"
          >
            Week
          </Button>
          <Button
            variant={viewMode === "all" ? "default" : "ghost"}
            size="sm"
            onClick={() => setViewMode("all")}
            className="rounded-r-lg rounded-l-none"
            data-testid="button-view-all"
          >
            All
          </Button>
        </div>
        {viewMode === "week" ? (
          <>
            <WeekNavigator weekStart={weekStart} onWeekChange={setWeekStart} />
            <div className="text-center">
              <span className="text-sm text-muted-foreground">Week Total: </span>
              <span className="font-semibold tabular-nums text-rose-400" data-testid="text-week-total">
                -${displayTotal.toFixed(2)}
              </span>
            </div>
          </>
        ) : (
          <div className="text-center" data-testid="text-all-summary">
            <span className="text-sm text-muted-foreground">
              {filteredExpenses.length} expense{filteredExpenses.length !== 1 ? "s" : ""}
            </span>
            <span className="mx-1 text-muted-foreground/40">&#8226;</span>
            <span className="font-semibold tabular-nums text-rose-400" data-testid="text-all-total">
              -${displayTotal.toFixed(2)}
            </span>
            <span className="text-sm text-muted-foreground"> total</span>
          </div>
        )}
      </div>

      <div className="bg-card/30 border border-border/20 rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <Loader2 className="w-8 h-8 animate-spin text-primary/50" />
          </div>
        ) : filteredExpenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Receipt className="w-10 h-10 mb-2 opacity-20" />
            <p className="font-medium">No expenses {categoryFilter !== "All" ? `in "${categoryFilter}"` : viewMode === "week" ? "this week" : "found"}.</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Tap + to log your first expense.</p>
          </div>
        ) : (
          <div className="space-y-3 p-3">
            {filteredExpenses.map((expense) => (
              <SwipeableRow
                key={expense.id}
                onTap={() => handleEdit(expense)}
                onDelete={() => setPendingDelete(expense)}
                testId={`row-expense-${expense.id}`}
              >
                <div className="flex items-center justify-between p-4" data-testid={`button-edit-expense-${expense.id}`}>
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center border bg-rose-500/10 text-rose-500 border-rose-500/20 flex-shrink-0">
                      <TrendingDown className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-sm truncate">{expense.merchant}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(expense.date), "MMM d, yyyy")} {expense.category}
                        {expense.paymentMethod && (
                          <span className="ml-1.5 inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-muted/30 text-muted-foreground/70">{expense.paymentMethod}</span>
                        )}
                      </p>
                      {expense.category === "Fuel" && expense.gallons && (
                        <p className="text-[11px] text-amber-400/70 mt-0.5 flex items-center gap-1 flex-wrap">
                          <Fuel className="w-3 h-3 inline flex-shrink-0" />
                          {Number(expense.gallons).toFixed(1)}gal
                          {expense.pricePerGallon && <span>@ ${Number(expense.pricePerGallon).toFixed(3)}</span>}
                          {expense.jurisdiction && <span className="text-muted-foreground">| {expense.jurisdiction}</span>}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {expense.receiptUrl && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewingReceiptUrl(expense.receiptUrl!);
                        }}
                        data-testid={`button-view-receipt-${expense.id}`}
                      >
                        <Receipt className="w-4 h-4 text-muted-foreground" />
                      </button>
                    )}
                    <span className="font-semibold tabular-nums text-rose-400">
                      -${Number(expense.amount).toFixed(2)}
                    </span>
                  </div>
                </div>
              </SwipeableRow>
            ))}
          </div>
        )}
      </div>

      <CreateExpenseDialog
        open={isDialogOpen}
        onOpenChange={handleDialogChange}
        editExpense={editingExpense}
        onSaved={(date) => setWeekStart(getWeekStart(date))}
      />

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        title="Delete Expense"
        description={pendingDelete ? `Are you sure you want to delete the $${Number(pendingDelete.amount).toFixed(2)} expense from ${pendingDelete.merchant}? This action cannot be undone.` : ""}
        onConfirm={handleConfirmDelete}
        isDeleting={deleteExpense.isPending}
      />

      <Dialog open={!!viewingReceiptUrl} onOpenChange={(open) => { if (!open) setViewingReceiptUrl(null); }}>
        <DialogContent className="max-w-lg bg-card border-border/25 p-2">
          {viewingReceiptUrl && (
            <img
              src={getReceiptImageUrl(viewingReceiptUrl)}
              alt="Receipt"
              className="w-full h-auto rounded-lg"
              data-testid="img-receipt-viewer"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
