import { useState, useEffect } from "react";
import { useExpenses } from "@/hooks/use-expenses";
import { useIncomeList } from "@/hooks/use-income";
import { useSearch } from "wouter";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Loader2, Download, CalendarDays, ArrowRight, Fuel, TrendingUp, TrendingDown, LayoutGrid, Wrench, Shield, CircleDollarSign, ParkingCircle, Droplets, BedDouble, UtensilsCrossed, Smartphone, Truck, Scale, MoreHorizontal, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, subDays, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import clsx from "clsx";
import { IFTAReportDialog } from "@/components/IFTAReportDialog";
import { ScheduleCDialog } from "@/components/ScheduleCDialog";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

const EXPENSE_CATEGORIES = [
  "Fuel", "Repairs", "Insurance", "Tolls", "Parking",
  "DEF", "Lodging", "Meals", "Phone/Internet",
  "Truck Lease", "Scale Tickets", "Other"
];

type FilterType = "all" | "income" | "expenses" | string;

const CATEGORY_ICONS: Record<string, any> = {
  "Fuel": Fuel, "Repairs": Wrench, "Insurance": Shield, "Tolls": CircleDollarSign,
  "Parking": ParkingCircle, "DEF": Droplets, "Lodging": BedDouble, "Meals": UtensilsCrossed,
  "Phone/Internet": Smartphone, "Truck Lease": Truck, "Scale Tickets": Scale, "Other": MoreHorizontal,
};

const PRIMARY_FILTERS: { label: string; value: FilterType; icon: any }[] = [
  { label: "All", value: "all", icon: LayoutGrid },
  { label: "Income", value: "income", icon: TrendingUp },
  { label: "Expenses", value: "expenses", icon: TrendingDown },
];

const CATEGORY_FILTERS: { label: string; value: FilterType; icon?: any }[] = EXPENSE_CATEGORIES.map(c => ({
  label: c, value: c, icon: CATEGORY_ICONS[c],
}));

export default function Reports() {
  const { data: expenses, isLoading: expLoading } = useExpenses();
  const { data: income, isLoading: incLoading } = useIncomeList();

  const [startDate, setStartDate] = useState<Date>(subDays(new Date(), 30));
  const [endDate, setEndDate] = useState<Date>(new Date());
  const [startOpen, setStartOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>("all");
  const [iftaOpen, setIftaOpen] = useState(false);
  const [scheduleCOpen, setScheduleCOpen] = useState(false);

  const search = useSearch();

  useEffect(() => {
    if (search.includes("ifta=1")) {
      setIftaOpen(true);
    }
  }, [search]);

  const isLoading = expLoading || incLoading;

  const filteredExpenses = expenses?.filter(e => {
    const d = new Date(e.date);
    return isWithinInterval(d, { start: startOfDay(startDate), end: endOfDay(endDate) });
  }) || [];

  const filteredIncome = income?.filter(i => {
    const d = new Date(i.date);
    return isWithinInterval(d, { start: startOfDay(startDate), end: endOfDay(endDate) });
  }) || [];

  const isExpenseCategory = EXPENSE_CATEGORIES.includes(activeFilter);
  const showIncome = activeFilter === "all" || activeFilter === "income";
  const showExpenses = activeFilter === "all" || activeFilter === "expenses" || isExpenseCategory;

  const displayExpenses = isExpenseCategory
    ? filteredExpenses.filter(e => e.category === activeFilter)
    : filteredExpenses;

  const totalExpenses = displayExpenses.reduce((s, e) => s + Number(e.amount), 0);
  const totalIncome = showIncome ? filteredIncome.reduce((s, i) => s + Number(i.amount), 0) : 0;
  const netProfit = totalIncome - totalExpenses;

  const categoryMap = new Map<string, number>();
  displayExpenses.forEach(e => {
    const current = categoryMap.get(e.category) || 0;
    categoryMap.set(e.category, current + Number(e.amount));
  });

  const pieData = Array.from(categoryMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  const monthlyMap = new Map<string, { income: number; expense: number }>();
  if (showExpenses) {
    displayExpenses.forEach(e => {
      const key = format(new Date(e.date), "MMM yyyy");
      const entry = monthlyMap.get(key) || { income: 0, expense: 0 };
      entry.expense += Number(e.amount);
      monthlyMap.set(key, entry);
    });
  }
  if (showIncome) {
    filteredIncome.forEach(i => {
      const key = format(new Date(i.date), "MMM yyyy");
      const entry = monthlyMap.get(key) || { income: 0, expense: 0 };
      entry.income += Number(i.amount);
      monthlyMap.set(key, entry);
    });
  }

  const monthlyData = Array.from(monthlyMap.entries())
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => new Date(a.name).getTime() - new Date(b.name).getTime());

  const fuelExpenses = activeFilter === "Fuel" ? displayExpenses : [];
  const totalGallons = fuelExpenses.reduce((s, e) => s + Number(e.gallons || 0), 0);
  const fuelWithPpg = fuelExpenses.filter(e => e.pricePerGallon);
  const avgPpg = fuelWithPpg.length > 0
    ? fuelWithPpg.reduce((s, e) => s + Number(e.pricePerGallon || 0), 0) / fuelWithPpg.length
    : 0;

  const jurisdictionMap = new Map<string, { gallons: number; cost: number }>();
  fuelExpenses.forEach(e => {
    const j = e.jurisdiction || "N/A";
    const entry = jurisdictionMap.get(j) || { gallons: 0, cost: 0 };
    entry.gallons += Number(e.gallons || 0);
    entry.cost += Number(e.amount);
    jurisdictionMap.set(j, entry);
  });
  const jurisdictionData = Array.from(jurisdictionMap.entries())
    .map(([state, data]) => ({ state, ...data }))
    .sort((a, b) => b.cost - a.cost);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(val);

  const formatCurrencyFull = (val: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(val);

  const CategoryIcon = isExpenseCategory ? CATEGORY_ICONS[activeFilter] : null;

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <h1 className="text-2xl font-display font-bold text-foreground" data-testid="text-reports-title">Reports</h1>
        <div className="flex items-center gap-1.5">
          <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={() => setIftaOpen(true)} data-testid="button-ifta-report">
            <Fuel className="w-3.5 h-3.5 mr-1.5" />
            IFTA
          </Button>
          <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={() => setScheduleCOpen(true)} data-testid="button-export-report">
            <Download className="w-3.5 h-3.5 mr-1.5" />
            Export
          </Button>
        </div>
      </div>

      {/* Date Range */}
      <div className="flex items-center gap-2">
        <Popover open={startOpen} onOpenChange={setStartOpen}>
          <PopoverTrigger asChild>
            <button
              className={clsx(
                "flex-1 flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-colors",
                startOpen ? "border-primary bg-primary/5" : "border-border/25 bg-muted/30"
              )}
              data-testid="button-start-date"
            >
              <CalendarDays className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <span className="text-[13px]">{format(startDate, "MMM d, yyyy")}</span>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 border-border/25" align="center" sideOffset={8}>
            <Calendar
              mode="single"
              selected={startDate}
              onSelect={(date) => {
                if (date) { setStartDate(date); if (date > endDate) setEndDate(date); }
                setStartOpen(false);
              }}
              disabled={(date) => date > new Date()}
              captionLayout="dropdown-buttons"
              fromYear={2020}
              toYear={new Date().getFullYear()}
              initialFocus
            />
          </PopoverContent>
        </Popover>
        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/50 flex-shrink-0" />
        <Popover open={endOpen} onOpenChange={setEndOpen}>
          <PopoverTrigger asChild>
            <button
              className={clsx(
                "flex-1 flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-colors",
                endOpen ? "border-primary bg-primary/5" : "border-border/25 bg-muted/30"
              )}
              data-testid="button-end-date"
            >
              <CalendarDays className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <span className="text-[13px]">{format(endDate, "MMM d, yyyy")}</span>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 border-border/25" align="center" sideOffset={8}>
            <Calendar
              mode="single"
              selected={endDate}
              onSelect={(date) => {
                if (date) { setEndDate(date); if (date < startDate) setStartDate(date); }
                setEndOpen(false);
              }}
              disabled={(date) => date > new Date()}
              captionLayout="dropdown-buttons"
              fromYear={2020}
              toYear={new Date().getFullYear()}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Primary Filters — segmented control */}
      <div className="bg-muted/30 rounded-xl p-1 flex gap-0.5">
        {PRIMARY_FILTERS.map((tab) => {
          const isActive = activeFilter === tab.value;
          const Icon = tab.icon;
          return (
            <button
              key={tab.value}
              onClick={() => setActiveFilter(tab.value)}
              className={clsx(
                "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[12px] font-semibold tracking-wide transition-all",
                isActive
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/25"
                  : "text-muted-foreground/70"
              )}
              data-testid={`button-filter-${tab.value}`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>


      {/* Summary Card — All / Income / Expenses */}
      {(activeFilter === "all" || activeFilter === "income" || activeFilter === "expenses") && (
        <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-5">
          <div className="text-center">
            <p className="text-[11px] uppercase tracking-widest text-muted-foreground/60 font-semibold">
              {activeFilter === "income" ? "Total Income" : activeFilter === "expenses" ? "Total Expenses" : "Net Profit"}
            </p>
            <p className={clsx(
              "text-4xl font-display font-extrabold mt-1.5 tracking-tight",
              activeFilter === "income" ? "text-emerald-400" :
              activeFilter === "expenses" ? "text-rose-400" :
              netProfit >= 0 ? "text-emerald-400" : "text-rose-400"
            )} data-testid="text-report-net">
              {activeFilter === "income" ? formatCurrencyFull(totalIncome) :
               activeFilter === "expenses" ? formatCurrencyFull(totalExpenses) :
               formatCurrencyFull(netProfit)}
            </p>
          </div>
          {activeFilter === "all" && (
            <div className="grid grid-cols-2 gap-2.5 mt-4">
              <div className="rounded-lg bg-emerald-500/[0.08] border border-emerald-500/15 px-3 py-3 text-center">
                <p className="text-[10px] text-emerald-400/60 uppercase tracking-widest font-semibold">Income</p>
                <p className="text-lg font-bold text-emerald-400 mt-0.5 tabular-nums" data-testid="text-report-income">{formatCurrency(totalIncome)}</p>
              </div>
              <div className="rounded-lg bg-rose-500/[0.08] border border-rose-500/15 px-3 py-3 text-center">
                <p className="text-[10px] text-rose-400/60 uppercase tracking-widest font-semibold">Expenses</p>
                <p className="text-lg font-bold text-rose-400 mt-0.5 tabular-nums" data-testid="text-report-expenses">{formatCurrency(totalExpenses)}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Summary Card — Category */}
      {isExpenseCategory && (
        <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-5">
          <div className="flex flex-col items-center gap-2">
            {CategoryIcon && (
              <div className={clsx(
                "w-10 h-10 rounded-xl flex items-center justify-center",
                activeFilter === "Fuel" ? "bg-amber-500/15" : "bg-rose-500/10"
              )}>
                <CategoryIcon className={clsx("w-5 h-5", activeFilter === "Fuel" ? "text-amber-400" : "text-rose-400")} />
              </div>
            )}
            <p className="text-[11px] uppercase tracking-widest text-muted-foreground/60 font-semibold">{activeFilter} Total</p>
            <p className={clsx(
              "text-4xl font-display font-extrabold tracking-tight",
              activeFilter === "Fuel" ? "text-amber-400" : "text-rose-400"
            )} data-testid="text-report-category-total">
              {formatCurrencyFull(totalExpenses)}
            </p>
            <p className="text-xs text-muted-foreground/50">
              {displayExpenses.length} transaction{displayExpenses.length !== 1 ? 's' : ''} in range
            </p>
          </div>
        </div>
      )}

      {/* Fuel Summary */}
      {activeFilter === "Fuel" && fuelExpenses.length > 0 && (
        <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-3">Fuel Summary</h3>
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-amber-500/[0.06] border border-amber-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-amber-400/50 uppercase tracking-widest font-semibold">Gallons</p>
              <p className="text-base font-bold text-amber-400 mt-1 tabular-nums" data-testid="text-fuel-gallons">{totalGallons.toFixed(1)}</p>
            </div>
            <div className="rounded-lg bg-amber-500/[0.06] border border-amber-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-amber-400/50 uppercase tracking-widest font-semibold">Avg $/Gal</p>
              <p className="text-base font-bold text-amber-400 mt-1 tabular-nums" data-testid="text-fuel-avg-ppg">${avgPpg.toFixed(3)}</p>
            </div>
            <div className="rounded-lg bg-amber-500/[0.06] border border-amber-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-amber-400/50 uppercase tracking-widest font-semibold">Total</p>
              <p className="text-base font-bold text-amber-400 mt-1 tabular-nums" data-testid="text-fuel-total">{formatCurrency(totalExpenses)}</p>
            </div>
          </div>
          {jurisdictionData.length > 0 && (
            <div className="mt-4 pt-3 border-t border-border/10">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold mb-2.5">By State</p>
              <div className="space-y-2">
                {jurisdictionData.map((j) => (
                  <div key={j.state} className="flex items-center gap-2.5">
                    <span className="font-mono text-[11px] font-bold bg-amber-500/10 text-amber-400/80 px-1.5 py-0.5 rounded w-8 text-center">{j.state}</span>
                    <div className="flex-1 h-1 rounded-full bg-muted/30 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-amber-500/40 to-amber-400/60"
                        style={{ width: `${totalExpenses > 0 ? (j.cost / totalExpenses) * 100 : 0}%` }}
                      />
                    </div>
                    <span className="text-[11px] text-muted-foreground/50 tabular-nums w-12 text-right">{j.gallons.toFixed(1)}g</span>
                    <span className="text-[11px] font-semibold tabular-nums w-14 text-right">{formatCurrency(j.cost)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Expense Breakdown Pie Chart */}
      {(activeFilter === "all" || activeFilter === "expenses" || isExpenseCategory) && (
        <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-4">
            {isExpenseCategory ? `${activeFilter} Breakdown` : "Expense Breakdown"}
          </h3>
          {pieData.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[180px] text-muted-foreground/40">
              <Receipt className="w-8 h-8 mb-2 opacity-50" />
              <p className="text-sm">No expenses in range</p>
            </div>
          ) : (
            <>
              <div className="h-[200px] -mx-2">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      fill="#8884d8"
                      paddingAngle={3}
                      dataKey="value"
                      strokeWidth={0}
                    >
                      {pieData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: 'rgba(255,255,255,0.08)', borderRadius: '10px', color: '#fff', fontSize: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.4)' }}
                      formatter={(value: number) => formatCurrencyFull(value)}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 space-y-1.5">
                {pieData.slice(0, 8).map((item, index) => {
                  const total = pieData.reduce((s, p) => s + p.value, 0);
                  const pct = total > 0 ? ((item.value / total) * 100).toFixed(0) : '0';
                  const CatIcon = CATEGORY_ICONS[item.name];
                  return (
                    <div key={item.name} className="flex items-center gap-2 py-1">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                      {CatIcon && <CatIcon className="w-3 h-3 text-muted-foreground/40 flex-shrink-0" />}
                      <span className="text-[13px] text-foreground/70 truncate flex-1">{item.name}</span>
                      <span className="text-[11px] text-muted-foreground/40 tabular-nums">{pct}%</span>
                      <span className="text-[13px] font-semibold tabular-nums w-20 text-right">{formatCurrency(item.value)}</span>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      )}

      {/* Bar Chart */}
      <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-4">
        <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-4">
          {activeFilter === "income" ? "Income Over Time" :
           activeFilter === "expenses" ? "Expenses Over Time" :
           isExpenseCategory ? `${activeFilter} Over Time` :
           "Income vs Expenses"}
        </h3>
        {monthlyData.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[180px] text-muted-foreground/40">
            <BarChart className="w-8 h-8 mb-2 opacity-50" />
            <p className="text-sm">No data in range</p>
          </div>
        ) : (
          <>
            <div className="h-[200px] -mx-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} barGap={2}>
                  <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} width={40} tickFormatter={(value) => `$${value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}`} />
                  <Tooltip
                    cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: 'rgba(255,255,255,0.08)', borderRadius: '10px', color: '#fff', fontSize: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.4)' }}
                    formatter={(value: number) => formatCurrencyFull(value)}
                  />
                  {showIncome && <Bar dataKey="income" name="Income" fill="#10b981" radius={[4, 4, 0, 0]} />}
                  {showExpenses && <Bar dataKey="expense" name={isExpenseCategory ? activeFilter : "Expenses"} fill={activeFilter === "Fuel" ? "#f59e0b" : "#ef4444"} radius={[4, 4, 0, 0]} />}
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-5 mt-3">
              {showIncome && (
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-[11px] text-muted-foreground/50">Income</span>
                </div>
              )}
              {showExpenses && (
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: activeFilter === "Fuel" ? "#f59e0b" : "#ef4444" }} />
                  <span className="text-[11px] text-muted-foreground/50">{isExpenseCategory ? activeFilter : "Expenses"}</span>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Transactions List */}
      {isExpenseCategory && displayExpenses.length > 0 && (
        <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/30 to-transparent p-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-3">Transactions</h3>
          <div className="space-y-0.5">
            {displayExpenses.slice(0, 20).map((e, i) => (
              <div key={e.id} className={clsx(
                "flex items-center justify-between gap-3 py-2.5 px-1",
                i < displayExpenses.length - 1 && i < 19 && "border-b border-border/10"
              )}>
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  {CategoryIcon && (
                    <div className={clsx(
                      "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                      activeFilter === "Fuel" ? "bg-amber-500/10" : "bg-rose-500/10"
                    )}>
                      <CategoryIcon className={clsx("w-3.5 h-3.5", activeFilter === "Fuel" ? "text-amber-400/70" : "text-rose-400/70")} />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-medium truncate">{e.merchant}</p>
                    <div className="flex items-center gap-1.5">
                      <p className="text-[11px] text-muted-foreground/50">{format(new Date(e.date), "MMM d, yyyy")}</p>
                      {activeFilter === "Fuel" && e.gallons && (
                        <p className="text-[11px] text-amber-400/60">
                          {Number(e.gallons).toFixed(1)}gal{e.pricePerGallon ? ` @ $${Number(e.pricePerGallon).toFixed(3)}` : ''}{e.jurisdiction ? ` | ${e.jurisdiction}` : ''}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <span className={clsx(
                  "text-[13px] font-semibold tabular-nums flex-shrink-0",
                  activeFilter === "Fuel" ? "text-amber-400" : "text-rose-400"
                )}>
                  {formatCurrencyFull(Number(e.amount))}
                </span>
              </div>
            ))}
            {displayExpenses.length > 20 && (
              <p className="text-[11px] text-center text-muted-foreground/40 pt-2">
                + {displayExpenses.length - 20} more
              </p>
            )}
          </div>
        </div>
      )}

      <IFTAReportDialog
        open={iftaOpen}
        onOpenChange={setIftaOpen}
        startDate={startDate}
        endDate={endDate}
      />

      <ScheduleCDialog
        open={scheduleCOpen}
        onOpenChange={setScheduleCOpen}
        expenses={filteredExpenses}
        income={filteredIncome}
        startDate={startDate}
        endDate={endDate}
      />
    </div>
  );
}
