import { Truck, BarChart3, Fuel, ArrowRight, CheckCircle2, Shield, ScanLine, Camera, CheckSquare, LineChart } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col lg:flex-row">

      {/* Left Panel — Branding & Features */}
      <div className="relative flex-1 flex flex-col justify-between p-6 sm:p-10 lg:p-14 lg:max-w-[55%]">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-40 -left-40 w-[500px] h-[500px] bg-primary/15 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[100px]" />
        </div>

        <div className="relative z-10">
          {/* Logo */}
          <div className="flex items-center gap-2.5 mb-10 lg:mb-16">
            <div className="bg-primary/20 p-2.5 rounded-xl">
              <Truck className="w-6 h-6 text-primary" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight" data-testid="text-app-name">HaulLedger</span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold tracking-tight leading-[1.1] mb-5">
            <span className="bg-gradient-to-br from-foreground via-foreground to-foreground/50 bg-clip-text text-transparent">
              Your books.{"\n"}<br />Done at the pump.
            </span>
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground max-w-md leading-relaxed mb-10 lg:mb-14" data-testid="text-subheadline">
            HaulLedger is the fastest way for owner-operators to track expenses, scan receipts, and stay IFTA & Schedule C ready — without the paperwork headache.
          </p>

          {/* How it works — desktop only */}
          <div className="hidden lg:block max-w-lg mb-10">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground/60 mb-5" data-testid="text-how-it-works">How it works</h3>
            <div className="grid grid-cols-3 gap-4">
              <HowItWorksStep icon={Camera} title="Snap a receipt" description="AI reads it automatically" step={1} />
              <HowItWorksStep icon={CheckSquare} title="Confirm & save" description="Categorized for taxes" step={2} />
              <HowItWorksStep icon={LineChart} title="Export reports" description="Hand to your accountant" step={3} />
            </div>
          </div>

          {/* Feature pills — desktop only */}
          <div className="hidden lg:grid grid-cols-1 gap-3 max-w-md">
            <FeaturePill icon={ScanLine} text="Snap a receipt and auto-fill every field with AI" />
            <FeaturePill icon={BarChart3} text="Schedule C and IFTA reports ready for your accountant" />
            <FeaturePill icon={Fuel} text="Track diesel by gallon, price, and jurisdiction" />
          </div>
        </div>

        {/* Footer — desktop only */}
        <p className="relative z-10 hidden lg:block text-xs text-muted-foreground/40 mt-10">
          &copy; {new Date().getFullYear()} HaulLedger. All rights reserved.
        </p>
      </div>

      {/* Right Panel — Auth */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10 lg:p-14 lg:border-l lg:border-border/10">
        <div className="w-full max-w-sm space-y-8">
          {/* Auth Card */}
          <div className="rounded-2xl border border-border/20 bg-muted/30 p-6 sm:p-8 space-y-6">
            <div className="text-center space-y-2">
              <div className="mx-auto w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mb-3">
                <Truck className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-display font-bold" data-testid="text-auth-heading">Get Started</h2>
              <p className="text-sm text-muted-foreground">Sign in with your Google account or email. New users are automatically registered.</p>
            </div>

            <a href="/api/login" className="block" data-testid="link-sign-in">
              <Button size="lg" className="w-full text-sm font-semibold shadow-lg shadow-primary/20">
                Continue with Google or Email
                <ArrowRight className="w-4 h-4 ml-1.5" />
              </Button>
            </a>

            {/* Social proof pills */}
            <div className="flex flex-wrap justify-center gap-2" data-testid="social-proof-pills">
              <SocialProofPill text="IFTA-ready reports" />
              <SocialProofPill text="Schedule C mapped" />
              <SocialProofPill text="Receipt scanning built in" />
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-border/20" />
              <span className="text-[11px] text-muted-foreground/50 uppercase tracking-widest font-medium">secure login</span>
              <div className="flex-1 h-px bg-border/20" />
            </div>

            <div className="space-y-2 text-center">
              <div className="flex items-center justify-center gap-4 text-[11px] text-muted-foreground/40">
                <span className="flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Encrypted
                </span>
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> No password needed
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground/30">New here? Just sign in and your account is created automatically.</p>
            </div>
          </div>

          {/* Trust badges */}
          <div className="text-center space-y-3">
            <p className="text-[11px] text-muted-foreground/40 font-medium">Free forever. No credit card required.</p>
          </div>

          {/* How it works — mobile only */}
          <div className="lg:hidden space-y-3">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground/60 mb-3" data-testid="text-how-it-works-mobile">How it works</h3>
            <div className="space-y-3">
              <HowItWorksStep icon={Camera} title="Snap a receipt" description="AI reads it automatically" step={1} />
              <HowItWorksStep icon={CheckSquare} title="Confirm & save" description="Categorized for taxes" step={2} />
              <HowItWorksStep icon={LineChart} title="Export reports" description="Hand to your accountant" step={3} />
            </div>
          </div>

          {/* Feature pills — mobile only */}
          <div className="grid grid-cols-1 gap-2.5 lg:hidden">
            <FeaturePill icon={ScanLine} text="Snap a receipt and auto-fill every field" />
            <FeaturePill icon={BarChart3} text="Tax reports ready for your accountant" />
            <FeaturePill icon={Fuel} text="Track diesel by gallon and jurisdiction" />
          </div>

          {/* Footer — mobile only */}
          <p className="lg:hidden text-center text-xs text-muted-foreground/40">
            &copy; {new Date().getFullYear()} HaulLedger. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}

function FeaturePill({ icon: Icon, text }: { icon: any; text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl bg-muted/30 border border-border/10 px-4 py-3">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex-shrink-0 flex items-center justify-center">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <p className="text-[13px] text-muted-foreground leading-snug">{text}</p>
    </div>
  );
}

function HowItWorksStep({ icon: Icon, title, description, step }: { icon: any; title: string; description: string; step: number }) {
  return (
    <div className="flex lg:flex-col items-center lg:items-center gap-3 lg:gap-2 rounded-xl bg-muted/30 border border-border/10 px-4 py-3 lg:px-3 lg:py-4 lg:text-center" data-testid={`how-it-works-step-${step}`}>
      <div className="w-9 h-9 rounded-lg bg-primary/15 flex-shrink-0 flex items-center justify-center">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </div>
      <div>
        <p className="text-sm font-semibold text-foreground">{title}</p>
        <p className="text-[12px] text-muted-foreground leading-snug">{description}</p>
      </div>
    </div>
  );
}

function SocialProofPill({ text }: { text: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 border border-primary/20 px-2.5 py-1 text-[11px] font-medium text-primary" data-testid={`pill-${text.toLowerCase().replace(/\s+/g, '-')}`}>
      <CheckCircle2 className="w-3 h-3" />
      {text}
    </span>
  );
}
