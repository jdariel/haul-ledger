import { useState } from "react";
import { useAssets, useCreateAsset, useUpdateAsset, useDeleteAsset } from "@/hooks/use-assets";
import { useTrips } from "@/hooks/use-trips";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Truck, Loader2, Pencil, Trash2, Container, Navigation } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { type Asset, type Trip } from "@shared/schema";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";

export default function Assets() {
  const { data: assets, isLoading } = useAssets();
  const { data: tripsData } = useTrips();
  const createAsset = useCreateAsset();
  const updateAsset = useUpdateAsset();
  const deleteAsset = useDeleteAsset();
  const { toast } = useToast();

  const getTripMiles = (t: Trip): number => {
    if (t.startOdometer && t.endOdometer) return Math.max(0, Number(t.endOdometer) - Number(t.startOdometer));
    return Math.max(0, Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0));
  };

  const getAssetMiles = (assetId: number): number => {
    if (!tripsData) return 0;
    return tripsData
      .filter((t: Trip) => t.assetId === assetId)
      .reduce((sum: number, t: Trip) => sum + getTripMiles(t), 0);
  };

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Asset | null>(null);
  const [form, setForm] = useState({ type: "truck", name: "", vin: "", plate: "", year: "", make: "", model: "" });

  const resetForm = () => setForm({ type: "truck", name: "", vin: "", plate: "", year: "", make: "", model: "" });

  const openCreate = () => { resetForm(); setEditingAsset(null); setIsDialogOpen(true); };

  const openEdit = (a: Asset) => {
    setEditingAsset(a);
    setForm({ type: a.type, name: a.name, vin: a.vin || "", plate: a.plate || "", year: a.year || "", make: a.make || "", model: a.model || "" });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast({ title: "Name is required", variant: "destructive" }); return; }
    try {
      const data = { ...form, vin: form.vin || undefined, plate: form.plate || undefined, year: form.year || undefined, make: form.make || undefined, model: form.model || undefined };
      if (editingAsset) {
        await updateAsset.mutateAsync({ id: editingAsset.id, ...data });
        toast({ title: "Asset Updated" });
      } else {
        await createAsset.mutateAsync(data);
        toast({ title: "Asset Added" });
      }
      setIsDialogOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteAsset.mutateAsync(pendingDelete.id);
      toast({ title: "Asset Deleted" });
      setPendingDelete(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const trucks = assets?.filter((a: Asset) => a.type === "truck") || [];
  const trailers = assets?.filter((a: Asset) => a.type === "trailer") || [];

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-assets-title">Fleet</h1>
          <p className="text-muted-foreground mt-1">Manage your trucks and trailers.</p>
        </div>
        <Button className="rounded-xl shadow-lg shadow-primary/20" onClick={openCreate} data-testid="button-add-asset">
          <Plus className="w-4 h-4 mr-2" />
          Add Vehicle
        </Button>
      </header>

      {isLoading ? (
        <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary/50" /></div>
      ) : (!assets || assets.length === 0) ? (
        <div className="bg-card/30 border border-border/20 rounded-2xl p-12 text-center">
          <Truck className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
          <p className="text-muted-foreground">No vehicles added yet.</p>
          <p className="text-muted-foreground/60 text-sm mt-1">Add your trucks and trailers to track them.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {trucks.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Trucks ({trucks.length})</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {trucks.map((a: Asset) => (
                  <Card key={a.id} className="bg-card/30 border-border/20 rounded-xl p-4" data-testid={`card-asset-${a.id}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Truck className="w-5 h-5 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-foreground truncate">{a.name}</p>
                          {(a.year || a.make || a.model) && (
                            <p className="text-xs text-muted-foreground mt-0.5">{[a.year, a.make, a.model].filter(Boolean).join(" ")}</p>
                          )}
                          {a.plate && <p className="text-xs text-muted-foreground/60 mt-0.5">Plate: {a.plate}</p>}
                          {a.vin && <p className="text-xs text-muted-foreground/60 mt-0.5 font-mono truncate">VIN: {a.vin}</p>}
                          {(() => { const m = getAssetMiles(a.id); return m > 0 ? (
                            <p className="text-xs text-cyan-400/70 mt-1 flex items-center gap-1" data-testid={`text-asset-miles-${a.id}`}>
                              <Navigation className="w-3 h-3" /> {m.toLocaleString()} miles logged
                            </p>
                          ) : null; })()}
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button size="icon" variant="ghost" onClick={() => openEdit(a)} data-testid={`button-edit-asset-${a.id}`}><Pencil className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => setPendingDelete(a)} data-testid={`button-delete-asset-${a.id}`}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
          {trailers.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Trailers ({trailers.length})</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {trailers.map((a: Asset) => (
                  <Card key={a.id} className="bg-card/30 border-border/20 rounded-xl p-4" data-testid={`card-asset-${a.id}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                          <Container className="w-5 h-5 text-cyan-500" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-foreground truncate">{a.name}</p>
                          {(a.year || a.make || a.model) && (
                            <p className="text-xs text-muted-foreground mt-0.5">{[a.year, a.make, a.model].filter(Boolean).join(" ")}</p>
                          )}
                          {a.plate && <p className="text-xs text-muted-foreground/60 mt-0.5">Plate: {a.plate}</p>}
                          {a.vin && <p className="text-xs text-muted-foreground/60 mt-0.5 font-mono truncate">VIN: {a.vin}</p>}
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button size="icon" variant="ghost" onClick={() => openEdit(a)} data-testid={`button-edit-asset-${a.id}`}><Pencil className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => setPendingDelete(a)} data-testid={`button-delete-asset-${a.id}`}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        title="Delete Asset"
        description={`Are you sure you want to delete "${pendingDelete?.name || "this asset"}"? This action cannot be undone.`}
        onConfirm={handleConfirmDelete}
        isDeleting={deleteAsset.isPending}
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-border/25 max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">{editingAsset ? "Edit Vehicle" : "Add Vehicle"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger data-testid="select-asset-type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="truck">Truck</SelectItem>
                  <SelectItem value="trailer">Trailer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Name</Label>
              <Input placeholder="e.g., My Peterbilt 579" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="input-asset-name" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><Label>Year</Label><Input placeholder="2024" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} data-testid="input-asset-year" /></div>
              <div><Label>Make</Label><Input placeholder="Peterbilt" value={form.make} onChange={(e) => setForm({ ...form, make: e.target.value })} data-testid="input-asset-make" /></div>
              <div><Label>Model</Label><Input placeholder="579" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} data-testid="input-asset-model" /></div>
            </div>
            <div>
              <Label>License Plate</Label>
              <Input placeholder="ABC-1234" value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} data-testid="input-asset-plate" />
            </div>
            <div>
              <Label>VIN</Label>
              <Input placeholder="Vehicle Identification Number" value={form.vin} onChange={(e) => setForm({ ...form, vin: e.target.value })} data-testid="input-asset-vin" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={createAsset.isPending || updateAsset.isPending} data-testid="button-save-asset">
              {(createAsset.isPending || updateAsset.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {editingAsset ? "Update" : "Add"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
