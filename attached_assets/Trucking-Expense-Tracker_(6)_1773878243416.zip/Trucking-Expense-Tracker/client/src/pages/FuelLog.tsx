import { useState } from "react";
import { useFuelEntries, useCreateFuelEntry, useDeleteFuelEntry } from "@/hooks/use-fuel-entries";
import { useAssets } from "@/hooks/use-assets";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Fuel, Loader2, Droplets, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { type FuelEntry, type Asset, US_STATES } from "@shared/schema";
import { SwipeableRow } from "@/components/SwipeableRow";
import { ConfirmDeleteDialog } from "@/components/ConfirmDeleteDialog";

export default function FuelLog() {
  const { data: entries, isLoading } = useFuelEntries();
  const { data: assets } = useAssets();
  const createEntry = useCreateFuelEntry();
  const deleteEntry = useDeleteFuelEntry();
  const { toast } = useToast();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<FuelEntry | null>(null);
  const [form, setForm] = useState({
    date: format(new Date(), "yyyy-MM-dd"),
    jurisdiction: "",
    gallons: "",
    pricePerGallon: "",
    totalCost: "",
    vendor: "",
    assetId: "",
    notes: "",
  });

  const resetForm = () => setForm({
    date: format(new Date(), "yyyy-MM-dd"),
    jurisdiction: "", gallons: "", pricePerGallon: "",
    totalCost: "", vendor: "", assetId: "", notes: "",
  });

  const handleGallonsChange = (val: string) => {
    const gallons = parseFloat(val) || 0;
    const ppg = parseFloat(form.pricePerGallon) || 0;
    setForm({ ...form, gallons: val, totalCost: gallons && ppg ? (gallons * ppg).toFixed(2) : form.totalCost });
  };

  const handlePPGChange = (val: string) => {
    const ppg = parseFloat(val) || 0;
    const gallons = parseFloat(form.gallons) || 0;
    setForm({ ...form, pricePerGallon: val, totalCost: gallons && ppg ? (gallons * ppg).toFixed(2) : form.totalCost });
  };

  const handleSave = async () => {
    if (!form.jurisdiction || !form.gallons || !form.pricePerGallon) {
      toast({ title: "State, gallons, and price per gallon are required", variant: "destructive" });
      return;
    }
    try {
      const gallons = parseFloat(form.gallons);
      const ppg = parseFloat(form.pricePerGallon);
      const totalCost = form.totalCost ? parseFloat(form.totalCost) : gallons * ppg;
      await createEntry.mutateAsync({
        date: new Date(form.date),
        jurisdiction: form.jurisdiction,
        gallons,
        pricePerGallon: ppg,
        totalCost,
        vendor: form.vendor || undefined,
        assetId: form.assetId ? Number(form.assetId) : undefined,
        notes: form.notes || undefined,
      } as any);
      toast({ title: "Fuel Entry Added" });
      setIsDialogOpen(false);
      resetForm();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteEntry.mutateAsync(pendingDelete.id);
      toast({ title: "Fuel Entry Deleted" });
      setPendingDelete(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const totalGallons = entries?.reduce((sum: number, e: FuelEntry) => sum + Number(e.gallons), 0) || 0;
  const totalCost = entries?.reduce((sum: number, e: FuelEntry) => sum + Number(e.totalCost), 0) || 0;
  const avgPPG = totalGallons > 0 ? totalCost / totalGallons : 0;
  const trucks = assets?.filter((a: Asset) => a.type === "truck") || [];

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-fuel-title">Fuel Log</h1>
          <p className="text-muted-foreground mt-1">Track every fill-up for IFTA reporting.</p>
        </div>
        <Button className="rounded-xl shadow-lg shadow-primary/20" onClick={() => { resetForm(); setIsDialogOpen(true); }} data-testid="button-add-fuel">
          <Plus className="w-4 h-4 mr-2" />
          Add Fill-Up
        </Button>
      </header>

      <div className="grid grid-cols-3 gap-3">
        <Card className="bg-card/30 border-amber-500/20 rounded-xl p-4 text-center">
          <Droplets className="w-5 h-5 text-amber-500 mx-auto mb-1" />
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Gallons</p>
          <p className="text-lg font-bold text-amber-400 tabular-nums" data-testid="text-fuel-total-gallons">{totalGallons.toFixed(1)}</p>
        </Card>
        <Card className="bg-card/30 border-amber-500/20 rounded-xl p-4 text-center">
          <DollarSign className="w-5 h-5 text-amber-500 mx-auto mb-1" />
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Total</p>
          <p className="text-lg font-bold text-amber-400 tabular-nums" data-testid="text-fuel-total-cost">${totalCost.toFixed(2)}</p>
        </Card>
        <Card className="bg-card/30 border-amber-500/20 rounded-xl p-4 text-center">
          <Fuel className="w-5 h-5 text-amber-500 mx-auto mb-1" />
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Avg $/Gal</p>
          <p className="text-lg font-bold text-amber-400 tabular-nums" data-testid="text-fuel-avg-ppg">${avgPPG.toFixed(3)}</p>
        </Card>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary/50" /></div>
      ) : (!entries || entries.length === 0) ? (
        <div className="bg-card/30 border border-border/20 rounded-2xl p-12 text-center">
          <Fuel className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
          <p className="text-muted-foreground">No fuel entries yet.</p>
          <p className="text-muted-foreground/60 text-sm mt-1">Add fill-ups to track fuel costs by state.</p>
        </div>
      ) : (
        <div className="bg-card/30 border border-border/20 rounded-2xl overflow-hidden">
          <div className="space-y-3 p-3">
            {entries.map((entry: FuelEntry) => (
              <SwipeableRow
                key={entry.id}
                onTap={() => {}}
                onDelete={() => setPendingDelete(entry)}
                testId={`row-fuel-${entry.id}`}
              >
                <div className="flex items-center justify-between p-4 gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center flex-shrink-0">
                      <Fuel className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm truncate">{entry.vendor || "Fuel Stop"}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(entry.date), "MMM d, yyyy")}
                        <span className="text-amber-400/70 ml-1.5">{Number(entry.gallons).toFixed(1)} gal @ ${Number(entry.pricePerGallon).toFixed(3)}</span>
                      </p>
                      <p className="text-[11px] text-muted-foreground/60">{entry.jurisdiction}</p>
                    </div>
                  </div>
                  <span className="font-semibold tabular-nums text-amber-400 flex-shrink-0">${Number(entry.totalCost).toFixed(2)}</span>
                </div>
              </SwipeableRow>
            ))}
          </div>
        </div>
      )}

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => { if (!open) setPendingDelete(null); }}
        title="Delete Fuel Entry"
        description={`Are you sure you want to delete this fuel entry${pendingDelete?.vendor ? ` at ${pendingDelete.vendor}` : ""}? This action cannot be undone.`}
        onConfirm={handleConfirmDelete}
        isDeleting={deleteEntry.isPending}
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-border/25 max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Add Fill-Up</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Date</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} data-testid="input-fuel-date" />
              </div>
              <div>
                <Label>State/Province</Label>
                <Select value={form.jurisdiction} onValueChange={(v) => setForm({ ...form, jurisdiction: v })}>
                  <SelectTrigger data-testid="select-fuel-jurisdiction"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {US_STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label>Gallons</Label>
                <Input type="number" step="0.001" placeholder="150.5" value={form.gallons} onChange={(e) => handleGallonsChange(e.target.value)} data-testid="input-fuel-gallons" />
              </div>
              <div>
                <Label>$/Gallon</Label>
                <Input type="number" step="0.001" placeholder="3.459" value={form.pricePerGallon} onChange={(e) => handlePPGChange(e.target.value)} data-testid="input-fuel-ppg" />
              </div>
              <div>
                <Label>Total</Label>
                <Input type="number" step="0.01" placeholder="520.60" value={form.totalCost} onChange={(e) => setForm({ ...form, totalCost: e.target.value })} data-testid="input-fuel-total" />
              </div>
            </div>
            <div>
              <Label>Vendor / Station</Label>
              <Input placeholder="Love's Travel Stop" value={form.vendor} onChange={(e) => setForm({ ...form, vendor: e.target.value })} data-testid="input-fuel-vendor" />
            </div>
            {trucks.length > 0 && (
              <div>
                <Label>Truck</Label>
                <Select value={form.assetId} onValueChange={(v) => setForm({ ...form, assetId: v })}>
                  <SelectTrigger data-testid="select-fuel-truck"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {trucks.map((a: Asset) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div>
              <Label>Notes</Label>
              <Input placeholder="Optional notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} data-testid="input-fuel-notes" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={createEntry.isPending} data-testid="button-save-fuel">
              {createEntry.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Add Fill-Up
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
