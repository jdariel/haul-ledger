import { useState } from "react";
import { useSavedRoutes, useCreateSavedRoute, useDeleteSavedRoute } from "@/hooks/use-saved-routes";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSavedRouteSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Plus, Route, Trash2, DollarSign, Loader2, StickyNote } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function SavedRoutes() {
  const { data: routes, isLoading } = useSavedRoutes();
  const createRoute = useCreateSavedRoute();
  const deleteRoute = useDeleteSavedRoute();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertSavedRouteSchema),
    defaultValues: {
      name: "",
      price: "",
      notes: "",
    },
  });

  const onSubmit = async (data: any) => {
    try {
      await createRoute.mutateAsync(data);
      toast({ title: "Route Saved", description: `"${data.name}" has been saved.` });
      setIsDialogOpen(false);
      form.reset();
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number, name: string) => {
    try {
      await deleteRoute.mutateAsync(id);
      toast({ title: "Route Deleted", description: `"${name}" has been removed.` });
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground" data-testid="text-saved-routes-title">Saved Routes</h1>
          <p className="text-muted-foreground mt-1">Pre-save your regular loads for quick income logging.</p>
        </div>
        <Button className="rounded-xl shadow-lg shadow-primary/20" onClick={() => setIsDialogOpen(true)} data-testid="button-add-route">
          <Plus className="w-4 h-4 mr-2" />
          New Route
        </Button>
      </header>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      ) : routes && routes.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {routes.map((route) => (
            <Card key={route.id} className="bg-card/30 border-border/20 p-5 rounded-2xl" data-testid={`card-route-${route.id}`}>
              <div className="flex items-start justify-between gap-2 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <Route className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-foreground text-lg" data-testid={`text-route-name-${route.id}`}>{route.name}</h3>
                    <span className="text-emerald-400 font-semibold text-sm" data-testid={`text-route-price-${route.id}`}>${Number(route.price).toFixed(2)}</span>
                  </div>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-muted-foreground hover:text-destructive"
                  onClick={() => handleDelete(route.id, route.name)}
                  data-testid={`button-delete-route-${route.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              {route.notes && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <StickyNote className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{route.notes}</span>
                </div>
              )}
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-card/30 border-border/20 p-12 rounded-2xl text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary mx-auto mb-4">
            <Route className="w-8 h-8" />
          </div>
          <h3 className="font-display font-semibold text-foreground text-lg mb-2">No Saved Routes Yet</h3>
          <p className="text-muted-foreground text-sm mb-6 max-w-md mx-auto">
            Save your regular loads and routes here. When you log income, you can pick from these to fill in the details automatically.
          </p>
          <Button onClick={() => setIsDialogOpen(true)} data-testid="button-add-route-empty">
            <Plus className="w-4 h-4 mr-2" />
            Save Your First Route
          </Button>
        </Card>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md bg-card/95 backdrop-blur-xl border-border/25 text-foreground">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-primary">Save New Route</DialogTitle>
            <DialogDescription className="sr-only">Create a new saved route template</DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Route Name</FormLabel>
                    <FormControl>
                      <Input placeholder='e.g. "Houston - Dallas"' {...field} className="glass-input" data-testid="input-route-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price ($)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} className="glass-input" data-testid="input-route-price" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Any details about this route..." {...field} className="glass-input resize-none" data-testid="input-route-notes" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-2">
                <Button
                  type="submit"
                  className="w-full h-12 text-lg font-semibold shadow-lg shadow-primary/20"
                  disabled={createRoute.isPending}
                  data-testid="button-save-route"
                >
                  {createRoute.isPending && <Loader2 className="w-5 h-5 animate-spin mr-2" />}
                  Save Route
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
