import { Link, useLocation } from "wouter";
import { LayoutDashboard, Wallet, TrendingUp, BarChart3, Settings } from "lucide-react";
import clsx from "clsx";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: LayoutDashboard },
    { href: "/expenses", label: "Expenses", icon: Wallet },
    { href: "/income", label: "Income", icon: TrendingUp },
    { href: "/reports", label: "Reports", icon: BarChart3 },
    { href: "/settings", label: "More", icon: Settings },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t border-border/20 bg-background/90 backdrop-blur-lg md:hidden z-50" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
      <nav className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={clsx("nav-item", isActive && "active")} data-testid={`nav-${item.label.toLowerCase()}`}>
              <div className={clsx("relative flex flex-col items-center gap-0.5")}>
                {isActive && (
                  <div className="absolute -top-2.5 w-8 h-0.5 rounded-full bg-primary" />
                )}
                <Icon className={clsx("w-5 h-5 transition-transform", isActive && "scale-110")} strokeWidth={isActive ? 2.5 : 2} />
                <span className={clsx("text-[9px]", isActive && "font-bold")}>{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
