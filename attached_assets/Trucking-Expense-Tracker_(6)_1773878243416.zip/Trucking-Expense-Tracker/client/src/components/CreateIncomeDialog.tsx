import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertIncomeSchema, type Income } from "@shared/schema";
import { useCreateIncome, useUpdateIncome } from "@/hooks/use-income";
import { useSavedRoutes } from "@/hooks/use-saved-routes";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Route } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface CreateIncomeDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  editIncome?: Income | null;
  onSaved?: (date: Date) => void;
}

export function CreateIncomeDialog({ open: controlledOpen, onOpenChange: setControlledOpen, editIncome, onSaved }: CreateIncomeDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = setControlledOpen !== undefined ? setControlledOpen : setInternalOpen;

  const isEditing = !!editIncome;
  const { toast } = useToast();
  const createIncome = useCreateIncome();
  const updateIncome = useUpdateIncome();
  const { data: savedRoutes } = useSavedRoutes();

  const form = useForm({
    resolver: zodResolver(insertIncomeSchema),
    defaultValues: {
      date: new Date(),
      source: "",
      amount: "",
      trailerNumber: "",
      routeName: "",
      notes: "",
    },
  });

  useEffect(() => {
    if (open && editIncome) {
      form.reset({
        date: new Date(editIncome.date),
        source: editIncome.source,
        amount: String(Number(editIncome.amount)),
        trailerNumber: editIncome.trailerNumber || "",
        routeName: editIncome.routeName || "",
        notes: editIncome.notes || "",
      });
    } else if (open && !editIncome) {
      form.reset({
        date: new Date(),
        source: "",
        amount: "",
        trailerNumber: "",
        routeName: "",
        notes: "",
      });
    }
  }, [open, editIncome]);

  const handleRouteSelect = (routeId: string) => {
    if (routeId === "none") return;
    const route = savedRoutes?.find((r) => String(r.id) === routeId);
    if (route) {
      form.setValue("routeName", route.name, { shouldValidate: true });
      form.setValue("amount", String(Number(route.price)), { shouldValidate: true });
      form.setValue("notes", route.notes || "", { shouldValidate: true });
    }
  };

  const onSubmit = async (data: any) => {
    try {
      if (isEditing) {
        await updateIncome.mutateAsync({ id: editIncome!.id, ...data });
        toast({ title: "Income Updated", description: "Changes saved successfully." });
      } else {
        await createIncome.mutateAsync(data);
        toast({ title: "Income Added", description: "Successfully logged new income." });
      }
      const savedDate = data.date instanceof Date ? data.date : new Date(data.date);
      setOpen(false);
      form.reset();
      onSaved?.(savedDate);
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  };

  const isPending = createIncome.isPending || updateIncome.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md bg-card/95 backdrop-blur-xl border-border/25 text-foreground">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-emerald-400">{isEditing ? "Edit Income" : "Log Income"}</DialogTitle>
          <DialogDescription className="sr-only">{isEditing ? "Edit an existing income record" : "Add a new income record"}</DialogDescription>
        </DialogHeader>

        {!isEditing && savedRoutes && savedRoutes.length > 0 ? (
          <div className="rounded-xl border border-border/25 bg-muted/30 p-3">
            <label className="text-xs font-medium text-muted-foreground mb-2 block">Quick Fill from Saved Route</label>
            <Select onValueChange={handleRouteSelect}>
              <SelectTrigger className="glass-input" data-testid="select-saved-route">
                <SelectValue placeholder="Pick a saved route..." />
              </SelectTrigger>
              <SelectContent>
                {savedRoutes.map((route) => (
                  <SelectItem key={route.id} value={String(route.id)} data-testid={`select-route-option-${route.id}`}>
                    <div className="flex items-center gap-2">
                      <Route className="w-3 h-3 text-primary" />
                      <span>{route.name}</span>
                      <span className="text-muted-foreground text-xs">(${Number(route.price).toFixed(2)})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : !isEditing ? (
          <div className="rounded-xl border border-dashed border-border/25 bg-muted/20 p-3 text-center">
            <p className="text-xs text-muted-foreground mb-1">No saved routes yet.</p>
            <Link href="/routes" onClick={() => setOpen(false)} className="text-xs text-primary font-medium hover:underline" data-testid="link-create-routes">
              Create saved routes for quick entry
            </Link>
          </div>
        ) : null}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="source"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Source (Broker/Load ID)</FormLabel>
                  <FormControl>
                    <Input placeholder="TQL Load #12345" {...field} className="glass-input" data-testid="input-income-source" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount ($)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} className="glass-input" data-testid="input-income-amount" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field} 
                        value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''}
                        onChange={(e) => field.onChange(new Date(e.target.value))}
                        className="glass-input"
                        data-testid="input-income-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="trailerNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Trailer #</FormLabel>
                    <FormControl>
                      <Input placeholder="TR-5678" {...field} className="glass-input" data-testid="input-income-trailer" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="routeName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Route Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Chicago - Dallas" {...field} className="glass-input" data-testid="input-income-route" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Load details..." {...field} className="glass-input resize-none" data-testid="input-income-notes" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="pt-2">
              <Button 
                type="submit" 
                className="w-full h-12 text-lg font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-500/20" 
                disabled={createIncome.isPending || updateIncome.isPending}
                data-testid="button-save-income"
              >
                {(createIncome.isPending || updateIncome.isPending) && <Loader2 className="w-5 h-5 animate-spin mr-2" />}
                {isEditing ? "Update Income" : "Save Income"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
