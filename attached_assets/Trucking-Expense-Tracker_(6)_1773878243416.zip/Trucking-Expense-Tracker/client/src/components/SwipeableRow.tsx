import { useState, useRef, useCallback } from "react";
import { Trash2 } from "lucide-react";

interface SwipeableRowProps {
  children: React.ReactNode;
  onDelete: () => void;
  onTap: () => void;
  testId?: string;
}

export function SwipeableRow({ children, onDelete, onTap, testId }: SwipeableRowProps) {
  const [offsetX, setOffsetX] = useState(0);
  const [isRevealed, setIsRevealed] = useState(false);
  const startX = useRef(0);
  const startY = useRef(0);
  const isDragging = useRef(false);
  const isHorizontalSwipe = useRef(false);
  const hasMoved = useRef(false);

  const DELETE_THRESHOLD = 80;
  const showDeleteBg = offsetX < 0 || isRevealed;

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    startX.current = e.clientX;
    startY.current = e.clientY;
    isDragging.current = true;
    isHorizontalSwipe.current = false;
    hasMoved.current = false;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging.current) return;

    const dx = e.clientX - startX.current;
    const dy = e.clientY - startY.current;

    if (!hasMoved.current && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
      hasMoved.current = true;
      isHorizontalSwipe.current = Math.abs(dx) > Math.abs(dy);
    }

    if (!isHorizontalSwipe.current) return;

    e.preventDefault();

    const base = isRevealed ? -DELETE_THRESHOLD : 0;
    const newOffset = Math.min(0, Math.max(-DELETE_THRESHOLD * 1.5, base + dx));
    setOffsetX(newOffset);
  }, [isRevealed]);

  const handlePointerUp = useCallback(() => {
    if (!isDragging.current) return;
    isDragging.current = false;

    if (!hasMoved.current) {
      if (isRevealed) {
        setIsRevealed(false);
        setOffsetX(0);
      } else {
        onTap();
      }
      return;
    }

    if (!isHorizontalSwipe.current) return;

    if (offsetX < -DELETE_THRESHOLD * 0.5) {
      setOffsetX(-DELETE_THRESHOLD);
      setIsRevealed(true);
    } else {
      setOffsetX(0);
      setIsRevealed(false);
    }
  }, [offsetX, isRevealed, onTap]);

  const handleDeleteClick = useCallback(() => {
    setOffsetX(0);
    setIsRevealed(false);
    onDelete();
  }, [onDelete]);

  return (
    <div
      className="relative rounded-xl"
      style={{ overflow: "hidden" }}
      data-testid={testId}
    >
      {showDeleteBg && (
        <div
          className="absolute right-0 top-0 bottom-0 flex items-center justify-center bg-destructive text-destructive-foreground"
          style={{ width: DELETE_THRESHOLD }}
        >
          <button
            onClick={handleDeleteClick}
            className="flex flex-col items-center justify-center w-full h-full gap-1"
            data-testid={testId ? `${testId}-delete-action` : undefined}
          >
            <Trash2 className="w-5 h-5" />
            <span className="text-xs font-medium">Delete</span>
          </button>
        </div>
      )}

      <div
        className="relative rounded-xl"
        style={{
          transform: `translateX(${offsetX}px)`,
          transition: isDragging.current ? "none" : "transform 0.25s ease-out",
          backgroundColor: "hsl(var(--card) / 0.4)",
          border: "1px solid hsl(0 0% 100% / 0.05)",
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={() => {
          isDragging.current = false;
          setOffsetX(isRevealed ? -DELETE_THRESHOLD : 0);
        }}
      >
        {children}
      </div>
    </div>
  );
}
