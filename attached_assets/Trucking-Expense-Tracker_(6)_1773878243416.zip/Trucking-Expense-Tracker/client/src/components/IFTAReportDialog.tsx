import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Fuel, Printer, Navigation, Download } from "lucide-react";
import { format } from "date-fns";
import { useTrips } from "@/hooks/use-trips";
import { useFuelEntries } from "@/hooks/use-fuel-entries";
import { downloadCSV } from "@/lib/utils";
import type { Trip, FuelEntry } from "@shared/schema";
import clsx from "clsx";

interface IFTAReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  startDate: Date;
  endDate: Date;
}

export function IFTAReportDialog({ open, onOpenChange, startDate, endDate }: IFTAReportDialogProps) {
  const { data: allTrips, isLoading: tripsLoading } = useTrips();
  const { data: allFuelEntries, isLoading: fuelLoading } = useFuelEntries();
  const isLoading = tripsLoading || fuelLoading;

  const trips: Trip[] = (allTrips || [])
    .filter((t: Trip) => {
      const d = new Date(t.date);
      return d >= startDate && d <= endDate;
    })
    .sort((a: Trip, b: Trip) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const fuelEntries: FuelEntry[] = (allFuelEntries || [])
    .filter((f: FuelEntry) => {
      const d = new Date(f.date);
      return d >= startDate && d <= endDate;
    })
    .sort((a: FuelEntry, b: FuelEntry) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const getTripMiles = (t: Trip) => {
    if (t.startOdometer && t.endOdometer) {
      return Number(t.endOdometer) - Number(t.startOdometer);
    }
    return Number(t.loadedMiles || 0) + Number(t.emptyMiles || 0);
  };

  const totalMiles = trips.reduce((s: number, t: Trip) => s + getTripMiles(t), 0);
  const totalGallons = fuelEntries.reduce((s: number, f: FuelEntry) => s + Number(f.gallons || 0), 0);
  const totalFuelCost = fuelEntries.reduce((s: number, f: FuelEntry) => s + Number(f.totalCost || 0), 0);
  const avgPpg = fuelEntries.length > 0
    ? fuelEntries.reduce((s: number, f: FuelEntry) => s + Number(f.pricePerGallon || 0), 0) / fuelEntries.length
    : 0;
  const mpg = totalGallons > 0 ? totalMiles / totalGallons : 0;
  const costPerMile = totalMiles > 0 ? totalFuelCost / totalMiles : 0;

  const milesByJurisdiction = new Map<string, { miles: number; trips: number }>();
  trips.forEach((t: Trip) => {
    const j = t.jurisdiction || "N/A";
    const entry = milesByJurisdiction.get(j) || { miles: 0, trips: 0 };
    entry.miles += getTripMiles(t);
    entry.trips += 1;
    milesByJurisdiction.set(j, entry);
  });
  const milesJurisdictionSummary = Array.from(milesByJurisdiction.entries())
    .map(([state, data]) => ({ state, ...data }))
    .sort((a, b) => b.miles - a.miles);

  const fuelByJurisdiction = new Map<string, { gallons: number; cost: number; count: number }>();
  fuelEntries.forEach((f: FuelEntry) => {
    const j = f.jurisdiction || "N/A";
    const entry = fuelByJurisdiction.get(j) || { gallons: 0, cost: 0, count: 0 };
    entry.gallons += Number(f.gallons || 0);
    entry.cost += Number(f.totalCost || 0);
    entry.count += 1;
    fuelByJurisdiction.set(j, entry);
  });
  const fuelJurisdictionSummary = Array.from(fuelByJurisdiction.entries())
    .map(([state, data]) => ({ state, ...data }))
    .sort((a, b) => b.cost - a.cost);

  const fmt = (val: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(val);

  const handlePrint = () => {
    const printContent = document.getElementById("ifta-print-content");
    if (!printContent) return;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`
      <html><head><title>IFTA Report</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 24px; color: #111; font-size: 12px; }
        h1 { font-size: 18px; margin-bottom: 4px; }
        h2 { font-size: 14px; margin-top: 20px; margin-bottom: 8px; color: #555; }
        .subtitle { color: #666; font-size: 12px; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; margin-top: 8px; }
        th { text-align: left; border-bottom: 2px solid #333; padding: 6px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #555; }
        td { border-bottom: 1px solid #e5e5e5; padding: 6px 8px; }
        .num { text-align: right; font-variant-numeric: tabular-nums; }
        .total-row td { border-top: 2px solid #333; border-bottom: none; font-weight: 700; }
        .summary-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
        .summary-box { border: 1px solid #ddd; border-radius: 6px; padding: 10px; text-align: center; }
        .summary-box .label { font-size: 10px; text-transform: uppercase; color: #888; letter-spacing: 0.5px; }
        .summary-box .value { font-size: 16px; font-weight: 700; margin-top: 2px; }
        .section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #333; margin-top: 24px; margin-bottom: 8px; border-bottom: 1px solid #ccc; padding-bottom: 4px; }
      </style></head><body>
      ${printContent.innerHTML}
      </body></html>
    `);
    w.document.close();
    w.print();
  };

  const handleCSV = () => {
    const rows: Record<string, string>[] = [];
    rows.push({ Type: "FUEL PURCHASES", Date: "", Description: "", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: "" });
    fuelEntries.forEach(f => {
      rows.push({
        Type: "Fuel",
        Date: format(new Date(f.date), "MM/dd/yyyy"),
        Description: f.vendor || "",
        Jurisdiction: f.jurisdiction || "",
        Gallons: Number(f.gallons).toFixed(3),
        "Price/Gal": Number(f.pricePerGallon).toFixed(3),
        "Loaded Mi": "",
        "Empty Mi": "",
        "Total Miles": "",
        Amount: Number(f.totalCost).toFixed(2),
      });
    });
    rows.push({ Type: "", Date: "", Description: "FUEL TOTAL", Jurisdiction: "", Gallons: totalGallons.toFixed(3), "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: totalFuelCost.toFixed(2) });
    rows.push({ Type: "", Date: "", Description: "", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: "" });
    rows.push({ Type: "TRIPS", Date: "", Description: "", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: "" });
    trips.forEach(t => {
      const loaded = Number(t.loadedMiles || 0);
      const empty = Number(t.emptyMiles || 0);
      const miles = getTripMiles(t);
      rows.push({
        Type: "Trip",
        Date: format(new Date(t.date), "MM/dd/yyyy"),
        Description: `${t.startLocation} - ${t.endLocation}`,
        Jurisdiction: t.jurisdiction || "",
        Gallons: "",
        "Price/Gal": "",
        "Loaded Mi": loaded > 0 ? loaded.toFixed(1) : "",
        "Empty Mi": empty > 0 ? empty.toFixed(1) : "",
        "Total Miles": miles.toFixed(1),
        Amount: "",
      });
    });
    rows.push({ Type: "", Date: "", Description: "TRIPS TOTAL", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": totalMiles.toFixed(1), Amount: "" });
    rows.push({ Type: "", Date: "", Description: "", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: "" });
    rows.push({ Type: "SUMMARY", Date: "", Description: "MPG", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": mpg > 0 ? mpg.toFixed(2) : "N/A", Amount: "" });
    rows.push({ Type: "", Date: "", Description: "Fuel Cost/Mile", Jurisdiction: "", Gallons: "", "Price/Gal": "", "Loaded Mi": "", "Empty Mi": "", "Total Miles": "", Amount: costPerMile > 0 ? `$${costPerMile.toFixed(3)}` : "N/A" });
    downloadCSV(`ifta-report-${format(startDate, "yyyy-MM-dd")}.csv`, rows);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto p-0 gap-0 border-border/20 bg-background">
        <DialogHeader className="p-4 pb-3 border-b border-border/20 sticky top-0 bg-background z-10">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center">
                <Fuel className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <DialogTitle className="text-base font-bold">IFTA Report</DialogTitle>
                <DialogDescription className="text-[11px] text-muted-foreground/60 mt-0.5">
                  {format(startDate, "MMM d, yyyy")} - {format(endDate, "MMM d, yyyy")}
                </DialogDescription>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={handleCSV} disabled={isLoading} data-testid="button-ifta-csv">
                <Download className="w-3.5 h-3.5 mr-1" />
                CSV
              </Button>
              <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={handlePrint} disabled={isLoading} data-testid="button-ifta-print">
                <Printer className="w-3.5 h-3.5 mr-1" />
                Print
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div id="ifta-print-content" className="p-4 space-y-5">
          <div className="hidden print:block">
            <h1>IFTA Report</h1>
            <p className="subtitle">{format(startDate, "MMMM d, yyyy")} through {format(endDate, "MMMM d, yyyy")}</p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-cyan-500/[0.06] border border-cyan-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-cyan-400/50 uppercase tracking-widest font-semibold">Total Miles</p>
              <p className="text-base font-bold text-cyan-400 mt-1 tabular-nums" data-testid="text-ifta-total-miles">{totalMiles.toLocaleString()}</p>
            </div>
            <div className="rounded-lg bg-amber-500/[0.06] border border-amber-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-amber-400/50 uppercase tracking-widest font-semibold">Total Gallons</p>
              <p className="text-base font-bold text-amber-400 mt-1 tabular-nums" data-testid="text-ifta-total-gal">{totalGallons.toFixed(1)}</p>
            </div>
            <div className="rounded-lg bg-amber-500/[0.06] border border-amber-500/10 px-2 py-3 text-center">
              <p className="text-[10px] text-amber-400/50 uppercase tracking-widest font-semibold">Total Fuel</p>
              <p className="text-base font-bold text-amber-400 mt-1 tabular-nums" data-testid="text-ifta-total-cost">{fmt(totalFuelCost)}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-muted/30 border border-border/20 px-2 py-3 text-center">
              <p className="text-[10px] text-muted-foreground/50 uppercase tracking-widest font-semibold">MPG</p>
              <p className="text-sm font-bold mt-1 tabular-nums" data-testid="text-ifta-mpg">{mpg > 0 ? mpg.toFixed(2) : "---"}</p>
            </div>
            <div className="rounded-lg bg-muted/30 border border-border/20 px-2 py-3 text-center">
              <p className="text-[10px] text-muted-foreground/50 uppercase tracking-widest font-semibold">Avg $/Gal</p>
              <p className="text-sm font-bold mt-1 tabular-nums" data-testid="text-ifta-avg-ppg">${avgPpg > 0 ? avgPpg.toFixed(3) : "0.000"}</p>
            </div>
            <div className="rounded-lg bg-muted/30 border border-border/20 px-2 py-3 text-center">
              <p className="text-[10px] text-muted-foreground/50 uppercase tracking-widest font-semibold">Fuel $/Mi</p>
              <p className="text-sm font-bold mt-1 tabular-nums" data-testid="text-ifta-cpm">${costPerMile > 0 ? costPerMile.toFixed(3) : "0.000"}</p>
            </div>
          </div>

          {milesJurisdictionSummary.length > 0 && (
            <div>
              <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2 flex items-center gap-1.5">
                <Navigation className="w-3 h-3" /> Miles by Jurisdiction
              </h3>
              <div className="rounded-lg border border-border/20 overflow-hidden">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-border/20">
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">State</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Trips</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Miles</th>
                    </tr>
                  </thead>
                  <tbody>
                    {milesJurisdictionSummary.map((j) => (
                      <tr key={j.state} className="border-b border-border/10">
                        <td className="px-3 py-2 font-mono font-bold text-cyan-400/80">{j.state}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">{j.trips}</td>
                        <td className="px-3 py-2 text-right tabular-nums font-medium">{j.miles.toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/20">
                      <td className="px-3 py-2 font-bold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{trips.length}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{totalMiles.toLocaleString()}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {fuelJurisdictionSummary.length > 0 && (
            <div>
              <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2 flex items-center gap-1.5">
                <Fuel className="w-3 h-3" /> Fuel by Jurisdiction
              </h3>
              <div className="rounded-lg border border-border/20 overflow-hidden">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-border/20">
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">State</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Purchases</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Gallons</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fuelJurisdictionSummary.map((j) => (
                      <tr key={j.state} className="border-b border-border/10">
                        <td className="px-3 py-2 font-mono font-bold text-amber-400/80">{j.state}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">{j.count}</td>
                        <td className="px-3 py-2 text-right tabular-nums">{j.gallons.toFixed(1)}</td>
                        <td className="px-3 py-2 text-right tabular-nums font-medium">{fmt(j.cost)}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/20">
                      <td className="px-3 py-2 font-bold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{fuelEntries.length}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{totalGallons.toFixed(1)}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{fmt(totalFuelCost)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2 flex items-center gap-1.5">
              <Navigation className="w-3 h-3" /> Trips Log
            </h3>
            {trips.length === 0 ? (
              <div className="rounded-lg border border-border/20 p-8 text-center">
                <Navigation className="w-8 h-8 mx-auto text-muted-foreground/20 mb-2" />
                <p className="text-sm text-muted-foreground/50">No trips in this date range</p>
              </div>
            ) : (
              <div className="rounded-lg border border-border/20 overflow-hidden">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-border/20">
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Date</th>
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Route</th>
                      <th className="text-center px-2 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">State</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Miles</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trips.map((t: Trip, i: number) => (
                      <tr key={t.id} className={clsx("border-b border-border/10", i % 2 === 0 && "bg-muted/10")}>
                        <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{format(new Date(t.date), "MM/dd/yy")}</td>
                        <td className="px-3 py-2 truncate max-w-[120px]">{t.startLocation} - {t.endLocation}</td>
                        <td className="px-2 py-2 text-center font-mono text-cyan-400/70 font-bold">{t.jurisdiction || "-"}</td>
                        <td className="px-3 py-2 text-right tabular-nums font-medium">{getTripMiles(t).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/20">
                      <td colSpan={3} className="px-3 py-2 font-bold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{totalMiles.toLocaleString()}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2 flex items-center gap-1.5">
              <Fuel className="w-3 h-3" /> Fuel Log
            </h3>
            {fuelEntries.length === 0 ? (
              <div className="rounded-lg border border-border/20 p-8 text-center">
                <Fuel className="w-8 h-8 mx-auto text-muted-foreground/20 mb-2" />
                <p className="text-sm text-muted-foreground/50">No fuel purchases in this date range</p>
              </div>
            ) : (
              <div className="rounded-lg border border-border/20 overflow-hidden">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-border/20">
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Date</th>
                      <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Vendor</th>
                      <th className="text-center px-2 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">State</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Gal</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">$/Gal</th>
                      <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fuelEntries.map((f: FuelEntry, i: number) => (
                      <tr key={f.id} className={clsx("border-b border-border/10", i % 2 === 0 && "bg-muted/10")}>
                        <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{format(new Date(f.date), "MM/dd/yy")}</td>
                        <td className="px-3 py-2 truncate max-w-[100px]">{f.vendor || "-"}</td>
                        <td className="px-2 py-2 text-center font-mono text-amber-400/70 font-bold">{f.jurisdiction || "-"}</td>
                        <td className="px-3 py-2 text-right tabular-nums">{Number(f.gallons).toFixed(1)}</td>
                        <td className="px-3 py-2 text-right tabular-nums">${Number(f.pricePerGallon).toFixed(3)}</td>
                        <td className="px-3 py-2 text-right tabular-nums font-medium">{fmt(Number(f.totalCost))}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/20">
                      <td colSpan={3} className="px-3 py-2 font-bold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{totalGallons.toFixed(1)}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">${avgPpg > 0 ? avgPpg.toFixed(3) : "0.000"}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{fmt(totalFuelCost)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
