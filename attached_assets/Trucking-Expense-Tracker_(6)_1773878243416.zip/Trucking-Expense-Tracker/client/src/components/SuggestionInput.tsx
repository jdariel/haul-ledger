import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface SuggestionInputProps {
  suggestions: string[];
  value: string;
  onChange: (value: string) => void;
  onBlur?: () => void;
  placeholder?: string;
  className?: string;
  "data-testid"?: string;
}

export function SuggestionInput({
  suggestions,
  value,
  onChange,
  onBlur,
  placeholder,
  className,
  "data-testid": dataTestId,
}: SuggestionInputProps) {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filtered, setFiltered] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.length > 0) {
      const matches = suggestions.filter(
        (s) => s.toLowerCase().includes(value.toLowerCase()) && s.toLowerCase() !== value.toLowerCase()
      );
      setFiltered(matches.slice(0, 5));
    } else {
      setFiltered(suggestions.slice(0, 5));
    }
  }, [value, suggestions]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <Input
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setShowSuggestions(true)}
        onBlur={onBlur}
        className={className}
        data-testid={dataTestId}
      />
      {showSuggestions && filtered.length > 0 && (
        <div
          className="absolute z-50 top-full left-0 right-0 mt-1 rounded-lg border border-border/25 bg-card shadow-xl overflow-hidden"
          data-testid={dataTestId ? `${dataTestId}-suggestions` : undefined}
        >
          {filtered.map((suggestion) => (
            <button
              key={suggestion}
              type="button"
              className="w-full text-left px-3 py-2 text-sm hover-elevate cursor-pointer truncate"
              onClick={() => {
                onChange(suggestion);
                setShowSuggestions(false);
              }}
              data-testid={dataTestId ? `${dataTestId}-suggestion-item` : undefined}
            >
              {suggestion}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
