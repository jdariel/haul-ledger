import { Link, useLocation } from "wouter";
import { LayoutDashboard, Wallet, TrendingUp, Truck, LogOut, Settings, MapPin, Fuel, FilePieChart } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import clsx from "clsx";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/expenses", label: "Expenses", icon: Wallet },
    { href: "/income", label: "Income", icon: TrendingUp },
    { href: "/fuel", label: "Fuel Log", icon: Fuel },
    { href: "/trips", label: "Trips", icon: MapPin },
    { href: "/fleet", label: "Fleet", icon: Truck },
    { href: "/reports", label: "Reports", icon: FilePieChart },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 border-r border-border/20 bg-card/30 backdrop-blur-xl h-screen sticky top-0">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-primary/20">
            <Truck className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg leading-tight">HaulLedger</h1>
            <p className="text-xs text-muted-foreground">Pro Driver Edition</p>
          </div>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={clsx(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/25" 
                    : "text-muted-foreground hover:bg-muted/30 hover:text-foreground"
                )}
                data-testid={`sidebar-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t border-border/20">
        <div className="flex items-center gap-3 mb-4">
          <img 
            src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${user?.firstName || 'User'}&background=random`} 
            alt="Profile" 
            className="w-8 h-8 rounded-full ring-2 ring-border/20"
          />
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate">{user?.firstName || 'Driver'}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
        </div>
        <button 
          onClick={() => logout()}
          className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-destructive transition-colors w-full"
          data-testid="button-sidebar-logout"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );
}
