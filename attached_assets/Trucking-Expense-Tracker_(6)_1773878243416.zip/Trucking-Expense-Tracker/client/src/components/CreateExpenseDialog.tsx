import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertExpenseSchema, type Expense } from "@shared/schema";
import { useCreateExpense, useUpdateExpense } from "@/hooks/use-expenses";
import { useProcessReceipt } from "@/hooks/use-receipts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Camera, Fuel, X, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUpload } from "@/hooks/use-upload";
import { useAssets } from "@/hooks/use-assets";
import clsx from "clsx";

const EXPENSE_CATEGORIES = [
  "Fuel", "Repairs", "Insurance", "Tolls", "Parking", 
  "DEF", "Lodging", "Meals", "Phone/Internet", 
  "Truck Lease", "Scale Tickets", "Other"
];

const PAYMENT_METHODS = ["Cash", "Card", "Fuel Card", "Check", "Other"];

const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA",
  "HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
  "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
  "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY","DC"
];

interface CreateExpenseDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  editExpense?: Expense | null;
  onSaved?: (date: Date) => void;
}

export function CreateExpenseDialog({ open: controlledOpen, onOpenChange: setControlledOpen, editExpense, onSaved }: CreateExpenseDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = setControlledOpen !== undefined ? setControlledOpen : setInternalOpen;

  const isEditing = !!editExpense;
  const { toast } = useToast();
  const createExpense = useCreateExpense();
  const updateExpense = useUpdateExpense();
  const processReceipt = useProcessReceipt();
  const { uploadFile, isUploading: isUploadingFile } = useUpload();
  const { data: assets } = useAssets();
  const [isProcessingReceipt, setIsProcessingReceipt] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm({
    resolver: zodResolver(insertExpenseSchema),
    defaultValues: {
      date: new Date(),
      merchant: "",
      category: "Fuel",
      amount: 0,
      notes: "",
      receiptUrl: "",
      pricePerGallon: undefined as number | undefined,
      gallons: undefined as number | undefined,
      jurisdiction: "",
      paymentMethod: "",
      truckId: "",
    },
  });

  const selectedCategory = form.watch("category");
  const isFuel = selectedCategory === "Fuel";

  useEffect(() => {
    if (open && editExpense) {
      form.reset({
        date: new Date(editExpense.date),
        merchant: editExpense.merchant,
        category: editExpense.category,
        amount: Number(editExpense.amount),
        notes: editExpense.notes || "",
        receiptUrl: editExpense.receiptUrl || "",
        pricePerGallon: editExpense.pricePerGallon ? Number(editExpense.pricePerGallon) : undefined,
        gallons: editExpense.gallons ? Number(editExpense.gallons) : undefined,
        jurisdiction: editExpense.jurisdiction || "",
        paymentMethod: editExpense.paymentMethod || "",
        truckId: editExpense.truckId || "",
      });
    } else if (open && !editExpense) {
      form.reset({
        date: new Date(),
        merchant: "",
        category: "Fuel",
        amount: 0,
        notes: "",
        receiptUrl: "",
        pricePerGallon: undefined,
        gallons: undefined,
        jurisdiction: "",
        paymentMethod: "",
        truckId: "",
      });
    }
  }, [open, editExpense]);

  const onSubmit = async (data: any) => {
    try {
      const submitData = { ...data };
      if (submitData.category !== "Fuel") {
        submitData.pricePerGallon = undefined;
        submitData.gallons = undefined;
        submitData.jurisdiction = undefined;
      } else {
        if (!submitData.pricePerGallon) submitData.pricePerGallon = undefined;
        if (!submitData.gallons) submitData.gallons = undefined;
        if (!submitData.jurisdiction) submitData.jurisdiction = undefined;
      }
      if (!submitData.paymentMethod) submitData.paymentMethod = undefined;
      if (!submitData.truckId || submitData.truckId === "none") submitData.truckId = undefined;

      if (isEditing) {
        await updateExpense.mutateAsync({ id: editExpense!.id, ...submitData });
        toast({ title: "Expense Updated", description: "Changes saved successfully." });
      } else {
        await createExpense.mutateAsync(submitData);
        toast({ title: "Expense Added", description: "Successfully logged new expense." });
      }
      const savedDate = data.date instanceof Date ? data.date : new Date(data.date);
      setOpen(false);
      form.reset();
      onSaved?.(savedDate);
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingReceipt(true);
    
    try {
      const uploadResponse = await uploadFile(file);
      if (uploadResponse) {
        form.setValue("receiptUrl", uploadResponse.objectPath);
      } else {
        toast({ title: "Upload Failed", description: "Receipt upload failed. Please try again.", variant: "destructive" });
      }

      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = (event) => resolve(event.target?.result as string);
        reader.readAsDataURL(file);
      });
      
      const base64 = await base64Promise;
      const data = await processReceipt.mutateAsync(base64);
      
      const hasAnyData = data.merchant || data.amount !== undefined || data.date || data.category;
      
      if (!hasAnyData) {
        toast({ title: "Manual Entry Needed", description: "Couldn't read receipt automatically. Please fill in the fields manually.", variant: "destructive" });
      } else {
        if (data.merchant) form.setValue("merchant", data.merchant, { shouldValidate: true });
        if (data.amount !== undefined) form.setValue("amount", Number(data.amount), { shouldValidate: true });
        if (data.date) {
          try {
            const parsedDate = new Date(data.date);
            if (!isNaN(parsedDate.getTime())) {
              form.setValue("date", parsedDate, { shouldValidate: true });
            }
          } catch (e) {
            console.error("Invalid date from OCR:", data.date);
          }
        }
        if (data.category) {
          const matchedCategory = EXPENSE_CATEGORIES.find(
            c => c.toLowerCase() === (data.category || "").toLowerCase()
          ) || "Other";
          form.setValue("category", matchedCategory, { shouldValidate: true });
        }
        if (data.notes) {
          form.setValue("notes", data.notes, { shouldValidate: true });
        }
        if (data.pricePerGallon) {
          form.setValue("pricePerGallon", Number(data.pricePerGallon), { shouldValidate: true });
        }
        if (data.gallons) {
          form.setValue("gallons", Number(data.gallons), { shouldValidate: true });
        }
        if (data.jurisdiction) {
          const matched = US_STATES.find(s => s === data.jurisdiction?.toUpperCase());
          form.setValue("jurisdiction", matched || data.jurisdiction || "", { shouldValidate: true });
        }

        const missingFields = [];
        if (!data.merchant) missingFields.push("merchant");
        if (data.amount === undefined) missingFields.push("amount");
        if (!data.date) missingFields.push("date");

        if (missingFields.length > 0) {
          toast({ title: "Receipt Partially Read", description: "Please verify the fields below." });
        } else {
          toast({ title: "Receipt Scanned", description: "Data extracted and image saved successfully!" });
        }
      }
    } catch (err: any) {
      console.error("Receipt scan error:", err);
      toast({ title: "Scan Failed", description: err?.message || "Could not read receipt. Please fill in the fields manually.", variant: "destructive" });
    } finally {
      setIsProcessingReceipt(false);
    }
  };

  const isBusy = createExpense.isPending || updateExpense.isPending || isUploadingFile || isProcessingReceipt;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md bg-card/95 backdrop-blur-xl border-border/25 text-foreground max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{isEditing ? "Edit Expense" : "Log Expense"}</DialogTitle>
          <DialogDescription className="sr-only">{isEditing ? "Edit an existing expense" : "Add a new expense record"}</DialogDescription>
        </DialogHeader>

        <div className="relative mb-4">
          {form.watch("receiptUrl") ? (
            <div className="rounded-xl overflow-hidden border border-border/25 relative">
              <img
                src={`/objects/${form.watch("receiptUrl")?.replace(/^\/objects\//, "")}`}
                alt="Receipt"
                className="w-full max-h-48 object-contain bg-black/20"
                data-testid="img-receipt-preview"
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="absolute top-1 right-1 bg-black/50 text-white"
                onClick={() => {
                  form.setValue("receiptUrl", "");
                  const input = document.getElementById("receipt-upload") as HTMLInputElement;
                  if (input) input.value = "";
                }}
                data-testid="button-remove-receipt"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                id="receipt-upload"
                className="hidden"
                onChange={handleFileUpload}
                disabled={isProcessingReceipt}
                data-testid="input-receipt-upload"
              />
              <div
                role="button"
                tabIndex={0}
                onClick={() => { if (!isProcessingReceipt) fileInputRef.current?.click(); }}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); if (!isProcessingReceipt) fileInputRef.current?.click(); } }}
                className={clsx(
                  "flex items-center justify-center gap-2 w-full p-4 border-2 border-dashed border-border/25 rounded-xl cursor-pointer hover:bg-muted/30 transition-colors",
                  isProcessingReceipt && "opacity-50 cursor-not-allowed"
                )}
                data-testid="button-scan-receipt"
              >
                {isProcessingReceipt || isUploadingFile ? (
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                ) : (
                  <Camera className="w-5 h-5 text-primary" />
                )}
                <span className="text-sm font-medium">
                  {isProcessingReceipt || isUploadingFile ? "Processing..." : "Scan Receipt to Auto-fill"}
                </span>
              </div>
            </>
          )}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="merchant"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Merchant</FormLabel>
                  <FormControl>
                    <Input placeholder="Pilot Flying J" {...field} className="glass-input" data-testid="input-expense-merchant" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01" 
                        placeholder="0.00" 
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        className="glass-input"
                        data-testid="input-expense-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field} 
                        value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''}
                        onChange={(e) => field.onChange(new Date(e.target.value))}
                        className="glass-input"
                        data-testid="input-expense-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="glass-input" data-testid="select-expense-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-popover border-border/25 text-popover-foreground">
                        {EXPENSE_CATEGORIES.map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl>
                        <SelectTrigger className="glass-input" data-testid="select-expense-payment">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-popover border-border/25 text-popover-foreground">
                        {PAYMENT_METHODS.map((pm) => (
                          <SelectItem key={pm} value={pm}>{pm}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {Array.isArray(assets) && assets.length > 0 && (
              <FormField
                control={form.control}
                name="truckId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Truck / Asset</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl>
                        <SelectTrigger className="glass-input" data-testid="select-expense-truck">
                          <SelectValue placeholder="None" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-popover border-border/25 text-popover-foreground">
                        <SelectItem value="none">None</SelectItem>
                        {assets.map((asset: any) => (
                          <SelectItem key={asset.id} value={String(asset.id)}>{asset.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {isFuel && (
              <div className="bg-secondary/30 border border-border/20 rounded-xl p-3 space-y-3">
                <div className="flex items-center gap-2 mb-1">
                  <Fuel className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-amber-400/80">Fuel Details</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="pricePerGallon"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">$/Gallon</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.001" 
                            placeholder="3.459" 
                            value={field.value ?? ""}
                            onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                            className="glass-input"
                            data-testid="input-expense-ppg"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="gallons"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Gallons</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.001" 
                            placeholder="120.5" 
                            value={field.value ?? ""}
                            onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                            className="glass-input"
                            data-testid="input-expense-gallons"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="jurisdiction"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">State / Jurisdiction</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger className="glass-input" data-testid="select-expense-jurisdiction">
                            <SelectValue placeholder="Select state" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover border-border/25 text-popover-foreground max-h-[200px]">
                          {US_STATES.map((st) => (
                            <SelectItem key={st} value={st}>{st}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Details..." {...field} className="glass-input resize-none" data-testid="input-expense-notes" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="pt-2">
              <Button type="submit" className="w-full h-12 text-lg font-semibold shadow-lg shadow-primary/25" disabled={isBusy} data-testid="button-save-expense">
                {isBusy && <Loader2 className="w-5 h-5 animate-spin mr-2" />}
                {isEditing ? "Update Expense" : "Save Expense"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
