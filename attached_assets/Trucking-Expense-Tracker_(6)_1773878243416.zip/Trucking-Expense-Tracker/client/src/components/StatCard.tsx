import { ArrowUpRight, ArrowDownRight, DollarSign } from "lucide-react";
import clsx from "clsx";

interface StatCardProps {
  title: string;
  value: number;
  type?: "neutral" | "success" | "danger";
  icon?: any;
  trend?: string;
}

export function StatCard({ title, value, type = "neutral", icon: Icon = DollarSign, trend }: StatCardProps) {
  const formattedValue = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);

  const colors = {
    neutral: "bg-card text-foreground",
    success: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    danger: "bg-rose-500/10 text-rose-500 border-rose-500/20",
  };

  const iconColors = {
    neutral: "bg-primary/20 text-primary",
    success: "bg-emerald-500/20 text-emerald-500",
    danger: "bg-rose-500/20 text-rose-500",
  };

  return (
    <div className={clsx("glass-card rounded-2xl p-5 relative overflow-hidden group hover:-translate-y-1 transition-transform duration-300", colors[type as keyof typeof colors] || colors.neutral)}>
      <div className="flex justify-between items-start mb-4">
        <div className={clsx("p-3 rounded-xl", iconColors[type as keyof typeof iconColors])}>
          <Icon className="w-6 h-6" />
        </div>
        {trend && (
          <span className="text-xs font-medium bg-muted/30 px-2 py-1 rounded-full border border-border/20">
            {trend}
          </span>
        )}
      </div>
      <div>
        <p className="text-sm text-muted-foreground font-medium mb-1">{title}</p>
        <h3 className="text-2xl font-display font-bold tracking-tight text-foreground">{formattedValue}</h3>
      </div>
      
      {/* Background decoration */}
      <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-current opacity-[0.03] rounded-full group-hover:scale-150 transition-transform duration-500" />
    </div>
  );
}
