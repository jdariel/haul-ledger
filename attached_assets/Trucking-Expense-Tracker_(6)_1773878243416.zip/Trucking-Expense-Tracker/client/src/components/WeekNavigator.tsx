import { startOfWeek, endOfWeek, addWeeks, subWeeks, format, isThisWeek } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface WeekNavigatorProps {
  weekStart: Date;
  onWeekChange: (newStart: Date) => void;
}

export function WeekNavigator({ weekStart, onWeekChange }: WeekNavigatorProps) {
  const weekEnd = endOfWeek(weekStart, { weekStartsOn: 0 });
  const currentWeek = isThisWeek(weekStart, { weekStartsOn: 0 });

  return (
    <div className="flex items-center justify-between gap-2 px-1" data-testid="week-navigator">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => onWeekChange(subWeeks(weekStart, 1))}
        data-testid="button-prev-week"
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>
      <button
        onClick={() => {
          if (!currentWeek) onWeekChange(startOfWeek(new Date(), { weekStartsOn: 0 }));
        }}
        className="text-sm font-medium text-center min-w-0"
        data-testid="text-week-range"
      >
        <span className="block">
          {format(weekStart, "MMM d")} – {format(weekEnd, "MMM d, yyyy")}
        </span>
        {currentWeek && (
          <span className="text-xs text-muted-foreground">This Week</span>
        )}
      </button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => onWeekChange(addWeeks(weekStart, 1))}
        disabled={currentWeek}
        data-testid="button-next-week"
      >
        <ChevronRight className="w-5 h-5" />
      </Button>
    </div>
  );
}

export function getWeekStart(date: Date = new Date()) {
  return startOfWeek(date, { weekStartsOn: 0 });
}

export function isInWeek(date: Date | string, weekStart: Date) {
  const d = typeof date === "string" ? new Date(date) : date;
  const weekEnd = endOfWeek(weekStart, { weekStartsOn: 0 });
  return d >= weekStart && d <= weekEnd;
}
