import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileText, Printer, Download } from "lucide-react";
import { format } from "date-fns";
import { downloadCSV } from "@/lib/utils";
import type { Expense, Income } from "@shared/schema";

interface ScheduleCDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expenses: Expense[];
  income: Income[];
  startDate: Date;
  endDate: Date;
}

const SCHEDULE_C_LINES: { line: string; label: string; categories: string[] }[] = [
  { line: "9", label: "Car and truck expenses", categories: ["Fuel", "Tolls", "Parking"] },
  { line: "15", label: "Insurance (other than health)", categories: ["Insurance"] },
  { line: "17", label: "Legal and professional services", categories: [] },
  { line: "18", label: "Office expense", categories: ["Supplies"] },
  { line: "20a", label: "Rent or lease - Vehicles, machinery, equipment", categories: ["Truck Lease"] },
  { line: "21", label: "Repairs and maintenance", categories: ["Repairs", "Maintenance", "DEF"] },
  { line: "24a", label: "Travel", categories: ["Lodging", "Travel"] },
  { line: "24b", label: "Meals (subject to 50% limitation)", categories: ["Meals"] },
  { line: "25", label: "Utilities", categories: ["Phone/Internet"] },
  { line: "27a", label: "Other expenses (see line 48)", categories: ["Scale Tickets", "Other"] },
];

function getScheduleCLine(category: string): string {
  const match = SCHEDULE_C_LINES.find(l => l.categories.includes(category));
  return match ? `Line ${match.line}` : "Other";
}

export function ScheduleCDialog({ open, onOpenChange, expenses, income, startDate, endDate }: ScheduleCDialogProps) {
  const totalIncome = income.reduce((s, i) => s + Number(i.amount), 0);

  const lineAmounts = SCHEDULE_C_LINES.map(line => {
    const amount = expenses
      .filter(e => line.categories.includes(e.category))
      .reduce((s, e) => s + Number(e.amount), 0);
    return { ...line, amount };
  });

  const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount), 0);
  const netProfit = totalIncome - totalExpenses;

  const fmt = (val: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(val);

  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const handlePrint = () => {
    const w = window.open("", "_blank");
    if (!w) return;

    const expenseRows = expenses
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map((e, i) => `<tr class="${i % 2 === 0 ? 'alt' : ''}"><td class="muted">${format(new Date(e.date), "MM/dd/yy")}</td><td>${esc(e.merchant)}</td><td class="muted">${esc(e.category)}</td><td class="num">${fmt(Number(e.amount))}</td></tr>`)
      .join("");

    const incomeRows = income
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map((inc, i) => `<tr class="${i % 2 === 0 ? 'alt' : ''}"><td class="muted">${format(new Date(inc.date), "MM/dd/yy")}</td><td>${esc(inc.source || "-")}</td><td class="muted">${esc(inc.routeName || "-")}</td><td class="num green">${fmt(Number(inc.amount))}</td></tr>`)
      .join("");

    const lineRows = lineAmounts
      .map((line, i) => `<tr class="${i % 2 === 0 ? 'alt' : ''}"><td class="line-num">${line.line}</td><td>${line.label}</td><td class="num red">${line.amount > 0 ? fmt(line.amount) : "-"}</td></tr>`)
      .join("");

    w.document.write(`<html><head><title>Schedule C Report - HaulLedger</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', -apple-system, sans-serif; padding: 0; color: #1a1a2e; font-size: 11px; }
        .cover { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #fff; padding: 36px 40px 28px; }
        .cover h1 { font-family: 'Outfit', sans-serif; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; }
        .cover .brand { font-size: 11px; text-transform: uppercase; letter-spacing: 2px; opacity: 0.6; margin-bottom: 6px; }
        .cover .period { font-size: 13px; opacity: 0.7; margin-top: 4px; }
        .net-box { display: flex; align-items: center; justify-content: space-between; background: ${netProfit >= 0 ? 'rgba(52,211,153,0.12)' : 'rgba(251,113,133,0.12)'}; border: 1px solid ${netProfit >= 0 ? 'rgba(52,211,153,0.3)' : 'rgba(251,113,133,0.3)'}; border-radius: 10px; padding: 16px 20px; margin: 20px 40px; }
        .net-box .label { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #888; font-weight: 600; }
        .net-box .value { font-family: 'Outfit', sans-serif; font-size: 28px; font-weight: 800; color: ${netProfit >= 0 ? '#059669' : '#e11d48'}; }
        .net-box .sub { font-size: 11px; color: #888; margin-top: 2px; }
        .content { padding: 0 40px 40px; }
        h2 { font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #64748b; margin: 24px 0 8px; padding-bottom: 6px; border-bottom: 2px solid #e2e8f0; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
        th { text-align: left; padding: 7px 10px; font-size: 9px; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; font-weight: 600; border-bottom: 1px solid #e2e8f0; }
        td { padding: 6px 10px; border-bottom: 1px solid #f1f5f9; font-size: 11px; }
        .alt td { background: #f8fafc; }
        .num { text-align: right; font-variant-numeric: tabular-nums; font-weight: 500; }
        .line-num { color: #94a3b8; font-size: 10px; width: 36px; }
        .muted { color: #64748b; }
        .green { color: #059669; }
        .red { color: #e11d48; }
        .total-row td { border-top: 2px solid #334155; font-weight: 700; background: #f1f5f9 !important; }
        .footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
        .footer .note { font-size: 9px; color: #94a3b8; max-width: 340px; line-height: 1.5; }
        .footer .generated { font-size: 9px; color: #94a3b8; text-align: right; }
        @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
      </style></head><body>
      <div class="cover">
        <div class="brand">HaulLedger</div>
        <h1>Schedule C Report</h1>
        <div class="period">${format(startDate, "MMMM d, yyyy")} — ${format(endDate, "MMMM d, yyyy")}</div>
      </div>
      <div class="net-box">
        <div><div class="label">Line 31 — Net Profit (or Loss)</div><div class="sub">Income ${fmt(totalIncome)} · Expenses ${fmt(totalExpenses)}</div></div>
        <div class="value">${fmt(netProfit)}</div>
      </div>
      <div class="content">
        <h2>Part I — Income</h2>
        <table><thead><tr><th>Line</th><th>Description</th><th style="text-align:right">Amount</th></tr></thead><tbody>
          <tr><td class="line-num">1</td><td>Gross receipts or sales</td><td class="num green">${fmt(totalIncome)}</td></tr>
          <tr class="total-row"><td class="line-num">7</td><td>Gross income</td><td class="num green">${fmt(totalIncome)}</td></tr>
        </tbody></table>

        <h2>Part II — Expenses</h2>
        <table><thead><tr><th>Line</th><th>Description</th><th style="text-align:right">Amount</th></tr></thead><tbody>
          ${lineRows}
          <tr class="total-row"><td class="line-num">28</td><td>Total expenses</td><td class="num red">${fmt(totalExpenses)}</td></tr>
        </tbody></table>

        <h2>Expense Detail</h2>
        <table><thead><tr><th>Date</th><th>Merchant</th><th>Category</th><th style="text-align:right">Amount</th></tr></thead><tbody>
          ${expenseRows || '<tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:16px">No expenses in this period</td></tr>'}
          ${expenses.length > 0 ? `<tr class="total-row"><td colspan="3">Total</td><td class="num">${fmt(totalExpenses)}</td></tr>` : ''}
        </tbody></table>

        <h2>Income Detail</h2>
        <table><thead><tr><th>Date</th><th>Source</th><th>Route</th><th style="text-align:right">Amount</th></tr></thead><tbody>
          ${incomeRows || '<tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:16px">No income in this period</td></tr>'}
          ${income.length > 0 ? `<tr class="total-row"><td colspan="3">Total</td><td class="num green">${fmt(totalIncome)}</td></tr>` : ''}
        </tbody></table>

        <div class="footer">
          <div class="note">This report is generated for informational purposes only and does not constitute tax advice. Consult a qualified tax professional before filing. Keep all receipts and supporting documentation.</div>
          <div class="generated">Generated by HaulLedger<br>${format(new Date(), "MMM d, yyyy 'at' h:mm a")}</div>
        </div>
      </div>
      </body></html>`);
    w.document.close();
    w.print();
  };

  const handleCSV = () => {
    const rows: Record<string, string>[] = [];
    rows.push({ Section: "EXPENSES", Date: "", "Description": "", Category: "", "Schedule C Line": "", Amount: "" });
    expenses
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .forEach(e => {
        rows.push({
          Section: "",
          Date: format(new Date(e.date), "MM/dd/yyyy"),
          Description: e.merchant,
          Category: e.category,
          "Schedule C Line": getScheduleCLine(e.category),
          Amount: Number(e.amount).toFixed(2),
        });
      });
    rows.push({ Section: "", Date: "", Description: "", Category: "", "Schedule C Line": "TOTAL EXPENSES", Amount: totalExpenses.toFixed(2) });
    rows.push({ Section: "", Date: "", Description: "", Category: "", "Schedule C Line": "", Amount: "" });
    rows.push({ Section: "INCOME", Date: "", Description: "", Category: "", "Schedule C Line": "", Amount: "" });
    income
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .forEach(i => {
        rows.push({
          Section: "",
          Date: format(new Date(i.date), "MM/dd/yyyy"),
          Description: i.source || "",
          Category: "Income",
          "Schedule C Line": i.routeName || "",
          Amount: Number(i.amount).toFixed(2),
        });
      });
    rows.push({ Section: "", Date: "", Description: "", Category: "", "Schedule C Line": "TOTAL INCOME", Amount: totalIncome.toFixed(2) });
    rows.push({ Section: "", Date: "", Description: "", Category: "", "Schedule C Line": "", Amount: "" });
    rows.push({ Section: "SUMMARY", Date: "", Description: "", Category: "", "Schedule C Line": "NET PROFIT", Amount: netProfit.toFixed(2) });
    downloadCSV(`schedule-c-${format(startDate, "yyyy-MM-dd")}.csv`, rows);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto p-0 gap-0 border-border/20 bg-background">
        <DialogHeader className="p-4 pb-3 border-b border-border/20 sticky top-0 bg-background z-10">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center">
                <FileText className="w-4 h-4 text-primary" />
              </div>
              <div>
                <DialogTitle className="text-base font-bold">Schedule C Report</DialogTitle>
                <p className="text-[11px] text-muted-foreground/60 mt-0.5">
                  {format(startDate, "MMM d, yyyy")} - {format(endDate, "MMM d, yyyy")}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={handleCSV} data-testid="button-schedulec-csv">
                <Download className="w-3.5 h-3.5 mr-1" />
                CSV
              </Button>
              <Button variant="outline" size="sm" className="border-border/25 text-xs" onClick={handlePrint} data-testid="button-schedulec-print">
                <Printer className="w-3.5 h-3.5 mr-1" />
                Print
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div id="schedulec-print-content" className="p-4 space-y-4">
          <div className="hidden print:block">
            <p className="form-title">IRS Form 1040</p>
            <h1>Schedule C - Profit or Loss From Business</h1>
            <p className="subtitle">{format(startDate, "MMMM d, yyyy")} through {format(endDate, "MMMM d, yyyy")}</p>
          </div>

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2">Part I - Income</h3>
            <div className="rounded-lg border border-border/20 overflow-hidden">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-border/20">
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold w-10">Line</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Description</th>
                    <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-border/10">
                    <td className="px-3 py-2 text-muted-foreground/50 text-[11px]">1</td>
                    <td className="px-3 py-2">Gross receipts or sales</td>
                    <td className="px-3 py-2 text-right tabular-nums font-medium text-emerald-400">{fmt(totalIncome)}</td>
                  </tr>
                  <tr className="bg-muted/20">
                    <td className="px-3 py-2 text-muted-foreground/50 text-[11px]">7</td>
                    <td className="px-3 py-2 font-semibold">Gross income</td>
                    <td className="px-3 py-2 text-right tabular-nums font-bold text-emerald-400">{fmt(totalIncome)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2">Part II - Expenses</h3>
            <div className="rounded-lg border border-border/20 overflow-hidden">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-border/20">
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold w-10">Line</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Description</th>
                    <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {lineAmounts.map((line, i) => (
                    <tr key={line.line} className={i % 2 === 0 ? "bg-muted/10" : ""}>
                      <td className="px-3 py-2 text-muted-foreground/50 text-[11px]">{line.line}</td>
                      <td className="px-3 py-2">
                        <span>{line.label}</span>
                        {line.categories.length > 0 && (
                          <span className="text-[10px] text-muted-foreground/40 ml-1.5">({line.categories.join(", ")})</span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums font-medium text-rose-400">
                        {line.amount > 0 ? fmt(line.amount) : "-"}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-muted/30 border-t border-border/20">
                    <td className="px-3 py-2 text-muted-foreground/50 text-[11px]">28</td>
                    <td className="px-3 py-2 font-semibold">Total expenses</td>
                    <td className="px-3 py-2 text-right tabular-nums font-bold text-rose-400">{fmt(totalExpenses)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-xl border border-border/20 bg-gradient-to-b from-muted/40 to-transparent p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Line 31</p>
                <p className="text-sm font-semibold mt-0.5">Net profit (or loss)</p>
              </div>
              <p className={`text-2xl font-display font-extrabold tabular-nums ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`} data-testid="text-schedulec-net">
                {fmt(netProfit)}
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2">Expense Detail</h3>
            <div className="rounded-lg border border-border/20 overflow-hidden">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-border/20">
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Date</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Merchant</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Category</th>
                    <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {expenses
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map((e, i) => (
                    <tr key={e.id} className={i % 2 === 0 ? "bg-muted/10" : ""}>
                      <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{format(new Date(e.date), "MM/dd/yy")}</td>
                      <td className="px-3 py-2 truncate max-w-[120px]">{e.merchant}</td>
                      <td className="px-3 py-2 text-muted-foreground">{e.category}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-medium">{fmt(Number(e.amount))}</td>
                    </tr>
                  ))}
                  {expenses.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-3 py-6 text-center text-muted-foreground/40">No expenses in this date range</td>
                    </tr>
                  )}
                  {expenses.length > 0 && (
                    <tr className="bg-muted/20 border-t border-border/20">
                      <td colSpan={3} className="px-3 py-2 font-semibold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold">{fmt(totalExpenses)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 mb-2">Income Detail</h3>
            <div className="rounded-lg border border-border/20 overflow-hidden">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-border/20">
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Date</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Source</th>
                    <th className="text-left px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Route</th>
                    <th className="text-right px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground/50 font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {income
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map((inc, i) => (
                    <tr key={inc.id} className={i % 2 === 0 ? "bg-muted/10" : ""}>
                      <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{format(new Date(inc.date), "MM/dd/yy")}</td>
                      <td className="px-3 py-2 truncate max-w-[100px]">{inc.source || "-"}</td>
                      <td className="px-3 py-2 text-muted-foreground truncate max-w-[80px]">{inc.routeName || "-"}</td>
                      <td className="px-3 py-2 text-right tabular-nums font-medium text-emerald-400">{fmt(Number(inc.amount))}</td>
                    </tr>
                  ))}
                  {income.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-3 py-6 text-center text-muted-foreground/40">No income in this date range</td>
                    </tr>
                  )}
                  {income.length > 0 && (
                    <tr className="bg-muted/20 border-t border-border/20">
                      <td colSpan={3} className="px-3 py-2 font-semibold">Total</td>
                      <td className="px-3 py-2 text-right tabular-nums font-bold text-emerald-400">{fmt(totalIncome)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
