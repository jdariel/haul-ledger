import { useState } from "react";
import { isFirstVisit, markVisited } from "@/lib/userPrefs";
import { Truck, X, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export function OnboardingBanner() {
  const [visible, setVisible] = useState(() => isFirstVisit());

  if (!visible) return null;

  const dismiss = () => {
    markVisited();
    setVisible(false);
  };

  return (
    <div className="relative rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 p-5 overflow-hidden" data-testid="banner-onboarding">
      <button
        onClick={dismiss}
        className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
        data-testid="button-dismiss-onboarding"
      >
        <X className="w-4 h-4" />
      </button>
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
          <Truck className="w-5 h-5 text-primary" />
        </div>
        <div className="min-w-0">
          <h3 className="font-display font-bold text-foreground text-base" data-testid="text-onboarding-title">
            Welcome to HaulLedger
          </h3>
          <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
            Start by adding your truck in Fleet, then log your first expense or income. Your dashboard will light up with real-time stats.
          </p>
          <div className="flex items-center gap-3 mt-3 flex-wrap">
            <Link
              href="/fleet"
              onClick={dismiss}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
              data-testid="link-onboarding-fleet"
            >
              Add a truck <ArrowRight className="w-3.5 h-3.5" />
            </Link>
            <button
              onClick={dismiss}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-onboarding-skip"
            >
              Skip for now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
