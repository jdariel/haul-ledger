import { format } from "date-fns";
import { TrendingDown, TrendingUp, Loader2, Search, Receipt } from "lucide-react";
import clsx from "clsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface Transaction {
  id: number;
  type: "expense" | "income";
  description: string;
  category?: string;
  amount: string | number;
  date: string | Date;
  receiptUrl?: string | null;
}

interface TransactionListProps {
  transactions: Transaction[];
  isLoading: boolean;
  emptyMessage?: string;
  limit?: number;
}

export function TransactionList({ transactions, isLoading, emptyMessage = "No transactions found.", limit }: TransactionListProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-primary/50" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground bg-card/30 rounded-2xl border border-border/20 border-dashed">
        <Search className="w-10 h-10 mb-2 opacity-20" />
        <p>{emptyMessage}</p>
      </div>
    );
  }

  const displayTransactions = limit ? transactions.slice(0, limit) : transactions;

  return (
    <div className="space-y-3">
      {displayTransactions.map((tx) => (
        <div 
          key={`${tx.type}-${tx.id}`}
          className="flex items-center justify-between p-4 rounded-xl bg-card/40 border border-border/20 hover:bg-card/60 transition-colors"
        >
          <div className="flex items-center gap-4">
            <div className={clsx(
              "w-10 h-10 rounded-full flex items-center justify-center border",
              tx.type === 'income' 
                ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" 
                : "bg-rose-500/10 text-rose-500 border-rose-500/20"
            )}>
              {tx.type === 'income' ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
            </div>
            <div>
              <p className="font-medium text-sm">{tx.description}</p>
              <p className="text-xs text-muted-foreground">
                {format(new Date(tx.date), "MMM d, yyyy")} • {tx.category || "Income"}
              </p>
            </div>
          </div>
          <span className={clsx(
            "font-semibold tabular-nums",
            tx.type === 'income' ? "text-emerald-400" : "text-rose-400"
          )}>
            {tx.type === 'income' ? '+' : '-'}${Number(tx.amount).toFixed(2)}
          </span>
          {tx.receiptUrl && (
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-2 h-8 w-8 text-muted-foreground hover:text-primary">
                  <Receipt className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card/95 backdrop-blur-xl border-border/25">
                <DialogHeader>
                  <DialogTitle>Receipt - {tx.description}</DialogTitle>
                </DialogHeader>
                <div className="mt-4 flex justify-center">
                  <img 
                    src={tx.receiptUrl} 
                    alt={`Receipt for ${tx.description}`} 
                    className="max-h-[70vh] w-auto rounded-lg object-contain shadow-2xl"
                  />
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      ))}
    </div>
  );
}
