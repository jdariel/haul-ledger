import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import Expenses from "@/pages/Expenses";
import Income from "@/pages/Income";
import SavedRoutes from "@/pages/SavedRoutes";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import Assets from "@/pages/Assets";
import Trips from "@/pages/Trips";
import FuelLog from "@/pages/FuelLog";
import QuickAdd from "@/pages/QuickAdd";
import NotFound from "@/pages/not-found";
import { Sidebar } from "@/components/Sidebar";
import { BottomNav } from "@/components/BottomNav";

function PrivateLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 px-4 py-6 md:p-8 max-w-7xl mx-auto w-full">
        {children}
      </main>
      <BottomNav />
    </div>
  );
}

function Router() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route component={() => {
          window.location.replace("/");
          return null;
        }} />
      </Switch>
    );
  }

  return (
    <PrivateLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/expenses" component={Expenses} />
        <Route path="/income" component={Income} />
        <Route path="/fuel" component={FuelLog} />
        <Route path="/trips" component={Trips} />
        <Route path="/fleet" component={Assets} />
        <Route path="/routes" component={SavedRoutes} />
        <Route path="/reports" component={Reports} />
        <Route path="/settings/quick-add" component={QuickAdd} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </PrivateLayout>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
