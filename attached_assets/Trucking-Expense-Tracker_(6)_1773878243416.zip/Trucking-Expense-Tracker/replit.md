# HaulLedger - Trucking Expenses & Earnings Tracker

## Overview

HaulLedger is a web application designed for truck drivers and owner-operators to track expenses, income, receipts, and generate financial reports (Schedule C style). The app provides a dashboard with financial summaries, expense/income CRUD operations, receipt scanning via AI, and reporting with charts. It follows a mobile-first design approach with a dark blue/slate theme.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter (lightweight client-side router)
- **State Management**: TanStack React Query for server state; no separate client state library
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives with Tailwind CSS
- **Charts**: Recharts for financial visualizations (bar charts, pie charts)
- **Styling**: Tailwind CSS with CSS variables for theming. Dark mode by default with a deep blue/slate color scheme. Custom fonts: Outfit (display) and Plus Jakarta Sans (body)
- **Forms**: React Hook Form with Zod resolvers for validation
- **CSV Export**: `downloadCSV()` utility in `client/src/lib/utils.ts` for client-side CSV generation (used by Schedule C, IFTA, and Settings export — includes expenses, income, trips, fuel entries)
- **Theme**: Dark/Light mode via ThemeProvider (`client/src/lib/theme.tsx`), `.light` CSS class variables in `index.css`, toggle in Settings
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Key UI Components
- **BottomNav** (`client/src/components/BottomNav.tsx`): 5-item mobile bottom navigation — Home, Expenses, Income, Reports, More. Active tab has top indicator bar, bold label, and scale-110 animation
- **ConfirmDeleteDialog** (`client/src/components/ConfirmDeleteDialog.tsx`): Reusable delete confirmation dialog (shadcn AlertDialog) used across Expenses, Income, FuelLog, Trips, and Assets pages
- **SwipeableRow** (`client/src/components/SwipeableRow.tsx`): Swipe-to-delete row wrapper used on Expenses, Income, FuelLog, and Trips lists
- **Receipt Viewer**: Dialog-based fullscreen receipt image viewer on Expenses page. Receipt URL pattern: `/objects/${receiptUrl.replace(/^\/objects\//, '')}`

### Page Features
- **Expenses**: Category filter, merchant search bar, Week/All toggle (segmented), swipe-to-delete with confirmation, receipt viewer dialog, truck/asset selector in create form
- **Income**: Notes display (truncated at 60 chars), trailer number badge pill, swipe-to-delete with confirmation
- **FuelLog**: Swipe-to-delete with confirmation (replaced inline delete buttons)
- **Trips**: Swipe-to-delete with confirmation (replaced inline delete buttons)
- **Assets**: Delete confirmation dialog on trash button click, fleet odometer running total (miles logged per truck from trips data)
- **Dashboard**: Weekly miles card, per-truck activity filter (when >1 asset), IFTA deadline countdown banner (within 30 days of Apr 30/Jul 31/Oct 31/Jan 31)
- **Settings**: Export All Data (JSON) + Export as CSV buttons, monthly backup reminder callout
- **Landing**: "Your books. Done at the pump." headline, 3-step how-it-works section, social proof pills
- **QuickAdd** (`client/src/pages/QuickAdd.tsx`): Template management page at `/settings/quick-add` for creating one-tap expense shortcuts
- **Dashboard Quick Add**: Horizontal scrollable quick expense buttons between stat cards and recent activity
- **Mileage Goals**: Weekly miles target set in Settings, progress bar displayed on Dashboard Miles This Week card. Stored in localStorage via `client/src/lib/userPrefs.ts`
- **OnboardingBanner** (`client/src/components/OnboardingBanner.tsx`): First-visit welcome banner on Dashboard with link to Fleet. Dismissible, uses `isFirstVisit()`/`markVisited()` from `userPrefs.ts`
- **Schedule C PDF**: Branded print template with HaulLedger cover header, net profit callout box, accountant disclaimer footer, custom fonts (Outfit + Plus Jakarta Sans)
- **PWA**: manifest.json for installability, meta tags for mobile web app

### Backend
- **Framework**: Express.js running on Node.js with TypeScript (via tsx)
- **API Pattern**: RESTful JSON API under `/api/*` prefix. Routes are defined in `shared/routes.ts` using Zod schemas for input validation and response typing
- **Authentication**: Replit Auth via OpenID Connect (OIDC). Sessions stored in PostgreSQL using `connect-pg-simple`. Auth middleware via Passport.js. The auth system uses `server/replit_integrations/auth/` — these files are critical and should not be modified carelessly
- **AI Integration**: OpenAI API (via Replit AI Integrations) for receipt processing. The `openai` client is configured with `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables
- **Build**: Production build uses esbuild for the server bundle and Vite for the client. Output goes to `dist/` directory

### Shared Code (`shared/`)
- **Schema** (`shared/schema.ts`): Drizzle ORM table definitions for all entities plus re-exports of auth and chat models
- **Routes** (`shared/routes.ts`): API contract definitions with Zod schemas shared between client and server. This is the single source of truth for API shapes
- **Models**: `shared/models/auth.ts` defines users and sessions tables (mandatory for Replit Auth). `shared/models/chat.ts` defines conversations and messages tables

### Database
- **Database**: PostgreSQL, required via `DATABASE_URL` environment variable
- **ORM**: Drizzle ORM with `drizzle-zod` for schema-to-Zod conversion
- **Migrations**: Managed via `drizzle-kit push` (schema push approach, not migration files). Config in `drizzle.config.ts`
- **Key Tables**:
  - `users` — user accounts (Replit Auth, do not drop)
  - `sessions` — session storage (Replit Auth, do not drop)
  - `assets` — trucks/trailers with VIN, plate, year, make, model
  - `trips` — trip records with odometer readings, loaded/empty miles, jurisdiction
  - `fuel_entries` — dedicated fuel purchases with gallons, price per gallon, jurisdiction, vendor
  - `expenses` — expense records with category, merchant, amount, receipt URL, truck ID, and fuel-specific fields
  - `income` — income records with source, amount, trailer number, route name
  - `saved_routes` — pre-saved route templates for quick income entry
  - `quick_expenses` — one-tap expense templates with label, merchant, category, amount
  - `conversations` / `messages` — AI chat history

### Storage Layer
- `server/storage.ts`: `DatabaseStorage` class implementing `IStorage` interface for all entities (expenses, income, assets, trips, fuel entries, saved routes, summary, account management)
- `server/replit_integrations/auth/storage.ts`: Auth-specific user CRUD
- `server/replit_integrations/chat/storage.ts`: Chat/conversation CRUD

### Replit Integrations (`server/replit_integrations/`)
These are pre-built integration modules. They include:
- **Auth**: Replit OIDC authentication (do not remove or restructure)
- **Chat**: AI conversation routes and storage
- **Audio**: Voice recording, playback, and streaming utilities
- **Image**: Image generation via OpenAI
- **Batch**: Batch processing utilities with rate limiting

### Development vs Production
- **Dev**: `npm run dev` runs tsx with Vite dev server middleware (HMR enabled)
- **Build**: `npm run build` builds client with Vite and server with esbuild
- **Production**: `npm start` serves the built static files and API from `dist/`

## External Dependencies

- **PostgreSQL**: Primary database, connected via `DATABASE_URL` environment variable
- **Replit Auth (OpenID Connect)**: Authentication provider, requires `ISSUER_URL`, `REPL_ID`, and `SESSION_SECRET` environment variables
- **OpenAI API**: Used for receipt processing and AI features, configured via `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`
- **shadcn/ui**: Component library configured in `components.json` with new-york style, Tailwind CSS variables, and neutral base color
- **Google Fonts**: Outfit, Plus Jakarta Sans (loaded via CSS and HTML)
- **Light Mode**: Full light mode support via theme-aware CSS tokens (`text-foreground`, `border-border`, `bg-muted`). All `white/` hardcoded references replaced with semantic tokens

### Capacitor (Native Mobile)
- **Config**: `capacitor.config.ts` — app ID: `com.haulledger.app`, webDir: `dist/public`
- **Plugins**: `@capacitor/status-bar`, `@capacitor/splash-screen`, `@capacitor/keyboard`, `@capacitor/haptics`
- **Init**: `client/src/lib/capacitor.ts` — initializes native plugins on app start
- **Safe Areas**: CSS env() variables for iOS notch/home indicator, applied to body and BottomNav
- **API Base URL**: `VITE_API_BASE_URL` env var allows pointing API calls to a deployed backend URL (needed for native Capacitor builds where the frontend is bundled locally)
- **Build for Native**: Run `npm run build` to generate `dist/public`, then use Capacitor CLI on a Mac/PC with Xcode/Android Studio to add platforms and build native binaries
- **Security Overrides**: `fast-xml-parser@4.5.4` and `minimatch@10.2.3` pinned via npm overrides in package.json