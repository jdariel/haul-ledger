--
-- PostgreSQL database dump
--

\restrict oNJ8G30Q0GW0UC6xzv5CD8CaMVN9HYLz2D30oJtGl0peFNU28aoFPRQZVIDhMx5

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."assets" (
    "id" integer NOT NULL,
    "type" "text" NOT NULL,
    "vin" "text" NOT NULL,
    "plate" "text" NOT NULL,
    "year" integer NOT NULL,
    "make" "text" NOT NULL,
    "model" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "user_id" integer
);


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."assets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."assets_id_seq" OWNED BY "public"."assets"."id";


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."expenses" (
    "id" integer NOT NULL,
    "date" "text" NOT NULL,
    "merchant" "text" NOT NULL,
    "category" "text" NOT NULL,
    "amount" real NOT NULL,
    "notes" "text",
    "receipt_url" "text",
    "truck_id" integer,
    "gallons" real,
    "price_per_gallon" real,
    "jurisdiction" "text",
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "user_id" integer
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."expenses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."expenses_id_seq" OWNED BY "public"."expenses"."id";


--
-- Name: fuel_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fuel_entries" (
    "id" integer NOT NULL,
    "date" "text" NOT NULL,
    "vendor" "text" NOT NULL,
    "gallons" real NOT NULL,
    "price_per_gallon" real NOT NULL,
    "jurisdiction" "text" NOT NULL,
    "total_amount" real NOT NULL,
    "truck_id" integer,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "user_id" integer
);


--
-- Name: fuel_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."fuel_entries_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fuel_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."fuel_entries_id_seq" OWNED BY "public"."fuel_entries"."id";


--
-- Name: income; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."income" (
    "id" integer NOT NULL,
    "date" "text" NOT NULL,
    "source" "text" NOT NULL,
    "amount" real NOT NULL,
    "trailer_number" "text",
    "route_name" "text",
    "notes" "text",
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "pickup_location" "text",
    "delivery_location" "text",
    "loaded_miles" real,
    "empty_miles" real,
    "user_id" integer
);


--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."income_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."income_id_seq" OWNED BY "public"."income"."id";


--
-- Name: quick_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."quick_expenses" (
    "id" integer NOT NULL,
    "label" "text" NOT NULL,
    "category" "text" NOT NULL,
    "default_amount" real NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "user_id" integer
);


--
-- Name: quick_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."quick_expenses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quick_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."quick_expenses_id_seq" OWNED BY "public"."quick_expenses"."id";


--
-- Name: saved_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."saved_routes" (
    "id" integer NOT NULL,
    "name" "text" NOT NULL,
    "origin" "text" NOT NULL,
    "destination" "text" NOT NULL,
    "standard_rate" real NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "user_id" integer
);


--
-- Name: saved_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."saved_routes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: saved_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."saved_routes_id_seq" OWNED BY "public"."saved_routes"."id";


--
-- Name: trips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."trips" (
    "id" integer NOT NULL,
    "date" "text" NOT NULL,
    "start_odometer" real NOT NULL,
    "end_odometer" real NOT NULL,
    "loaded_miles" real NOT NULL,
    "empty_miles" real NOT NULL,
    "jurisdiction" "text" NOT NULL,
    "truck_id" integer,
    "notes" "text",
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "pickup_location" "text",
    "delivery_location" "text",
    "user_id" integer
);


--
-- Name: trips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."trips_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."trips_id_seq" OWNED BY "public"."trips"."id";


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."users" (
    "id" integer NOT NULL,
    "name" "text" NOT NULL,
    "email" "text" NOT NULL,
    "password_hash" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "expo_push_token" "text"
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."users_id_seq" OWNED BY "public"."users"."id";


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."assets" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."assets_id_seq"'::"regclass");


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."expenses_id_seq"'::"regclass");


--
-- Name: fuel_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fuel_entries" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."fuel_entries_id_seq"'::"regclass");


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."income" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."income_id_seq"'::"regclass");


--
-- Name: quick_expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."quick_expenses" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."quick_expenses_id_seq"'::"regclass");


--
-- Name: saved_routes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."saved_routes" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."saved_routes_id_seq"'::"regclass");


--
-- Name: trips id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."trips" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."trips_id_seq"'::"regclass");


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."users" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."users_id_seq"'::"regclass");


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."assets" ("id", "type", "vin", "plate", "year", "make", "model", "created_at", "user_id") FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."expenses" ("id", "date", "merchant", "category", "amount", "notes", "receipt_url", "truck_id", "gallons", "price_per_gallon", "jurisdiction", "created_at", "user_id") FROM stdin;
5	2026-03-15	Business Adv Fundamentals - 6441	Maintenance	800	\N	/objects/uploads/05c05b99-dcef-4355-ac46-6cbe80fde1cd	\N	\N	\N	\N	2026-03-19 02:38:34.034251	\N
6	2026-01-23	Ta Bloomsbury	Fuel	194.2	\N	/objects/uploads/f717296b-d60a-4452-8901-7261ccdcbc52	\N	54.999	3.531	NJ	2026-03-19 02:39:27.088809	\N
7	2026-03-19	NY EZPASS	Tolls	200	\N	\N	\N	\N	\N	\N	2026-03-19 02:41:57.083615	\N
\.


--
-- Data for Name: fuel_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fuel_entries" ("id", "date", "vendor", "gallons", "price_per_gallon", "jurisdiction", "total_amount", "truck_id", "created_at", "user_id") FROM stdin;
1	2026-03-19	Pilot Flying J	120.5	3.449	TX	415.5	\N	2026-03-19 00:54:12.226198	\N
2	2020-07-10	Fuel Depot	33.182	2.97	NV	102.98	\N	2026-03-19 00:54:54.423711	\N
3	2026-01-23	Ta Bloomsbury	54.999	3.531	NJ	194.2	\N	2026-03-19 02:39:27.088809	\N
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."income" ("id", "date", "source", "amount", "trailer_number", "route_name", "notes", "created_at", "pickup_location", "delivery_location", "loaded_miles", "empty_miles", "user_id") FROM stdin;
2	2026-03-21	2333	500	\N	edison,nj → bronx,ny	\N	2026-03-21 17:56:08.998631	edison,nj	bronx,ny	42	\N	\N
3	2026-03-21	4545	600	\N	paterson,nj → leroy,ny	\N	2026-03-21 17:56:54.37012	paterson,nj	leroy,ny	326	20	\N
\.


--
-- Data for Name: quick_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."quick_expenses" ("id", "label", "category", "default_amount", "created_at", "user_id") FROM stdin;
1	Scale Fee	Scale Fee	15	2026-03-18 23:56:18.69715	\N
2	Parking	Parking	20	2026-03-18 23:56:18.735512	\N
3	Lumper	Lumper	100	2026-03-18 23:56:18.772133	\N
4	Tolls	Tolls	25	2026-03-18 23:56:18.810603	\N
\.


--
-- Data for Name: saved_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."saved_routes" ("id", "name", "origin", "destination", "standard_rate", "created_at", "user_id") FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."trips" ("id", "date", "start_odometer", "end_odometer", "loaded_miles", "empty_miles", "jurisdiction", "truck_id", "notes", "created_at", "pickup_location", "delivery_location", "user_id") FROM stdin;
1	2026-03-21	0	42	42	0	N/A	\N	Auto-logged from income: 2333	2026-03-21 17:56:09.028698	edison,nj	bronx,ny	\N
2	2026-03-21	0	346	326	20	N/A	\N	Auto-logged from income: 4545	2026-03-21 17:56:54.376186	paterson,nj	leroy,ny	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."users" ("id", "name", "email", "password_hash", "created_at", "expo_push_token") FROM stdin;
1	John Trucker	test@example.com	$2b$12$sQfG90etP9c3WQvsaPHhK.LmUu8clTfh/ZrVLAYbJ7.TGEHB22Wyq	2026-03-19 02:00:09.002634	\N
2	Dariel Jimenez	jimenezdariel16@gmail.com	$2b$10$/q1Jg4zlN/N9MV/a1tsbYepKlJsm2ed2XPIJT3A.GtKZtgbFMV6z6	2026-03-19 02:17:05.241465	ExponentPushToken[ZZ_NmJBQyJSUmVmBP0od0M]
\.


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."assets_id_seq"', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."expenses_id_seq"', 7, true);


--
-- Name: fuel_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."fuel_entries_id_seq"', 3, true);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."income_id_seq"', 3, true);


--
-- Name: quick_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."quick_expenses_id_seq"', 5, true);


--
-- Name: saved_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."saved_routes_id_seq"', 1, false);


--
-- Name: trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."trips_id_seq"', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 2, true);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."assets"
    ADD CONSTRAINT "assets_pkey" PRIMARY KEY ("id");


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_pkey" PRIMARY KEY ("id");


--
-- Name: fuel_entries fuel_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fuel_entries"
    ADD CONSTRAINT "fuel_entries_pkey" PRIMARY KEY ("id");


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."income"
    ADD CONSTRAINT "income_pkey" PRIMARY KEY ("id");


--
-- Name: quick_expenses quick_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."quick_expenses"
    ADD CONSTRAINT "quick_expenses_pkey" PRIMARY KEY ("id");


--
-- Name: saved_routes saved_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."saved_routes"
    ADD CONSTRAINT "saved_routes_pkey" PRIMARY KEY ("id");


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."trips"
    ADD CONSTRAINT "trips_pkey" PRIMARY KEY ("id");


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_email_unique" UNIQUE ("email");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: assets assets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."assets"
    ADD CONSTRAINT "assets_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: expenses expenses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: fuel_entries fuel_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fuel_entries"
    ADD CONSTRAINT "fuel_entries_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: income income_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."income"
    ADD CONSTRAINT "income_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: quick_expenses quick_expenses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."quick_expenses"
    ADD CONSTRAINT "quick_expenses_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: saved_routes saved_routes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."saved_routes"
    ADD CONSTRAINT "saved_routes_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- Name: trips trips_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."trips"
    ADD CONSTRAINT "trips_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");


--
-- PostgreSQL database dump complete
--

\unrestrict oNJ8G30Q0GW0UC6xzv5CD8CaMVN9HYLz2D30oJtGl0peFNU28aoFPRQZVIDhMx5

